# GitHub Copilot Instructions for di-4-free

This file provides guidance to GitHub Copilot when working with code in this repository.

## Project Overview

di-4-free is a web application for streaming music from AudioAddict networks (DI.FM, RadioTunes, etc.). It's a frontend-only application built with vanilla JavaScript and Lit web components.

## Tech Stack

- **JavaScript (ES Modules)**: All code uses modern ES modules with native browser imports
- **Lit**: Web components are built using the Lit library (loaded from CDN)
- **IndexedDB**: Local storage for tracks and playlists via `js/db.js`
- **Cloudflare Functions**: Serverless functions in the `functions/` directory
- **CSS**: External CSS files with names matching their JS web component counterparts. Use native CSS nesting when possible.

## Project Structure

- `/js/` - Main JavaScript application code
  - `app.js` - Entry point with imports
  - `lit.js` - Main Lit application with `MusicPlayer` component
  - `audioaddict.js` - API client for AudioAddict services
  - `db.js` - IndexedDB database setup and exports
  - `utils.js` - Utility functions (`getJson`, `postJson`, `lazy`, etc.)
  - `components/` - Reusable Lit components
- `/functions/` - Cloudflare Functions for edge computing
- `/img/` - Static images and SVG icons
- `lit.html` - Main HTML entry point

## Code Style Guidelines

- Follow [StandardJS](https://standardjs.com/) coding format, but use tabs instead of spaces for indentation
- Use ES module imports/exports (no CommonJS)
- Use only one single `export { ... }` statement at the bottom of each `.js` file
- Never use default exports - all exports should be named
- Prefer arrow functions and modern JavaScript syntax
- Web components should extend `LitElement` from Lit
- Keep dependencies minimal - use CDN imports where possible
- UI text is primarily in Swedish

## Key Patterns

- **IndexedDB Transactions**: Use the `q()` and `qq()` database helper functions defined in `lit.js` for database operations
- **API Calls**: Use utility functions from `utils.js` (`getJson`, `postJson`, etc.)
- **Web Components**: Define custom elements with `customElements.define()`
- **State Management**: Use Lit's reactive properties (`static properties = {}`)

## Important Notes

- No build step required - code runs directly in the browser
- No package.json or npm dependencies - all external libraries loaded via CDN
- AudioAddict API requires specific authentication headers
