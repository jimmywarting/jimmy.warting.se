import { makeDictionary, getJson, pick, postJson, call, bytesToCdnUrl } from './utils.js'
import { kv } from 'https://localwebcontainer.com/clientmyadmin/shared/kv.js'

let config = await kv('get', 'config')

if (!config) {
	const networks = await getJson('https://api.audioaddict.com/v1/networks')
	const channelMap = {}
	const q = await Promise.all([
		postJson(
			`https://api.audioaddict.com/v1/di/member_sessions`,
			{ member_session: { unregistered: 'true' } },
			{
				'content-type': 'application/json',
				authorization: 'Basic bW9iaWxlOmFwcHM='
			}
		),
		getJson(`https://api.audioaddict.com/v1/di/qualities`),
		Promise.all(networks.map(network =>
			getJson(`https://api.audioaddict.com/v1/${network.key}/channel_filters`)
		)).then(data => {
			const filterPicker = pick('position,networkId,name,key,images,id,descriptionText,descriptionTitle,channels'.split(','))
			const channelPicker = pick('assetUrl,bannerUrl,description,descriptionLong,descriptionShort,id,images,key,name,networkId'.split(','))

			const filters = data.flat().map(filter => {
				const ids = filter.channels.map(c => {
					channelMap[c.id] ??= channelPicker(c)
					return c.id
				})

				filter.channels = ids

				return filterPicker(filter)
			})

			filters.sort((a, b) => a.position - b.position)
			filters.forEach(f => delete f.position)

			return filters
		})
	])

	q[1].sort((a, b) => a.position - b.position)
	q[1].forEach(f => delete f.position)

	config = {
		networks,
		session: q[0],
		qualities: q[1],
		filters: q[2],
		channels: Object.values(channelMap)
	}

	// Promise.all(config.channels.map(async channel => {
	// 	const url = bytesToCdnUrl(channel.images.square)
	// 	const response = await fetch(url)
	// 	const blob = await response.file({ name: channel.name + '.png' })
	// 	channel.images.squareBlob = await blob.convertToImage('webp', .9)
	// 	channel.images.squareBlobThumbnail = await blob.convertToImage('webp', .9, 150)
	// }))

	const sortingOptions = [
		{
			id: 'size',
			label: 'Storlek',
			checked: false,
			order: 'Stigande'
		},
		{
			id: 'displayTitle',
			label: 'Namn',
			checked: false,
			order: 'Stigande'
		},
		{
			id: 'displayArtist',
			label: 'Artist',
			checked: false,
			order: 'Stigande'
		},
		{
			id: 'album',
			label: 'Album',
			checked: false,
			order: 'Stigande'
		},
		{
			id: 'duration',
			label: 'Längd',
			checked: false,
			order: 'Stigande'
		},
		{
			id: 'rating',
			label: 'Betyg',
			checked: false,
			order: 'Stigande'
		},
		{
			id: 'PCNT',
			label: 'Antal spelningar',
			checked: true,
			order: 'Stigande'
		},
		{
			id: 'randomness',
			label: 'Slumpa',
			checked: true,
			order: 'Lägg till ny'
		},
		{
			id: 'lastplayed',
			label: 'Senast spelad',
			checked: true,
			order: 'Fallande'
		},
		{
			id: 'reaction',
			label: 'Reaktion',
			checked: false,
			order: 'Stigande'
		},
		{
			id: 'fileHandle',
			label: 'Nedladdad',
			checked: false,
			order: 'Stigande'
		},
		{
			id: 'cached',
			label: 'temporärt cachad',
			checked: false,
			order: 'Stigande'
		}
	]

	config.networks.forEach(n => {
		n.name = n.name
			.replace(/\.com/i, '')
			.toLowerCase()
			.replace('radio', 'Radio')
			.replace(/./, char => char.toUpperCase())
	})

	config.settings = {
		notificationsEnabled: false,
		notifyNewTrack: false,
		inactivityPause: false,
		audioOutput: 'default',
		qualityWifi: 'ultra',
		qualityMobile: 'medium',
		qualityDownload: 'ultra',
		maxSongs: 0,
		maxHours: 0,
		maxSizeGB: 0,
		maxSongsPerStation: 0,
		ttlDays: 0,
		autoReplaceOld: false,
		wifiOnlyDownload: true,
		protectUpvoted: true,
		autoOfflineMode: false
	}

	await kv('put', config, 'config')
}

// listener keys that works:
// 036aa6df146c7b1d
// 20a1d1bf879e76
// 780a4f0bfb95c977ceab43a2
// 9564836dd232258
// 6a40af94924ae467
// https://github.com/search?q=%2Fhttp%3A%5C%2F%5C%2Fprem%281%7C2%7C3%7C4%29%5C.di%5C.fm%5C%2F%5B%5E%5C%2F%5Cs%5D%2B_hi%5C%3F%5B0-9a-f%5D%2B%2F&type=code
// keys = [...new Set(document.body.innerText.match(/http:\/\/prem(1|2|3|4)\.di\.fm\/[^\/\s]+_hi\?[0-9a-f]+/g).map(e => e.split('?')[1]))]

const listenerKey = '9564836dd232258' // https://github.com/alexjulien/DIfm_pls
config.listenerKey = listenerKey
globalThis.config = config

class AudioAddict {
	// voteUp (track) {
	//   const network = config.networks.find(n => n.id === track.networkId).key
	//   return postJson(`https://api.audioaddict.com/v1/${network}/tracks/${track.trackId}/vote/up`, {}, {
	//     'x-session-key': '0ffbc9bdae68faa9a65127c71289daa5'
	//   })
	// }

	// voteDown (track) {
	//   const network = config.networks.find(n => n.id === track.networkId).key
	//   return postJson(`https://api.audioaddict.com/v1/${network}/tracks/${track.trackId}/vote/down`, {}, {
	//     'x-session-key': '0ffbc9bdae68faa9a65127c71289daa5'
	//   })
	// }

	// deleteVote (track) {
	//   const network = config.networks.find(n => n.id === track.networkId).key
	//   return fetch(`https://api.audioaddict.com/v1/${network}/tracks/${track.trackId}/vote`, {
	//     method: 'DELETE',
	//     headers: {
	//       'x-session-key': '0ffbc9bdae68faa9a65127c71289daa5'
	//     }
	//   }).then(res => res.json())
	// }

	async getTrack (track) {
		const result = await getJson(`https://api.audioaddict.com/v1/di/tracks/${track.trackId}?audio_token=${config.session.audioToken}`)
		result.content.assets.forEach(asset => {
			// get ext from url
			const url = new URL(asset.url)
			asset.ext = url.pathname.split('.').pop()
		})
		return result
	}

	getTrackWithoutContent (trackId) {
		return getJson(`https://api.audioaddict.com/v1/di/tracks/${trackId}?audio_token=${config.session.audioToken}`)
	}

	async nowPlaying (channel) {
		// https://api.audioaddict.com/v1/di/currently_playing/channel/1
		const net = config.networks.by({ id: channel.networkId })
		const result = await getJson(`https://api.audioaddict.com/v1/${net.key}/currently_playing/channel/${channel.id}?audio_token=${config.session.audioToken}`, {
    	'x-session-key': config.session.key
  	})
		const track = await getJson(`https://api.audioaddict.com/v1/${net.key}/tracks/${result.track.id}/${net.id}?audio_token=${config.session.audioToken}`, {
	    'x-session-key': config.session.key
	  })
		track.content.assets.forEach(asset => {
			// get ext from url
			const url = new URL(asset.url)
			asset.ext = url.pathname.split('.').pop()
		})

		return { started: 999 + +result.track.startTime, track }
	}

	/**
   * @param {Channel[]} channels
   */
	generatePlaylist (channels) {
		const playlist = []
		playlist.push('[playlist]')
		playlist.push(`NumberOfEntries=${channels.length}`)
		channels.forEach((channel, i) => {
			playlist.push(`File${i}=http://prem1.di.fm/${channel.key}_hi?${listenerKey}`)
			playlist.push(`Title${i}=${channel.name}`)
			playlist.push(`Length${i}=0`)
		})
		return playlist.join('\n')
	}

	generateM3u8Playlist (channels) {
		const playlist = []

		playlist.push('#EXTM3U')

		channels.forEach(channel => {
			playlist.push(`#EXTINF:-1,${channel.name}`)
			playlist.push(`http://prem1.di.fm/${channel.key}_hi?${listenerKey}`)
		})

		return playlist.join('\n')
	}

	getChannel (channel) {
		return channelD[channel]
	}

	/**
   * Gets all channels
   */
	get channels () {
		return config.channels // 1 = all
	}

	/** @param {Channel} */
	async tuneIn (channel) {
		const result = await getJson(`https://api.audioaddict.com/v1/di/routines/channel/${channel.id}?tune_in=false&audio_token=${config.session.audioToken}`)
		result.tracks.forEach(track => {
			track.content.assets.forEach(asset => {
				// get ext from url
				const url = new URL(asset.url)
				asset.ext = url.pathname.split('.').pop()
			})
		})

		return result
	}

	async ping () {
		return getJson('https://api.audioaddict.com/v1/ping')
	}

	/**
   * @param {channel} channel
   * @returns {Promise<trackHistory[]>}
   */
	async trackHistory (channel) {
		const network = config.networks.find(n => n.id === channel.networkId).key
		return getJson(`https://api.audioaddict.com/v1/${network}/track_history/channel/${channel.id}`)
	}

	// t = await audioAddict.getTrack(currentTrack)
	// t.content.assets[0]

	async preferredQuality (qualityId) {
		if (qualityId) {
			return postJson(`https://api.audioaddict.com/v1/di/members/${config.session.memberId}/preferred_quality`,
			{ quality_id: qualityId }, {
				'x-session-key': config.session.key
			})
		} else {
			const res = await getJson(`https://api.audioaddict.com/v1/di/members/${config.session.memberId}/preferred_quality`, {
				'x-session-key': config.session.key
			})
			const cof = await kv('get', config, 'config')
			cof.preferredQuality = res
			await kv('put', cof, 'config')
			return res
		}
	}

	preferredQuality2 () {
		return getJson(`https://api.audioaddict.com/v1/di/members/${config.session.memberId}/preferred_qualities`, {
			'x-session-key': config.session.key
		})
	}

	sessions () {
		return getJson(`https://api.audioaddict.com/v1/di/members/${config.session.memberId}/active_sessions?page=1&per_page=100`, {
			'x-session-key': config.session.key
		})

		// https://api.audioaddict.com/v1/di/qualities?all=true
		// https://api.audioaddict.com/v1/di/members/307868/social_identities
	}

	auth () {
		fetch('https://api.audioaddict.com/v1/di/members/authenticate', {
			headers: {
				'content-type': 'application/json'
			},
			body: JSON.stringify({
				username: '',
				password: ''
			}),
			method: 'POST'
		})
	}

	async batchInfo () {
		const res = await fetch('https://api.audioaddict.com/v1/di/mobile/batch_update?stream_set_key=public3', {
			headers: {
				Authorization: 'Basic ZXBoZW1lcm9uOmRheWVpcGgwbmVAcHA='
			}
		})
		const data = await res.json()
		return data
	}
}

const audioAddict = new AudioAddict()
globalThis.audioAddict = audioAddict

export { audioAddict }

/*
https://api.audioaddict.com/v1/di/members/16409657/preferred_qualities
{
	"preferred_qualities": [{
		"quality_id": 4,
		"client_device_category": "native_mobile",
		"client_device_category_id": 3,
		"connection_class": "cellular"
	}]
}
https://api.audioaddict.com/v1/di/members/16409657/preferred_qualities
{
	"preferred_qualities": [{
		"quality_id": 4,
		"client_device_category": "native_mobile",
		"client_device_category_id": 3,
		"connection_class": "wifi"
	}]
}

AAC_64("Good 64k (AAC)", "premium_medium"), AAC_128("Excellent (128k AAC)", "premium"), MP3_320("Excellent (320k MP3)", "premium_high");

https://listen.di.fm/premium_medium/favorites?9564836dd232258
https://listen.di.fm/premium_medium?9564836dd232258

http://prem2.di.fm:80/deeporganichouse_hi?9564836dd232258 // Premium high - premium_high (320k)
http://prem2.di.fm:80/deeporganichouse?9564836dd232258 // Premium - premium (128k)
http://prem2.di.fm:80/deeporganichouse_aac?9564836dd232258 // AAC Medium - premium_medium (64k)

https://content.audioaddict.com/prd/7/4/5/b/e/3639b783129ed1e1abae9d4ee9778091a0c.mp4?purpose=playback&audio_token=685470e635f926cff28989d4a7c832ba&network=radiotunes&device=chrome_143_mac_os_x_10_15_7&ip=2001:9b1:42f7:f100:c542:999a:50dc:7d2d&ip_type=6&country_code=SE&masked_ipv6=2001:9b1:42f7:f100::/64&channel_id=20&routine_id=239&exp=2026-01-17T19:12:52Z&auth=6f43468ebe746db91628e7cb7aeeb5ba00c7c3ea
https://content-beta.audioaddict.com/prd/f/6/4/9/a/dae912cd0798e4be88eb85a0995017a0127.mp4?purpose=playback&audio_token=685470e635f926cff28989d4a7c832ba&network=radiotunes&device=chrome_143_mac_os_x_10_15_7&ip=2001:9b1:42f7:f100:c542:999a:50dc:7d2d&ip_type=6&country_code=SE&masked_ipv6=2001:9b1:42f7:f100::/64&channel_id=20&routine_id=239&exp=2026-01-17T19:12:52Z&auth=6f43468ebe746db91628e7cb7aeeb5ba00c7c3ea
https://cdn-images.audioaddict.com/a/9/b/0/6/7/a9b06764d5c55fe17cb6e58b09f92c9a.webp?size=207x297&quality=75
https://api.audioaddict.com/v1/di/timed_alerts
https://api.audioaddict.com/v1/radiotunes/skip_rulesets/active
https://api.audioaddict.com/v1/radiotunes/skip_rulesets
https://api.audioaddict.com/v1/di/events/upcoming?channel_id=2&limit=6&light=1
https://api.audioaddict.com/v1/di/events?start=1768672800&end=1769209199&channel_filter_id=1&light=1
https://api.audioaddict.com/v1/ping
https://api.audioaddict.com/v1/networks
https://api.audioaddict.com/v1/di/member_sessions
https://api.audioaddict.com/v1/di/qualities
https://api.audioaddict.com/v1/di/tracks/${trackId}
https://api.audioaddict.com/v1/di/members/authenticate
https://api.audioaddict.com/v1/di/mobile/batch_update?stream_set_key=public3
https://api.audioaddict.com/v1/di/members/${memberId}/data_preferences
https://api.audioaddict.com/v1/di/members/${memberId}/social_identities
https://api.audioaddict.com/v1/di/members/${memberId}/payment_method
https://api.audioaddict.com/v1/di/members/${memberId}/favorites/channels
https://api.audioaddict.com/v1/di/plans/active?service_key=radiotunes-premium
https://api.audioaddict.com/v1/di/members/${memberId}/preferred_quality
https://api.audioaddict.com/v1/di/members/${memberId}/preferred_qualities
https://api.audioaddict.com/v1/di/members/${memberId}/active_sessions?page=1&per_page=100
https://api.audioaddict.com/v1/di/routines/channel/${channel.id}
https://api.audioaddict.com/v1/di/skip_rulesets/active
https://api.audioaddict.com/v1/di/shows/pharmacy-radio/episodes?page=1&per_page=1
https://api.audioaddict.com/v1/di/shows/index?order_by%5B%5D=active&order_by%5B%5D=follows_count&channel_filter_id=6&page=1&per_page=14
https://api.audioaddict.com/v1/di/shows/index?order_by%5B%5D=active&order_by%5B%5D=follows_count&channel_id=2&page=1&per_page=14
https://api.audioaddict.com/v1/di/shows/{slug_show}/episodes?page=1&per_page=5
https://api.audioaddict.com/v1/di/shows/{slug_show}/episodes/{slug_episode}

link <https://api.audioaddict.com/v1/di/shows/index?channel_id=2&order_by%5B%5D=active&order_by%5B%5D=follows_count&page=107&per_page=14>; rel="last",
link <https://api.audioaddict.com/v1/di/shows/index?channel_id=2&order_by%5B%5D=active&order_by%5B%5D=follows_count&page=2&per_page=14>; rel="next"
paginate-page 1
paginate-pages 107
paginate-perpage 14
paginate-records 1498

quality_id=4
*/
