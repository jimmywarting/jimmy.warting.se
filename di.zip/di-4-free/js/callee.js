// const { Peer } = await import('./peer.js?' + Date.now())
import { Peer } from 'https://jimmy.warting.se/packages/peer/perfect-negotiation.js'
import EncryptionHelperAES128GCM from 'https://jimmy.warting.se/packages/webpush/encryption-aes128gcm.js'
import clients from '/clientmyadmin/clients' with { type: 'json' }
import { generate } from 'https://cdn.jsdelivr.net/npm/lean-qr@2.6.1/index.mjs';

let mySubscription = null
const p2p = globalThis.p2p = {}
const { platform, mobile } = navigator.userAgentData || {}

const canvas = document.createElement('canvas')
const bc = new BroadcastChannel('push-messages')
bc.onmessage = async (evt) => {
  const { initiator, ...data } = evt.data
  const { sub, id } = initiator
  const peer = (p2p[id] ??= new Peer({
    polite: false,
    trickle: false,
    iceServers: []
  }))

  peer.signalingPort.postMessage(data)
  peer.signalingPort.onmessage ??= ({data}) => {
    const obj = JSON.parse(data)
    obj.initiator = { id, sub: mySubscription, platform, mobile }
    sendPushMessage(sub, JSON.stringify(obj))
  }
}

const sw = await navigator.serviceWorker.ready
canvas.style.imageRendering = 'pixelated'
canvas.style.verticalAlign = 'text-bottom'
canvas.className = 'qr'

const APPLICATION_KEYS = {
  privateKey: 'H0L1P2gEoPH5RIEVFmb2E3NWxEcYyjZWoVFiCVfHRuA',
  publicKey: 'BAxmrX2FAMLfM2SxV81N_8gAXJEuUUjJVPTRpl5GboIfSJhOySknIWAMukb3P5s9l52bvp2FnnaEX6b2RV2UokE'
}

const encryptionHelper = new EncryptionHelperAES128GCM({
  vapidKeys: APPLICATION_KEYS,
  // contact information for push service to contact you
  // in case of problem. It's either a mailto: or https: link
  subject: location.origin
})

const permission = await navigator.permissions.query({
  name: 'push',
  userVisibleOnly: true
})

const createQrCode = async () => {
  mySubscription =
    await sw.pushManager.getSubscription() ||
    await sw.pushManager.subscribe({
      userVisibleOnly: true, // a chrome requirement...
      applicationServerKey: APPLICATION_KEYS.publicKey
    })

  const obj = mySubscription.toJSON()
  const data = [
    obj.endpoint.replace('https://fcm.googleapis.com/fcm/send/', '0'),
    obj.keys.p256dh,
    obj.keys.auth
  ]

  generate(JSON.stringify(data)).toCanvas(canvas, {
    on: [0x00, 0x00, 0x00, 0xFF], // black
    off: [0x00, 0x00, 0x00, 0x00], // transparent
    pad: 0,
  })
}

if (permission.state === 'granted') {
  await createQrCode()
}

permission.onchange = async () => {
  if (permission.state === 'granted') {
    createQrCode()
  } else {
    canvas.remove()
  }
}

const decodeSubscription = (qrString) => {
  const [ endpoint, p256dh, auth ] = JSON.parse(qrString)
  return {
    endpoint: endpoint.replace(/^0/, 'https://fcm.googleapis.com/fcm/send/'),
    expirationTime: null,
    keys: {
      p256dh,
      auth
    }
  }
}

async function sendPushMessage (subscription, text) {
  const uint8 = new TextEncoder().encode(text)

  // Return an array that can be passed to fetch as arguments
  const request = await encryptionHelper.getRequestDetails(
    subscription,
    uint8
  )

  // Cors support on a push services is a reasonable SHOULD requirement
  // https://github.com/w3c/push-api/issues/303

  // Currently only mozilla have CORS enabled.
  // So we can make request directly to them.
  if (request[0].includes('mozilla.com')) {
    return fetch(...request)
  }

  // As for the rest: poke the bear and tell them to enable CORS support
  // In the meanwhile we will have to use a CORS proxy
  return sendRequestToProxyServer(...request)
}

async function sendRequestToProxyServer(url, requestInfo) {
  const q = new URLSearchParams({
    cors: JSON.stringify({
      url,
      headers: requestInfo.headers,
      forwardRequestHeaders: false,
      setRequestHeaders: [...new Headers(requestInfo.headers)]
    })
  })

  url = 'https://adv-cors.deno.dev/?' + q

  return fetch(url, { method: 'POST', body: requestInfo.body })
}

function call (subscription) {
  const id = Math.random().toString(36).slice(2)
  const peer = new Peer({
    polite: true,
    trickle: false,
    iceServers: []
  })

  p2p[id] = peer

  peer.signalingPort.onmessage ??= ({data}) => {
    const obj = JSON.parse(data)
    obj.initiator = { id, sub: mySubscription, platform, mobile }
    sendPushMessage(subscription, JSON.stringify(obj))
  }
}

class QRConnect extends HTMLElement {
  // Private fields
  #shadow;
  #video;
  #resultEl;
  #button;
  #stream = null;
  #scanning = false;
  #detector = null;

  #tabScanBtn;
  #tabShowBtn;
  #tabScanPanel;
  #tabShowPanel;
  #qrImg;
  #qrLabel;
  #qrValue = '';

  // Handlers
  #onStartClick;
  #scanFrame;
  #onTabScanClick;
  #onTabShowClick;

  constructor() {
    super();
    this.#shadow = this.attachShadow({ mode: 'open' });
    this.#shadow.innerHTML = `
      <style>
        :host {
          display: block;
          font-family: system-ui, sans-serif;
          max-width: 600px;
        }
        .card {
          border: 1px solid #ddd;
          border-radius: 8px;
          padding: 1rem;
        }
        .tabs {
          display: flex;
          border-bottom: 1px solid #ddd;
          margin-bottom: 0.75rem;
        }
        .tab {
          flex: 1;
          text-align: center;
          padding: 0.5rem;
          cursor: pointer;
          user-select: none;
          border-bottom: 2px solid transparent;
        }
        .tab.active {
          font-weight: 600;
          border-color: #007aff;
        }
        .panels > div {
          display: none;
        }
        .panels > div.active {
          display: block;
        }

        /* Scan area: center the button over the video */
        .scan-container {
          position: relative;
          width: 100%;
          border-radius: 8px;
          overflow: hidden;
          background: #000;
        }
        video {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }
        .scan-button {
          position: absolute;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%);
          padding: 0.75rem 1.5rem;
          font-size: 1rem;
          cursor: pointer;
          border-radius: 999px;
          border: none;
          background: rgba(0, 0, 0, 0.7);
          color: #fff;
        }
        .scan-button:disabled {
          opacity: 0.7;
          cursor: default;
        }

        .result {
          margin-top: 0.75rem;
          padding: 0.5rem;
          border-radius: 6px;
          background: #e6ffed;
          border: 1px solid #34c759;
          font-weight: 600;
          word-break: break-word;
        }

        canvas.qr {
          display: block;
          margin: 0.5rem auto 0;
          background: #fff;
          border-radius: 4px;
          width: 256px;
          height: 256px;
          object-fit: contain;
        }
        .qr-label {
          margin-top: 0.25rem;
          font-size: 0.85rem;
          color: #555;
          text-align: center;
          word-break: break-word;
        }
      </style>
      <div class="card">
        <div class="tabs" role="tablist">
          <div id="tab-scan" class="tab active" role="tab" aria-selected="true">Discover</div>
          <div id="tab-show" class="tab" role="tab" aria-selected="false">Advertise</div>
        </div>

        <div class="panels">
          <!-- Scan panel -->
          <div id="panel-scan" class="active" role="tabpanel">
            <div class="scan-container">
              <video id="video" playsinline autoplay muted></video>
              <button id="startBtn" class="scan-button" type="button">
                Start scanning
              </button>
            </div>
            <div id="result" class="result" hidden></div>
          </div>

          <!-- Be scanned panel -->
          <div id="panel-show" role="tabpanel">
            <p>Show this QR code to another device so it can connect to you.</p>
            <!-- Static QR from a URL; content is updated from "value" -->
            <img
              id="qrImg"
              class="qr"
              alt="QR code"
              src="https://api.qrserver.com/v1/create-qr-code/?size=256x256&data=example"
            />
            <div class="qr-label" id="qrLabel"></div>
          </div>
        </div>
      </div>
    `;

    // Scan UI
    this.#video = this.#shadow.getElementById('video');
    this.#resultEl = this.#shadow.getElementById('result');
    this.#button = this.#shadow.getElementById('startBtn');

    // Tabs
    this.#tabScanBtn = this.#shadow.getElementById('tab-scan');
    this.#tabShowBtn = this.#shadow.getElementById('tab-show');
    this.#tabScanPanel = this.#shadow.getElementById('panel-scan');
    this.#tabShowPanel = this.#shadow.getElementById('panel-show');

    // QR display
    this.#qrImg = this.#shadow.getElementById('qrImg');
    this.#qrLabel = this.#shadow.getElementById('qrLabel');

    // Arrow functions so `this` works with private fields
    this.#onStartClick = () => {
      if (!this.#scanning) {
        this.#startScanning();
      }
    };
    this.#scanFrame = async () => {
      await this.#doScanFrame();
    };
    this.#onTabScanClick = () => this.#tryActivateTab('scan');
    this.#onTabShowClick = () => this.#tryActivateTab('show');
  }

  static get observedAttributes() {
    return ['value'];
  }

  attributeChangedCallback(name, _oldValue, newValue) {
    if (name === 'value') {
      this.#qrValue = newValue || '';
      this.#renderQR();
    }
  }

  connectedCallback() {
    this.#button.addEventListener('click', this.#onStartClick);
    this.#tabScanBtn.addEventListener('click', this.#onTabScanClick);
    this.#tabShowBtn.addEventListener('click', this.#onTabShowClick);
    this.#renderQR();
  }

  disconnectedCallback() {
    this.#button.removeEventListener('click', this.#onStartClick);
    this.#tabScanBtn.removeEventListener('click', this.#onTabScanClick);
    this.#tabShowBtn.removeEventListener('click', this.#onTabShowClick);
    this.stop();
  }

  // Public API for value
  get value() {
    return this.#qrValue;
  }

  set value(v) {
    this.#qrValue = String(v ?? '');
    this.setAttribute('value', this.#qrValue);
    this.#renderQR();
  }

  async #tryActivateTab(tab, autoStartScan = false) {
    // Require push permission before *either* scanning or being scanned
    const pushOk = await this.#ensurePushPermission();
    if (!pushOk) return;

    this.#activateTab(tab);
    if (tab === 'scan' && autoStartScan) {
      this.#startScanning();
    }
  }

  #activateTab(tab) {
    const isScan = tab === 'scan';

    this.#tabScanBtn.classList.toggle('active', isScan);
    this.#tabShowBtn.classList.toggle('active', !isScan);
    this.#tabScanPanel.classList.toggle('active', isScan);
    this.#tabShowPanel.classList.toggle('active', !isScan);

    if (!isScan) {
      // When switching away from Scan, stop camera for privacy/battery
      this.stop();
    }
  }

  async #ensurePushPermission() {
    if (!('Notification' in window)) {
      alert('This browser does not support Web Notifications / Push.');
      return false;
    }

    // If already granted, ok
    if (Notification.permission === 'granted') {
      return true;
    }

    // If denied, bail out
    if (Notification.permission === 'denied') {
      alert(
        'Notification permission has been denied.\n' +
        'Please enable notifications in your browser settings before using this feature.'
      );
      return false;
    }

    // At this point, permission is "default" (not yet asked): request it explicitly.
    try {
      const result = await Notification.requestPermission();
      if (result !== 'granted') {
        alert(
          'You must allow notifications (Web Push) before scanning or showing your QR code.\n' +
          'Please try again and accept the permission prompt.'
        );
        return false;
      }
      return true;
    } catch (err) {
      console.error('Notification permission request failed:', err);
      alert('Unable to request notification permission.');
      return false;
    }
  }

  async #ensureCameraPermission() {
    // Basic checks
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      alert('Camera access is not supported in this browser.');
      return false;
    }

    // If Permissions API is available, check current state
    if (navigator.permissions && navigator.permissions.query) {
      try {
        const status = await navigator.permissions.query({ name: 'camera' });
        if (status.state === 'denied') {
          alert(
            'Camera permission has been denied. ' +
            'Please enable camera access in your browser/site settings and try again.'
          );
          return false;
        }
        // If "prompt" or "granted", we proceed and let getUserMedia handle the actual prompt.
      } catch {
        // Ignore Permission API errors and just rely on getUserMedia
      }
    }

    return true;
  }

  async #initDetector() {
    if (!('BarcodeDetector' in window)) {
      throw new Error('BarcodeDetector is not supported in this browser.');
    }

    const supported = await BarcodeDetector.getSupportedFormats();
    if (!supported.includes('qr_code')) {
      throw new Error('QR code format is not supported by BarcodeDetector on this browser.');
    }

    this.#detector = new BarcodeDetector({ formats: ['qr_code'] });
  }

  async #startCamera() {
    // Ask for / trigger camera permission
    const ok = await this.#ensureCameraPermission();
    if (!ok) {
      throw new Error('Camera permission not granted.');
    }

    try {
      this.#stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' },
        audio: false,
      });
    } catch (err) {
      // Handle explicit permission denial or other getUserMedia errors
      if (err && (err.name === 'NotAllowedError' || err.name === 'SecurityError')) {
        throw new Error(
          'Camera access was denied. Please allow camera permission and try again.'
        );
      }
      if (err && err.name === 'NotFoundError') {
        throw new Error('No suitable camera device was found.');
      }
      throw err;
    }

    this.#video.srcObject = this.#stream;
    this.#tabScanPanel.requestFullscreen()

    await new Promise((resolve, reject) => {
      this.#video.onloadedmetadata = () => {
        this.#video.play().then(resolve).catch(reject);
      };
      this.#video.onerror = reject;
    });
  }

  #stopCamera() {
    if (this.#stream) {
      this.#stream.getTracks().forEach(track => track.stop());
      this.#stream = null;
    }
    this.#video.srcObject = null;
  }

  async #doScanFrame() {
    if (!this.#scanning || !this.#detector) return;

    try {
      if (this.#video.readyState >= 2) { // HAVE_CURRENT_DATA
        const barcodes = await this.#detector.detect(this.#video);

        for (const qr of barcodes) {
          this.#scanning = false;
          this.#stopCamera();

          let value = qr.rawValue ?? '';
          if (!value.startsWith('["')) continue; // Not our expected format
          value = decodeSubscription(value)
          call(value)
          document.exitFullscreen()
          this.#resultEl.hidden = false;
          this.#resultEl.textContent = 'QR Code Content: ' + JSON.stringify(value)
          this.#button.disabled = false;
          this.#button.textContent = 'Start again';

          // Simple behavior for now: just alert when found
          console.log('QR code found', value);
          return
        }
      }
    } catch (err) {
      console.error('Detection error:', err);
      this.#scanning = false;
      this.#stopCamera();
      this.#button.disabled = false;
      this.#button.textContent = 'Start scanning';
      alert('Error during detection: ' + err.message);
      return;
    }

    if (this.#scanning) {
      requestAnimationFrame(() => this.#scanFrame());
    }
  }

  async #startScanning() {
    // Also ensure push permission before scanning
    const pushOk = await this.#ensurePushPermission();
    if (!pushOk) return;

    this.#button.disabled = true;
    this.#resultEl.hidden = true;
    this.#resultEl.textContent = '';

    try {
      if (!this.#detector) {
        await this.#initDetector();
      }

      await this.#startCamera();

      this.#scanning = true;
      this.#button.textContent = 'Scanning…';
      requestAnimationFrame(() => this.#scanFrame());
    } catch (err) {
      console.error(err);
      this.#button.disabled = false;
      this.#button.textContent = 'Start scanning';
      alert(err.message);
    }
  }

  // Use static QR from a URL; update it when value changes
  #renderQR() {
    const value = this.#qrValue || '';
    this.#qrLabel.textContent = value || '(no value set)';

    this.#qrImg.replaceWith(canvas)
  }
}

customElements.define('qr-connect', QRConnect);

export { }