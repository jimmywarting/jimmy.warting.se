import { LitElement, html } from 'https://cdn.jsdelivr.net/gh/lit/dist@3/core/lit-core.min.js'
import styles from './hero.css' with { type: 'css' }
import { ArrowLeftIcon, CloudIcon, CloudOffIcon } from '../icons.js'

class Hero extends LitElement {
	static properties = {
		imageUrl: { type: String },
		title: { type: String },
		subtitle: { type: String },
		showBackButton: { type: Boolean },
		online: { type: Boolean }
	}

	static styles = [styles]

	constructor () {
		super()
		this.imageUrl = ''
		this.title = ''
		this.subtitle = ''
		this.showBackButton = false
		this.online = true

		globalThis.addEventListener('offline', () => {
			this.online = false
		})

		globalThis.addEventListener('online', () => {
			this.online = true
		})
	}

	#handleBackClick () {
		this.dispatchEvent(new CustomEvent('back', { bubbles: true, composed: true }))
	}

	#handleOfflineToggle () {
		// const newOfflineMode = !this.online
		// this.dispatchEvent(new CustomEvent('offline-toggle', {
		// 	bubbles: true,
		// 	composed: true,
		// 	detail: { isOfflineMode: newOfflineMode }
		// }))
	}

	render () {
		const backgroundStyle = this.imageUrl
			? `background-image: linear-gradient(to bottom, #0c0e1d80, #0c0e1d), url('${this.imageUrl}.webp?quality=90');`
			: 'background-color: #1a1a36;'

		const modeClass = this.online ? 'online' : 'offline'
		const modeIcon = this.online ? CloudOffIcon : CloudIcon
		const modeTitle = this.online ? 'Offline-läge (Endast nedladdat)' : 'Online-läge (Alla låtar)'

		return html`
			<div class="hero" style="${backgroundStyle}">
				<div class="hero-header">
					${this.showBackButton
						? html`
							<button class="hero-button" @click=${this.#handleBackClick} title="Tillbaka" aria-label="Tillbaka">
								${ArrowLeftIcon}
							</button>
						`
						: html`<div></div>`
					}
					<slot name="top-right-buttons"></slot>
				</div>

				<div class="hero-content">
					${this.imageUrl
						? html`
							<div class="hero-image-container">
								<img src="${this.imageUrl}.webp?width=150&quality=90" alt="${this.title || ''} omslag">
							</div>
						`
						: ''
					}
					${this.subtitle ? html`<p class="hero-subtitle">${this.subtitle}</p>` : ''}
					${this.title ? html`<h1 class="hero-title">${this.title}</h1>` : ''}

					<div class="hero-slot-content">
						<slot></slot>
					</div>
				</div>
			</div>
		`
	}
}

customElements.define('app-hero', Hero)

export { Hero }
