import { LitElement, html } from 'https://cdn.jsdelivr.net/gh/lit/dist@3/core/lit-core.min.js'
import styles from './settings-dialog.css' with { type: 'css' }
import { XIcon } from '../icons.js'
import { on, get } from '../global-store.js'

const micAccess = await navigator.permissions.query({ name: 'microphone' })

const audioDevices = get('audioDevices', [])
const qualites = [
  {
    "id": 3,
    "name": "High",
    "position": 2,
    "premiumOnly": false,
    "key": "high",
    "default": true,
    "contentFormat": {
      "id": 3,
      "key": "aac",
      "name": "AAC",
      "extension": "mp4",
      "mimeType": "audio/mp4"
    },
    "contentQuality": {
      "id": 4,
      "key": "128k",
      "name": "128 kbit/s",
      "kiloBitrate": 128
    }
  },
  {
    "id": 2,
    "name": "Medium",
    "position": 1,
    "premiumOnly": false,
    "key": "medium",
    "default": false,
    "contentFormat": {
      "id": 6,
      "key": "aac_he",
      "name": "AAC-HE",
      "extension": "mp4",
      "mimeType": "audio/mp4"
    },
    "contentQuality": {
      "id": 2,
      "key": "64k",
      "name": "64 kbit/s",
      "kiloBitrate": 64
    }
  },
  {
    "id": 4,
    "name": "Ultra",
    "position": 3,
    "premiumOnly": false,
    "key": "ultra",
    "default": false,
    "contentFormat": {
      "id": 1,
      "key": "mp3",
      "name": "MP3",
      "extension": "mp3",
      "mimeType": "audio/mpeg"
    },
    "contentQuality": {
      "id": 6,
      "key": "320k",
      "name": "320 kbit/s",
      "kiloBitrate": 320
    }
  }
]


class SettingsDialog extends LitElement {
	static properties = {
		open: { type: Boolean },
		activeTab: { type: String },
		audioDevices: { type: Array },
		settings: { type: Object }
	}

	static styles = [styles]
	#qualities = globalThis.config.qualities.map(q => {
		return {
			value: q.id,
			label: `${q.name} (${q.contentQuality.name} ${q.contentFormat.name})`,
			disabled: q.premiumOnly
		}
	})

	constructor () {
		super()
		this.open = false
		this.activeTab = 'notification'
		this.audioDevices = audioDevices
		this.settings = this.#loadSettings()

		on('audioDevices', v => {
			this.audioDevices = v
		})
	}

	#loadSettings () {
		try {
			const saved = localStorage.getItem('di-4-free-settings')
			return saved ? JSON.parse(saved) : this.#getDefaultSettings()
		} catch (e) {
			console.error('Failed to load settings:', e)
			return this.#getDefaultSettings()
		}
	}

	#getDefaultSettings () {
		return {
			notificationsEnabled: false,
			notifyNewTrack: false,
			inactivityPause: false,
			audioOutput: 'default',
			qualityWifi: 'high',
			qualityMobile: 'medium',
			qualityDownload: 'high',
			maxSongs: '',
			maxHours: '',
			maxSizeGB: '',
			maxSongsPerStation: '',
			ttlDays: '',
			autoReplaceOld: false,
			wifiOnlyDownload: true,
			protectUpvoted: true,
			autoOfflineMode: false
		}
	}

	#saveSettings () {
		try {
			localStorage.setItem('di-4-free-settings', JSON.stringify(this.settings))
		} catch (e) {
			console.error('Failed to save settings:', e)
		}
	}

	updated (changedProperties) {
		if (changedProperties.has('open')) {
			const dialog = this.shadowRoot.querySelector('dialog')
			if (dialog) {
				if (this.open && !dialog.open) {
					dialog.showModal()
				} else if (!this.open && dialog.open) {
					dialog.close()
				}
			}
		}
	}

	#handleClose (e) {
		const dialog = e.target
		const form = dialog.querySelector('form')
		this.open = false
	}

	#handleTabChange (tab) {
		this.activeTab = tab
	}

	firstUpdated () {
		globalThis.settingsDialog = this.shadowRoot.querySelector('dialog')
	}

	#inputChanged (e) {
		const input = e.target
		const { name, type, checked, value } = input

		if (type === 'checkbox') {
			this.settings[name] = checked
		} else if (type === 'number') {
			this.settings[name] = input.valueAsNumber || 0
		} else if (type === 'select-one') {
			this.settings[name] = value
		}
	}

	render () {
		return html`
			<dialog closedby="any" @close=${this.#handleClose}>
				<form method="dialog" @input=${this.#inputChanged}>
					<div class="dialog-header">
						<h2>Inställningar</h2>
						<button class="close-button" type="submit" aria-label="Stäng">
							${XIcon}
						</button>
					</div>

					<div class="dialog-content">
						<nav class="side-menu">
							<button
								type="button"
								class="menu-item ${this.activeTab === 'notification' ? 'active' : ''}"
								@click=${() => this.#handleTabChange('notification')}
							>
								Notifikationer
							</button>
							<button
								type="button"
								class="menu-item ${this.activeTab === 'audio' ? 'active' : ''}"
								@click=${() => this.#handleTabChange('audio')}
							>
								Ljud
							</button>
							<button
								type="button"
								class="menu-item ${this.activeTab === 'storage' ? 'active' : ''}"
								@click=${() => this.#handleTabChange('storage')}
							>
								Lagring
							</button>
							<button
								type="button"
								class="menu-item ${this.activeTab === 'misc' ? 'active' : ''}"
								@click=${() => this.#handleTabChange('misc')}
							>
								Övrigt
							</button>
						</nav>

						<div class="settings-panel">
							${this.#renderActiveTab()}
						</div>
					</div>
				</form>
			</dialog>
		`
	}

	#renderActiveTab () {
		switch (this.activeTab) {
			case 'notification':
				return this.#renderNotificationSettings()
			case 'audio':
				return this.#renderAudioSettings()
			case 'storage':
				return this.#renderStorageSettings()
			case 'misc':
				return this.#renderMiscSettings()
			default:
				return html``
		}
	}

	#renderNotificationSettings () {
		const notificationPermission = Notification.permission
		const notificationsGranted = notificationPermission === 'granted'



		return html`
			<div class="settings-section">
				<h3>Notifikationsinställningar</h3>

				<div class="warning-message" style='display: if( style(--push: "denied"): block; else: none );'>
					<p>Notifikationer är blockerade i din webbläsare. Aktivera dem i webbläsarinställningarna för att använda dessa funktioner.<br>
					Tillstånd ger även möjligheten att synka musik mellan olika enheter</p>
				</div>

				<div class="info-message" style='display: if( style(--push: "prompt"): block; else: none );'>
					<p>Du behöver ge tillstånd för notifikationer för att använda dessa funktioner.<br>
					Tillstånd ger även möjligheten att synka musik mellan olika enheter.</p>
					<button type="button" class="primary-button" @click=${this.#requestNotificationPermission}>
						Begär tillstånd
					</button>
				</div>

				<div class="setting-item ${!notificationsGranted ? 'disabled' : ''}">
					<label>
						<input
							type="checkbox"
							name="notificationsEnabled"
							?checked=${this.settings.notificationsEnabled}
							?disabled=${!notificationsGranted}
						>
						<span>Aktivera notifikationer</span>
					</label>
					<p class="setting-description">Visa systemnotifikationer från appen</p>
				</div>

				<div class="setting-item ${!notificationsGranted ? 'disabled' : ''}">
					<label>
						<input
							type="checkbox"
							name="notifyNewTrack"
							?checked=${this.settings.notifyNewTrack}
							?disabled=${!notificationsGranted}
						>
						<span>Visa när ny låt börjar</span>
					</label>
					<p class="setting-description">Få en notifikation när nästa låt börjar spelas</p>
				</div>

				<div class="setting-item ${!notificationsGranted ? 'disabled' : ''}">
					<label>
						<input
							type="checkbox"
							name="inactivityPause"
							?checked=${this.settings.inactivityPause}
							?disabled=${!notificationsGranted}
						>
						<span>Pausa vid inaktivitet</span>
					</label>
					<p class="setting-description">Visa "Är du där?" och pausa spelaren om ingen interaktion sker</p>
				</div>
			</div>
		`
	}

	#requestMicrophonePermission () {
		navigator.permissions.request({ name: 'microphone' })
	}

	#renderAudioSettings () {
		return html`
			<div class="settings-section">
				<h3>Ljudinställningar</h3>

				<div class="setting-item">
					<label for="audioOutput">Ljudutgång</label>

					<div class="warning-message" style='display: if( style(--microphone: "denied"): block; else: none );'>
						<p>Mikrofon är blockerade i din webbläsare. Aktivera dem i webbläsarinställningarna för att låta oss lista dina ljudenheter.<br>
					</div>

					<div class="info-message" style='display: if( style(--microphone: "prompt"): block; else: none );'>
						<p>Du behöver ge tillstånd för mikrofonen för kunna lista dina ljudenheter och kunna byta ljudutgång.<br>
						Mikrofonen används inte för att lyssna på något.</p>
						<button type="button" class="primary-button" @click=${this.#requestMicrophonePermission}>
							Begär tillstånd
						</button>
					</div>

					<select id="audioOutput" name="audioOutput" .value=${this.settings.audioOutput}>
						${this.audioDevices.map(device => html`
							<option value="${device.deviceId}" ?selected=${this.settings.audioOutput === device.deviceId}>
								${device.label || `Enhet ${device.deviceId.slice(0, 8)}`}
							</option>
						`)}
					</select>
					<p class="setting-description">Välj vilken enhet som ska användas för uppspelning</p>
				</div>

				<div class="setting-item">
					<label for="qualityWifi">Ljudkvalitet (WiFi)</label>
					<select id="qualityWifi" name="qualityWifi" .value=${this.settings.qualityWifi}>
						${this.#qualities.map(q => html`
							<option
								value="${q.value}"
								?selected=${this.settings.qualityWifi === q.value}
								?disabled=${q.disabled}
							>
								${q.label} ${q.disabled ? '(Premium endast)' : ''}
							</option>
						`)}
					</select>
					<p class="setting-description">Streaming kvalite när du är ansluten till WiFi</p>
				</div>

				<div class="setting-item disabled">
					<label for="qualityMobile">Ljudkvalitet (Mobildata)</label>
					<select id="qualityMobile" disabled name="qualityMobile" .value=${this.settings.qualityMobile}>
						${this.#qualities.map(q => html`
							<option
								value="${q.value}"
								?selected=${this.settings.qualityWifi === q.value}
								?disabled=${q.disabled}
							>
								${q.label} ${q.disabled ? '(Premium endast)' : ''}
							</option>
						`)}
					</select>
					<p class="setting-description">Streaming kvalite när du använder mobildata</p>
				</div>

				<div class="setting-item disabled">
					<label for="qualityDownload">Ljudkvalitet (Nedladdning)</label>
					<select id="qualityDownload" disabled name="qualityDownload" .value=${this.settings.qualityDownload}>
						<option value="low" ?selected=${this.settings.qualityDownload === 'low'}>Låg (64 kbps)</option>
						<option value="medium" ?selected=${this.settings.qualityDownload === 'medium'}>Medel (128 kbps)</option>
						<option value="high" ?selected=${this.settings.qualityDownload === 'high'}>Hög (320 kbps)</option>
					</select>
					<p class="setting-description">Kvalitet för nedladdade låtar</p>
				</div>
			</div>
		`
	}

	#renderStorageSettings () {
		return html`
			<div class="settings-section">
				<h3>Lagringsinställningar</h3>

				<div class="setting-item">
					<label for="maxSongs">Max antal låtar totalt</label>
					<input
						type="number"
						id="maxSongs"
						name="maxSongs"
						min="0"
						.value=${this.settings.maxSongs}
						placeholder="Obegränsat"
					>
					<p class="setting-description">Maximalt antal låtar att ladda ner totalt</p>
				</div>

				<div class="setting-item">
					<label for="maxHours">Max antal timmar totalt</label>
					<input
						type="number"
						id="maxHours"
						name="maxHours"
						min="0"
						.value=${this.settings.maxHours}
						placeholder="Obegränsat"
					>
					<p class="setting-description">Maximalt antal timmar musik att ladda ner</p>
				</div>

				<div class="setting-item">
					<label for="maxSizeGB">Max lagringsstorlek (GB)</label>
					<input
						type="number"
						id="maxSizeGB"
						name="maxSizeGB"
						min="0"
						step="0.1"
						.value=${this.settings.maxSizeGB}
						placeholder="Obegränsat"
					>
					<p class="setting-description">Maximal lagringsstorlek för nedladdade låtar</p>
				</div>

				<div class="setting-item">
					<label for="maxSongsPerStation">Max låtar per station</label>
					<input
						type="number"
						id="maxSongsPerStation"
						name="maxSongsPerStation"
						min="0"
						.value=${this.settings.maxSongsPerStation}
						placeholder="Obegränsat"
					>
					<p class="setting-description">Maximalt antal låtar per radiostation</p>
				</div>

				<div class="setting-item">
					<label for="ttlDays">Tid att leva (dagar)</label>
					<input
						type="number"
						id="ttlDays"
						name="ttlDays"
						min="0"
						.value=${this.settings.ttlDays}
						placeholder="Aldrig"
					>
					<p class="setting-description">Radera gamla låtar efter X dagar</p>
				</div>

				<div class="setting-item">
					<label>
						<input
							type="checkbox"
							name="autoReplaceOld"
							?checked=${this.settings.autoReplaceOld}
						>
						<span>Ersätt gamla låtar automatiskt</span>
					</label>
					<p class="setting-description">Ersätt gamla låtar med nya när lagringsgränsen nås</p>
				</div>

				<div class="setting-item">
					<label>
						<input
							type="checkbox"
							name="wifiOnlyDownload"
							?checked=${this.settings.wifiOnlyDownload}
						>
						<span>Ladda endast ner via WiFi</span>
					</label>
					<p class="setting-description">Förhindra nedladdningar när du använder mobildata</p>
				</div>

				<div class="setting-item">
					<label>
						<input
							type="checkbox"
							name="protectUpvoted"
							?checked=${this.settings.protectUpvoted}
						>
						<span>Skydda gillade låtar</span>
					</label>
					<p class="setting-description">Radera aldrig låtar som du har gillat</p>
				</div>
			</div>
		`
	}

	#renderMiscSettings () {
		return html`
			<div class="settings-section">
				<h3>Övriga inställningar</h3>

				<div class="setting-item">
					<label>
						<input
							type="checkbox"
							name="autoOfflineMode"
							?checked=${this.settings.autoOfflineMode}
						>
						<span>Automatisk offline-läge</span>
					</label>
					<p class="setting-description">Byt automatiskt till offline-läge när du inte är ansluten till WiFi</p>
				</div>
			</div>
		`
	}

	// Event handler
	async #requestNotificationPermission () {
		const permission = await Notification.requestPermission()
		if (permission === 'granted') {
			this.settings.notificationsEnabled = true
			this.#saveSettings()
		}
		this.requestUpdate()
	}
}

customElements.define('settings-dialog', SettingsDialog)

export { SettingsDialog }
