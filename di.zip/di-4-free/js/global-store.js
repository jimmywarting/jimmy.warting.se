const state = Object.create(null)
const bc = new BroadcastChannel('state')
globalThis.state = state
bc.addEventListener('message', evt => {
  const [k, v] = evt.data
  set(k, v, null)
})

function set (k, v, c = bc) {
  const b = (state[k] ??= { l: [], v: undefined })
  if (b.v === v) return
  b.v = v
  b.l.forEach(f => f(v, k))
  c?.postMessage([k, v])
}

function on (k, callback) {
  const b = (state[k] ??= { l: [], v: undefined })
  b.l.push(callback)
}

function get (k, def) {
  const b = (state[k] ??= { l: [], v: undefined })
  return b.v ?? def
}

if (typeof document !== 'undefined') {
  const globalStyle = document.documentElement.style
  const setGlobalListeners = (v, k) => {
    globalStyle.setProperty(`--${k}`, v)
  }

  `currentTimeFormatted
  currentTime
  progress
  playbackState
  push
  microphone
  durationFormatted
  currentTrackTitle
  duration`
  .split('\n').forEach(k => {
    on(k.trim(), setGlobalListeners)
  })

  const getAudioOutputDevices = async () => {
    let devices = await navigator.mediaDevices.enumerateDevices()
    devices = devices.filter(device => device.kind === 'audiooutput')
      .map(device => device.toJSON())
    set('audioDevices', devices)
  }

  getAudioOutputDevices()

  on('microphone', getAudioOutputDevices)
}

function importState (keyValues = []) {
  keyValues.forEach(([k, v]) => {
    set(k, v, null)
  })
}

export {
  state,
  set,
  importState,
  get,
  on
}