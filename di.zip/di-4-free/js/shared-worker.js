let state, set
async function init () {
  await import('./polyfills.js')
  await import('./audioaddict.js')
  const mod = await import('./global-store.js')
  state = mod.state
  set = mod.set

  const pushPermission = await navigator.permissions.request({
    name: 'push',
    userVisibleOnly: true
  })

  const micAccess = await navigator.permissions.query({
    name: 'microphone'
  })

  pushPermission.onchange = () => set('push', JSON.stringify(pushPermission.state))
  micAccess.onchange = () => set('microphone', JSON.stringify(micAccess.state))

  set('push', JSON.stringify(pushPermission.state))
  set('microphone', JSON.stringify(micAccess.state))
}

globalThis.onconnect = async (event) => {
  const p = init()
  init = () => {}
  await p
  const port = event.ports[0]

  port.onmessage = (e) => {
    const writable = e.data.config.getWriter()
    writable.write({
        ...globalThis.config,
        state: Object.entries(state).map(([k,v]) => [k,v.v])
    })
  }
}