const mitm = 'https://jimmywarting.github.io/StreamSaver.js/mitm.html'

/**
 * create a hidden iframe and append it to the DOM (body)
 *
 * @param  {string} src page to load
 * @return {HTMLIFrameElement} page to load
 */
function makeIframe (src) {
  const iframe = document.createElement('iframe')
  iframe.hidden = true
  iframe.src = src
  iframe.loaded = false
  iframe.name = 'iframe'
  iframe.postMessage = (...args) => iframe.contentWindow.postMessage(...args)
  iframe.addEventListener('load', () => {
    iframe.loaded = true
  }, { once: true })
  document.body.appendChild(iframe)
  return iframe
}

/**
 * @param  {string} filename filename that should be used
 * @return {WritableStream<Uint8Array>}
 */
function download (filename, headers = {}) {
  const channel = new MessageChannel()
  const ts = new TransformStream()
  const readableStream = ts.readable
  const mitmTransporter = makeIframe(mitm)

  const response = {
    transferringReadable: true,
    pathname: Math.random().toString().slice(-6) + '/' + filename,
    headers: {
      'Content-Type': 'audio/mpeg',
      'Transfer-Encoding': 'chunked',
      'Connection': 'keep-alive'
    }
  }

  const args = [ response, '*', [ channel.port2 ] ]

  channel.port1.postMessage({ readableStream }, [ readableStream ])
  channel.port1.onmessage = evt => {
    // Service worker sent us a link that we should open.
    if (evt.data.download) {
      // We never remove this iframes b/c it can interrupt saving
      console.log(evt.data.download)
      const audio = new Audio(evt.data.download)
      audio.autoplay = true
      audio.controls = true
      document.body.appendChild(audio)
      audio.play()
      // makeIframe(evt.data.download)
    } else if (evt.data.abort) {
      chunks = []
      channel.port1.postMessage('abort') //send back so controller is aborted
      channel.port1.onmessage = null
      channel.port1.close()
      channel.port2.close()
      channel = null
    }
  }

  if (mitmTransporter.loaded) {
    mitmTransporter.postMessage(...args)
  } else {
    mitmTransporter.addEventListener('load', () => {
      mitmTransporter.postMessage(...args)
    }, { once: true })
  }

  return ts.writable
}

const response = await fetch('http://prem1.di.fm/chillout_hi?9564836dd232258')
response.body.pipeTo(download('filename.txt', response.headers))

export {
  download
}