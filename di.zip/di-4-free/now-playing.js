import http from 'node:http'

const PORT = 3000

const channels = []

/* -------------------------
   SSE server
-------------------------- */

const server = http.createServer((req, res) => {
  if (req.url === '/stream') {
    res.writeHead(200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      Connection: 'keep-alive'
    })

    res.write('event: connected\ndata: connected\n\n')
    clients.add(res)

    req.on('close', () => {
      clients.delete(res)
    })

    return
  }

  res.writeHead(404)
  res.end()
})

server.listen(PORT, () => {
  console.log(`SSE server running on http://localhost:${PORT}`)
})

/* -------------------------
   SSE broadcast
-------------------------- */

function broadcast (event, data) {
  const payload =
    `event: ${event}\n` +
    `data: ${JSON.stringify(data)}\n\n`

  for (const client of clients) {
    client.write(payload)
  }
}

/* -------------------------
   Bootstrap
-------------------------- */

let currentData = null

async function fetchCurrentlyPlayingFromAllNetworks () {
  const networksRes = await fetch('https://api.audioaddict.com/v1/networks', {
    cache: 'no-store',
    headers: {
      'Cache-Control': 'no-cache, no-store, max-age=0, must-revalidate',
      'Pragma': 'no-cache',
      'Expires': '0'
    }
  })
  const networks = await networksRes.json()

  const now = new Date()

  const allChannels = await Promise.all(networks.map(async network => {
      const url = `https://api.audioaddict.com/v1/${network.key}/currently_playing?t=${Date.now()}`
      const res = await fetch(url, {
        cache: 'no-store',
        headers: {
          'Cache-Control': 'no-cache, no-store, max-age=0, must-revalidate',
          'Pragma': 'no-cache',
          'Expires': '0'
        }
      })
    const channels = await res.json()

    return channels.map(channel => {
      let endDate
      let trackId = null

      if (channel.track) {
        const start = new Date(channel.track.start_time)
        const durationMs = channel.track.duration * 1000
        endDate = new Date(start.getTime() + durationMs)
      } else {
        endDate = new Date(now.getTime() + 30 * 1000)
      }

      if (endDate <= now) {
        endDate = new Date(Date.now() + 2000)
      }

      if (channel.track) trackId = channel.track.id

      return {
        channelId: channel.channel_id,
        trackId,
        endDate,
        networkKey: network.key,
        get timeLeft() {
          return Math.max(0, this.endDate - new Date())
        }
      }
    })
  }))

  const flatList = allChannels.flat()
  flatList.sort((a, b) => a.endDate - b.endDate)

  currentData = { list: flatList }
  return currentData
}

function scheduleNextTrackEnd () {
  if (!currentData || !currentData.list.length) return

  const c = currentData.list.shift()
  currentData.list.sort((a, b) => a.endDate - b.endDate)

  fetch(`https://api.audioaddict.com/v1/${c.networkKey}/currently_playing/channel/${c.channelId}?t=${Date.now()}`, {
    cache: 'no-store',
    headers: {
      'Cache-Control': 'no-cache, no-store, max-age=0, must-revalidate',
      'Pragma': 'no-cache',
      'Expires': '0'
    }
  })
  .then(res => res.json())
  .then(channel => {
    if (!channel.track) {
      c.trackId = null
      c.endDate = new Date(Date.now() + 30000)
      currentData.list.push(c)
      currentData.list.sort((a, b) => a.endDate - b.endDate)
      return
    }

    if (channel.track.trackId === c.trackId) {
      console.log('same')
      currentData.list.push(c)
      currentData.list.sort((a, b) => a.endDate - b.endDate)
      return
    }

    console.log('newSong', { channel: c.channelId, ended: c.trackId, started: channel.track.id })

    c.trackId = channel.track.id
    const start = new Date(channel.track.start_time)
    const ms = new Date().getMilliseconds()
    start.setMilliseconds(Math.max(0, ms - 20))
    const durationMs = channel.track.duration * 1000
    c.endDate = new Date(start.getTime() + durationMs)

    currentData.list.push(c)
    currentData.list.sort((a, b) => a.endDate - b.endDate)
  })

  const nextTimeout = currentData.list[0].timeLeft
  setTimeout(scheduleNextTrackEnd, nextTimeout)
}

async function main () {
  await fetchCurrentlyPlayingFromAllNetworks()
  scheduleNextTrackEnd()
}

main()