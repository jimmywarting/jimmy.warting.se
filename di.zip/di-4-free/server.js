import http from 'node:http'
import fs from 'node:fs/promises'
import { spawn } from 'node:child_process'

const PORT = 8080
const HOST = '0.0.0.0'
const mimeTypes = {
  '.html': 'text/html',
  '.js': 'application/javascript',
  '.css': 'text/css',
  '.json': 'application/json',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.gif': 'image/gif',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.zip': 'application/zip'
}


const server = http.createServer((req, res) => {
  // static file server
  let filePath = `.${req.url}`

  if (filePath === './') {
    filePath = './lit.html'
  }

  // enable CORS
  res.setHeader('Access-Control-Allow-Origin', res.getHeader('Origin') || '*')
  res.setHeader('Access-Control-Allow-Methods', res.getHeader('Access-Control-Request-Method') || 'GET, OPTIONS, HEAD')
  res.setHeader('Access-Control-Allow-Headers', '*')

  if (filePath === './Arkiv.zip') {
    // create a zip file with cmd process
    res.statusCode = 200
    res.setHeader('Content-Disposition', 'attachment; filename="Arkiv.zip"')
    res.setHeader('Content-Type', 'application/zip')

    // -r for recursive
    // - for file output to stdout
    // ./ for current working directory
    const zipProcess = spawn('zip', ['-r', '-', './'])
    zipProcess.stdout.pipe(res)
    zipProcess.on('error', (err) => {
      res.writeHead(500)
      res.end('Server error: ' + err.message)
    })
    return
  }

  fs.readFile(filePath)
    .then(data => {
      res.writeHead(200, { 'Content-Type': mimeTypes[filePath.substring(filePath.lastIndexOf('.'))] || 'application/octet-stream' } )
      res.end(data)
    })
    .catch(err => {
      res.writeHead(404)
      res.end('Not found')
    })
})

server.listen(PORT, HOST, () => {
  console.log(`Server running at http://${HOST}:${PORT}/`)
})