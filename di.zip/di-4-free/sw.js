/// <reference no-default-lib="true"/>
/// <reference lib="esnext" />
/// <reference lib="WebWorker" />
const sw = /** @type {ServiceWorkerGlobalScope & typeof globalThis} */ (globalThis)

const cachedV1 = caches.open('v1')

async function processImage (res, width, quality = 0.9) {
  const originalBlob = await res.blob()
  console.log({originalBlob})
  const bitmap = await createImageBitmap(originalBlob)

  const targetWidth = width ? Math.min(Number(width), bitmap.width) : bitmap.width
  const targetHeight = targetWidth * (bitmap.height / bitmap.width)

  const canvas = new OffscreenCanvas(targetWidth, targetHeight)
  const ctx = canvas.getContext('2d')
  ctx.drawImage(bitmap, 0, 0, targetWidth, targetHeight)

  const webpBlob = await canvas.convertToBlob({ type: 'image/webp', quality: Number(quality) })
  console.log({ originalSize: originalBlob.size, webpSize: webpBlob.size })
  // Returnera en Response med den blob som är minst
  return new Response(webpBlob.size < originalBlob.size ? webpBlob : originalBlob)
}

async function cacheFirst (req) {
  const cache = await cachedV1
  const cached = await cache.match(req.url)
  if (cached) return cached

  let res

  if (req.url.match(/\.(png|jpe?g|gif|webp)/i)) {
    res = await fetch(req.url)
    const url = new URL(req.url)
    const params = Object.fromEntries(url.searchParams)
    res = await processImage(res, params.width, params.quality)
  } else {
    res = await fetch(req)
  }

  await cache.put(req.url, res.clone())
  return res
}

const cacheable = [
  // 'localwebcontainer.com',
  'jsdelivr.net',
  // 'cdn.audioaddict.com',
  'unpkg.com',
  'fonts.googleapis.com'
]

router.get(
  ctx => ctx.url.pathname === '/funkis-test',
  ctx => new Response('funkis works!')
)

router.get(
  ctx => cacheable.some(host => ctx.url.host.includes(host)),
  ctx => cacheFirst(ctx.request)
)

globalThis.addEventListener('message', evt => {
  if (evt.data.action === 'open-existing-client') {
    evt.waitUntil((async () => {
      const client = await sw.clients.get(evt.data.id)
      client.focus()
      client.postMessage({ action: 'focus' }, evt.ports)
    })())
  }
})

const bc = new BroadcastChannel('push-messages')
globalThis.addEventListener('push', evt => {
  const data = evt.data.json()
  bc.postMessage(data)
})

globalThis.addEventListener('onperiodicsync', evt => {
  // console.log('Periodic Syncing messages in the background...', evt)
})

globalThis.addEventListener('sync', evt => {
  console.log('Syncing messages in the background...', evt)
})

console.log('hej från sw.js')
