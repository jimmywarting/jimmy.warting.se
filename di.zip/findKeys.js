import fs from 'node:fs/promises'

const GITHUB_TOKEN = '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'

if (!GITHUB_TOKEN) {
  throw new Error('Sätt GITHUB_TOKEN i env')
}

const HEADERS = {
  Authorization: `Bearer ${GITHUB_TOKEN}`,
  Accept: 'application/vnd.github+json'
}

const HOSTS = [
  'prem1.di.fm',
  'prem2.di.fm',
  'prem3.di.fm',
  'prem4.di.fm'
]

const STREAM_REGEX =
  /http:\/\/prem(1|2|3|4)\.di\.fm\/[^/\s]+_hi\?[0-9a-f]+/g

async function searchCode (query, page = 1) {
  const url =
    `https://api.github.com/search/code?q=${encodeURIComponent(query)}&per_page=100&page=${page}`

  const res = await fetch(url, { headers: HEADERS })


  const json = await res.json()
  return json
}

async function fetchFile (url) {
  const res = await fetch(url)

  return res.text()
}

async function main () {
  const results = new Set()

  for (const host of HOSTS) {
    let page = 1

    while (true) {
      const data = await searchCode(host, page)
      console.log(data)

      for (const item of data.items || []) {
        if (!item.download_url) continue
        const content = await fetchFile(item.download_url)
        if (!content) continue

        const matches = content.match(STREAM_REGEX)
        if (!matches) continue

        for (const match of matches) {
          results.add(match)
        }
      }

      if (data.items.length < 100) break
      page++
    }
  }

  const sorted = [...results].sort()

  await fs.writeFile('di-streams.txt', sorted.join('\n'))

  console.log(`Hittade ${sorted.length} unika streams`)
}

main()
