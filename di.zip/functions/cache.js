
async function onRequestGet(c) {
  const cache = await caches.open('v1')
  const url = c.url.searchParams.get('url')
  return cache.match(url).then(res => {
    if (res) return res
    return fetch(url, { mode: 'no-cors' }).then(res => {
      cache.put(url, res.clone())
      return res
    })
  })
}

globalThis.addEventListener('fetch', async event => {
  const url = event.request.url
  if (url.startsWith('https://cdn.jsdelivr.net/')) {
    const cache = await caches.open('v1')
    const res = await cache.match(url)
    if (!res) cache.add(url)
  }
})

export {
  onRequestGet
}
