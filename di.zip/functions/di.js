async function onRequestGet() {
  const response = await fetch('https://www.di.fm/')
  const text = await response.text()
  const config = text.match(/di\.app\.start\((.*)\)/)[1]
  return Response.json(config)
}

export {
  onRequestGet
}
