import { formatTime } from './utils.js'
import { set, on } from './global-store.js'

globalThis.currentTrack = null

const sw = await navigator.serviceWorker.ready
const notifications = await sw.getNotifications()
const session = navigator.mediaSession

let notification
let requestedUpdate

function updateSeekBarBackground () {
  const duration = audio.duration
  const currentTime = audio.currentTime

	if (!duration || isNaN(duration)) return

  const buffered = audio.buffered
  const playedPercentage = (currentTime / duration) * 100
  const finalGradientParts = []
  let currentOffset = 0
  let totalBufferedSeconds = 0

  if (playedPercentage > 0) {
    finalGradientParts.push(`var(--offline-color) 0%`, `var(--offline-color) ${playedPercentage}%`)
    currentOffset = playedPercentage;
  }

  for (let i = 0; i < buffered.length; i++) {
    const start = buffered.start(i)
    const end = buffered.end(i)

    totalBufferedSeconds += (end - start)

    const startPercentage = (start / duration) * 100
    const endPercentage = (end / duration) * 100

    if (startPercentage > currentOffset) {
      finalGradientParts.push(`#535557 ${currentOffset}%`, `#535557 ${startPercentage}%`)
    }

    const greenStart = Math.max(startPercentage, playedPercentage)
    if (endPercentage > greenStart) {
      finalGradientParts.push(`var(--buffered-color) ${greenStart}%`, `var(--buffered-color) ${endPercentage}%`)
    }
    currentOffset = Math.max(currentOffset, endPercentage)
  }

  if (currentOffset < 100) {
    finalGradientParts.push(`#535557 ${currentOffset}%`, `#535557 100%`)
  }

	set('progress-bar-background', `linear-gradient(to right, ${finalGradientParts.join(", ")})`)

  // const audioFileSizeMB = currentTrack.metadata.size
  // const downloadedMB = (totalBufferedSeconds / duration) * audioFileSizeMB
  // downloadedLabel.textContent = `${downloadedMB.toFixed(2)} MB`
}

function updatePositionState () {
	session.setPositionState({
		duration: audio.duration,
		playbackRate: audio.playbackRate,
		position: audio.currentTime
	})
	session.playbackState = audio.paused ? 'paused' : 'playing'
	set('playbackState', `"${session.playbackState}"`)
}

session.setActionHandler('enterpictureinpicture', () => {
	console.log('enterpictureinpicture action received')
	// pip()
})

session.setActionHandler('previoustrack', () => audioPlayer.prev())
session.setActionHandler('nexttrack', () => audioPlayer.next())
session.setActionHandler('play', () => audioPlayer.togglePlayPause())
session.setActionHandler('pause', () => audioPlayer.togglePlayPause())
session.setActionHandler('stop', () => {
	audio.pause()
	updatePositionState()
})

session.setActionHandler('seekto', evt => {
	evt.seekTime && (audio.currentTime = evt.seekTime)
	updatePositionState()
})

session.setActionHandler('seekbackward', evt => {
	if (evt.seekOffset) {
		audio.currentTime = Math.max(0, audio.currentTime - evt.seekOffset)
	}
	updatePositionState()
})

session.setActionHandler('seekforward', evt => {
	if (evt.seekOffset) {
		audio.currentTime = Math.min(audio.duration, audio.currentTime + evt.seekOffset)
	}
	updatePositionState()
})

/**
 * Background audio player module.
 * Manages the Audio element, playlist, and current track state.
 * Can be imported and used by any component that needs player state.
 */
const audio = globalThis.audio = new Audio()
const progressBar = document.createElement('input')
const bc = new BroadcastChannel('state')
const timeDisplay = document.createElement('span')
const divider = document.createElement('span')

divider.className = 'divider'
timeDisplay.className = 'reaction'
timeDisplay.append(divider)

progressBar.type = 'range'
progressBar.step = 'any'
progressBar.id = 'progress-bar'

audio.crossorigin = 'anonymous'

//
// Bind audio events to update UI
//

on('progress-bar-background', v => progressBar.style.background = v)
on('currentTime', v => progressBar.value = v)
on('duration', v => progressBar.max = v)

audio.addEventListener('timeupdate', () => {
	const t = audio.currentTime
	set('currentTime', t)
	set('currentTimeFormatted', `"${formatTime(t)}"`)
	set('progress', (t / audio.duration) * 100 + '%')
	updateSeekBarBackground()
})

audio.addEventListener('loadedmetadata', () => {
	set('duration', audio.duration)
	set('durationFormatted', `"${formatTime(audio.duration)}"`)
	console.log('durationFormatted')
  updatePositionState()
})

audio.addEventListener('play', async () => {
	const img = currentTrack.duration === Infinity
		? { url: currentTrack.images.default.url }
		: await currentTrack.getImage()

	const src = img.url

	session.metadata = new MediaMetadata({
		title: currentTrack.displayTitle,
		artist: currentTrack.displayArtist,
		artwork: [{ src }]
	})
	session.playbackState = 'playing'

	if (Notification.permission === 'granted') {
		notification?.close()

		notifications.forEach(n => {
			if (n.tag === 'Now Playing') {
				n.close()
			}
		})
		notifications.length = 0

		notification = await sw.showNotification('Nu spelas:', {
			body: currentTrack.displayTitle + ' av ' + currentTrack.displayArtist,
			icon: src,
			image: src,
			silent: true,
			actions: [
				{ action: 'upvote', title: '👍 Gillade förra låten' },
				{ action: 'downvote', title: '👎 Gillade inte förra låten' }
			]
		})
	}
})

const mediaEvents = [
  'abort', 'canplay', 'canplaythrough', 'durationchange', 'emptied',
  'ended', 'error', 'loadeddata', 'loadedmetadata', 'loadstart',
  'pause', 'play', 'playing', 'progress', 'ratechange', 'seeked',
  'seeking', 'stalled', 'suspend', 'waiting', 'volumechange',

	// 'timeupdate' is handled separately above
	// this would call requestUpdate too often and cause performance issues
]
mediaEvents.forEach(eventType => {
	audio.addEventListener(eventType, () => {
		document.hidden ? console.log(requestedUpdate = true) : playerUI.requestUpdate()
	})
})

addEventListener('visibilitychange', () => {
  if (!document.hidden && requestedUpdate) {
    requestedUpdate = false
    playerUI.requestUpdate()
  }
})

//
// Bind UI to update audio
//
progressBar.addEventListener('input', () => {
  audio.currentTime = progressBar.value
})


class AudioPlayer extends EventTarget {

	components = { timeDisplay, progressBar }

	constructor () {
		super()

		this._playlist = []
		this._currentIndex = -1
		this._isMuted = false

		audio.addEventListener('ended', () => {
			this.next()
		})
	}

	get playlist () {
		return this._playlist
	}

	get currentIndex () {
		return this._currentIndex
	}

	/**
	 * Set the playlist
	 * @param {Array} tracks - Array of track objects
	 */
	setPlaylist (tracks) {
		this._playlist = tracks
	}

	/**
	 * Play a specific track
	 * @param {Track} track - Track object to play
	 */
	async playTrack (track) {
		// Find index in playlist
		const index = this._playlist.findIndex(t => t.trackId === track.trackId)
		this._currentIndex = index >= 0 ? index : -1

		currentTrack = track

		set('currentTrack', track)
		set('currentTrackTitle', `"${track.track}"`)

		if (track.duration === Infinity) {
			audio.src = `http://prem1.di.fm/${track.channel.key}_hi?${config.listenerKey}`

			// const mediaSource = new MediaSource()
			// audio.src = URL.createObjectURL(mediaSource)

			// mediaSource.addEventListener('sourceopen', async () => {
			// 	const mime = 'audio/mpeg'
			// 	const sourceBuffer = mediaSource.addSourceBuffer(mime)
			// 	const res = await fetch(`http://prem1.di.fm/${track.channel.key}_hi?${config.listenerKey}`)

			// 	for await (const chunk of res.body) {
			// 		await appendBuffer(sourceBuffer, chunk)
			// 	}
			// })

			// return audio.play()
		} else if (track.metadata?.fileHandle) {
			const file = await track.metadata.fileHandle.getFile()
			audio.src = URL.createObjectURL(file)
		} else if (track.asset) {
			const asset = await track.asset
			audio.src = asset.url
		}

		this.dispatchEvent(new CustomEvent('trackchange', {
			detail: { track, index: this._currentIndex }
		}))

		await audio.play()
	}

	/**
	 * Play/pause toggle
	 */
	togglePlayPause = () => {
		audio.paused ? audio.play() : audio.pause()
		updatePositionState()
	}

	/**
	 * Skip to next track in playlist
	 */
	next () {
		if (this._playlist.length === 0) return

		const nextIndex = this._currentIndex >= this._playlist.length - 1
			? 0
			: this._currentIndex + 1

		this.playTrack(this._playlist[nextIndex])
	}

	/**
	 * Skip to previous track in playlist
	 */
	prev () {
		if (this._playlist.length === 0) return

		const prevIndex = this._currentIndex <= 0
			? this._playlist.length - 1
			: this._currentIndex - 1

		this.playTrack(this._playlist[prevIndex])
	}
}

// Export a singleton instance
const audioPlayer = new AudioPlayer()

export { audioPlayer, audio }

function appendBuffer (sourceBuffer, chunk) {
	return new Promise(resolve => {
		if (!sourceBuffer.updating) {
			sourceBuffer.appendBuffer(chunk)
			sourceBuffer.addEventListener('updateend', resolve, { once: true })
		}
	})
}
