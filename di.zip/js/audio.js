const audio = new Audio()
audio.preload = 'auto'
audio.crossOrigin = 'anonymous'

const playlist = {
  tracks: [],
  currentTrack: null,
}

export { audio, playlist }