import { makeDictionary, getJson, pick, postJson, call, bytesToCdnUrl } from './utils.js'
import kv from 'https://localwebcontainer.com/clientmyadmin/shared/kv.js'

let config = await kv('get', 'config')

if (!config) {
	const networks = await getJson('https://api.audioaddict.com/v1/networks')
	const channelMap = {}
	const q = await Promise.all([
		postJson(
			`https://api.audioaddict.com/v1/${networks[0].key}/member_sessions`,
			{ member_session: { unregistered: 'true' } },
			{
				'content-type': 'application/json',
				authorization: 'Basic bW9iaWxlOmFwcHM='
			}
		),
		getJson(`https://api.audioaddict.com/v1/${networks[0].key}/qualities`),
		Promise.all(networks.map(network =>
			getJson(`https://api.audioaddict.com/v1/${network.key}/channel_filters`)
		)).then(data => {
			const filterPicker = pick('position,networkId,name,key,images,id,descriptionText,descriptionTitle,channels'.split(','))
			const channelPicker = pick('assetUrl,bannerUrl,description,descriptionLong,descriptionShort,id,images,key,name,networkId'.split(','))

			const filters = data.flat().map(filter => {
				const ids = filter.channels.map(c => {
					channelMap[c.id] ??= channelPicker(c)
					return c.id
				})

				filter.channels = ids

				return filterPicker(filter)
			})

			filters.sort((a, b) => a.position - b.position)
			filters.forEach(f => delete f.position)

			return filters
		})
	])

	config = {
		networks,
		session: q[0],
		qualities: q[1],
		filters: q[2],
		channels: Object.values(channelMap)
	}

	// Promise.all(config.channels.map(async channel => {
	// 	const url = bytesToCdnUrl(channel.images.square)
	// 	const response = await fetch(url)
	// 	const blob = await response.file({ name: channel.name + '.png' })
	// 	channel.images.squareBlob = await blob.convertToImage('webp', .9)
	// 	channel.images.squareBlobThumbnail = await blob.convertToImage('webp', .9, 150)
	// }))

	const sortingOptions = [
		{
			id: 'size',
			label: 'Storlek',
			checked: false,
			order: 'Stigande'
		},
		{
			id: 'displayTitle',
			label: 'Namn',
			checked: false,
			order: 'Stigande'
		},
		{
			id: 'displayArtist',
			label: 'Artist',
			checked: false,
			order: 'Stigande'
		},
		{
			id: 'album',
			label: 'Album',
			checked: false,
			order: 'Stigande'
		},
		{
			id: 'duration',
			label: 'Längd',
			checked: false,
			order: 'Stigande'
		},
		{
			id: 'rating',
			label: 'Betyg',
			checked: false,
			order: 'Stigande'
		},
		{
			id: 'PCNT',
			label: 'Antal spelningar',
			checked: true,
			order: 'Stigande'
		},
		{
			id: 'randomness',
			label: 'Slumpa',
			checked: true,
			order: 'Lägg till ny'
		},
		{
			id: 'lastplayed',
			label: 'Senast spelad',
			checked: true,
			order: 'Fallande'
		},
		{
			id: 'reaction',
			label: 'Reaktion',
			checked: false,
			order: 'Stigande'
		},
		{
			id: 'fileHandle',
			label: 'Nedladdad',
			checked: false,
			order: 'Stigande'
		},
		{
			id: 'cached',
			label: 'temporärt cachad',
			checked: false,
			order: 'Stigande'
		}
	]

	await kv('put', config, 'config')
}

config.networks.forEach(n => {
	n.name = n.name
		.replace(/\.com/i, '')
		.toLowerCase()
		.replace('radio', 'Radio')
		.replace(/./, char => char.toUpperCase())
})

// listener keys that works:
// 036aa6df146c7b1d
// 20a1d1bf879e76
// 780a4f0bfb95c977ceab43a2
// 9564836dd232258
// 6a40af94924ae467
// https://github.com/search?q=%2Fhttp%3A%5C%2F%5C%2Fprem%281%7C2%7C3%7C4%29%5C.di%5C.fm%5C%2F%5B%5E%5C%2F%5Cs%5D%2B_hi%5C%3F%5B0-9a-f%5D%2B%2F&type=code
// keys = [...new Set(document.body.innerText.match(/http:\/\/prem(1|2|3|4)\.di\.fm\/[^\/\s]+_hi\?[0-9a-f]+/g).map(e => e.split('?')[1]))]

const listenerKey = '9564836dd232258' // https://github.com/alexjulien/DIfm_pls
config.listenerKey = listenerKey
globalThis.config = config

class AudioAddict {
	// voteUp (track) {
	//   const network = config.networks.find(n => n.id === track.networkId).key
	//   return postJson(`https://api.audioaddict.com/v1/${network}/tracks/${track.trackId}/vote/up`, {}, {
	//     'x-session-key': '0ffbc9bdae68faa9a65127c71289daa5'
	//   })
	// }

	// voteDown (track) {
	//   const network = config.networks.find(n => n.id === track.networkId).key
	//   return postJson(`https://api.audioaddict.com/v1/${network}/tracks/${track.trackId}/vote/down`, {}, {
	//     'x-session-key': '0ffbc9bdae68faa9a65127c71289daa5'
	//   })
	// }

	// deleteVote (track) {
	//   const network = config.networks.find(n => n.id === track.networkId).key
	//   return fetch(`https://api.audioaddict.com/v1/${network}/tracks/${track.trackId}/vote`, {
	//     method: 'DELETE',
	//     headers: {
	//       'x-session-key': '0ffbc9bdae68faa9a65127c71289daa5'
	//     }
	//   }).then(res => res.json())
	// }

	async getTrack (track) {
		const result = await getJson(`https://api.audioaddict.com/v1/${track.network.key}/tracks/${track.trackId}?audio_token=${config.session.audioToken}`)
		result.content.assets.forEach(asset => {
			// get ext from url
			const url = new URL(asset.url)
			asset.ext = url.pathname.split('.').pop()
		})
		return result
	}

	getTrackWithoutContent (trackId, networkId) {
		return getJson(`https://api.audioaddict.com/v1/${networkId}/tracks/${trackId}?audio_token=${config.session.audio_token}`)
	}

	async nowPlaying (channel) {
		// https://api.audioaddict.com/v1/di/currently_playing/channel/1
		const net = config.networks.by({ id: channel.networkId })
		const result = await getJson(`https://api.audioaddict.com/v1/${net.key}/currently_playing/channel/${channel.id}`)
		const track = await getJson(`https://api.audioaddict.com/v1/${net.key}/tracks/${result.track.id}/${net.id}?audio_token=${config.session.audio_token}`)
		track.content.assets.forEach(asset => {
			// get ext from url
			const url = new URL(asset.url)
			asset.ext = url.pathname.split('.').pop()
		})
		return { started: new Date(result.track.startTime), track }
	}

	/**
   * @param {Channel[]} channels
   */
	generatePlaylist (channels) {
		const playlist = []
		playlist.push('[playlist]')
		playlist.push(`NumberOfEntries=${channels.length}`)
		channels.forEach((channel, i) => {
			playlist.push(`File${i}=http://prem1.di.fm/${channel.key}_hi?${listenerKey}`)
			playlist.push(`Title${i}=${channel3.name}`)
			playlist.push(`Length${i}=0`)
		})
		return playlist.join('\n')
	}

	getChannel (channel) {
		return channelD[channel]
	}

	/**
   * Gets all channels
   */
	get channels () {
		return config.channels // 1 = all
	}

	/** @param {Channel} */
	async tuneIn (channel) {
		const result = await getJson(`https://api.audioaddict.com/v1/di/routines/channel/${channel.id}?tune_in=false&audio_token=${config.session.audioToken}`)
		result.tracks.forEach(track => {
			track.content.assets.forEach(asset => {
				// get ext from url
				const url = new URL(asset.url)
				asset.ext = url.pathname.split('.').pop()
			})
		})

		return result
	}

	async ping () {
		return getJson('https://api.audioaddict.com/v1/ping')
	}

	/**
   * @param {channel} channel
   * @returns {Promise<trackHistory[]>}
   */
	async trackHistory (channel) {
		const network = config.networks.find(n => n.id === channel.networkId).key
		return getJson(`https://api.audioaddict.com/v1/${network}/track_history/channel/${channel.id}`)
	}

	sessions () {
		return getJson(`https://api.audioaddict.com/v1/di/members/${config.session.memberId}/active_sessions?page=1&per_page=100`, {
			'x-session-key': config.session.key
		})

		// https://api.audioaddict.com/v1/di/qualities?all=true
		// https://api.audioaddict.com/v1/di/members/307868/social_identities
	}

	auth () {
		fetch('https://api.audioaddict.com/v1/di/members/authenticate', {
			headers: {
				'content-type': 'application/json'
			},
			body: JSON.stringify({
				username: '',
				password: ''
			}),
			method: 'POST'
		})
	}

	async batchInfo () {
		const res = await fetch('https://api.audioaddict.com/v1/di/mobile/batch_update?stream_set_key=public3', {
			headers: {
				Authorization: 'Basic ZXBoZW1lcm9uOmRheWVpcGgwbmVAcHA='
			}
		})
		const data = await res.json()
		return data
	}
}

const audioAddict = new AudioAddict()
globalThis.audioAddict = audioAddict

export { audioAddict }
