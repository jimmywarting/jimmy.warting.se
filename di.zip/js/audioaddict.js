import { makeDictionary, getJson, pick, postJson, call } from './utils.js'

if (!localStorage.config) {
  getJson(`https://api.audioaddict.com/v1/networks`).then(console.log)
  const networks = await getJson(`https://api.audioaddict.com/v1/networks`)
  console.log('Hämtade nätverk:', networks)
  const q = await Promise.all([
    postJson(
      `https://api.audioaddict.com/v1/${networks[0].key}/member_sessions`,
      { member_session: { unregistered: 'true' } },
      {
        'content-type': 'application/json',
        'authorization': 'Basic bW9iaWxlOmFwcHM='
      }
    ),
    getJson(`https://api.audioaddict.com/v1/${networks[0].key}/qualities`),
    Promise.all(networks.map(network =>
      getJson(`https://api.audioaddict.com/v1/${network.key}/channels`)
    )).then(channels => channels.flat().map(pick(
      'assetUrl,bannerUrl,description,descriptionLong,descriptionShort,id,images,key,name,networkId'
      .split(',')
    )))
  ]).catch(console.error)

  localStorage.setItem('config', JSON.stringify({
    networks,
    session: q[0],
    qualities: q[1],
    channels: q[2],
  }))
}

// postJson(
//       `https://api.audioaddict.com/v1/di/member_sessions`,
//       { member_session: { unregistered: 'true' } },
//       {
//         'content-type': 'application/json',
//         'authorization': 'Basic bW9iaWxlOmFwcHM=' // 'mobile:apps'
//       }
//     ).then(console.log)
const config = JSON.parse(localStorage.config)
config.network = config.networks.by({ key: 'di' })
// config.channels = config.channels.filter(c => c.network_id === config.network.id)

const listenerKey = '9564836dd232258' // https://github.com/alexjulien/DIfm_pls
globalThis.config = config

class AudioAddict {
  // voteUp (track) {
  //   const network = config.networks.find(n => n.id === track.networkId).key
  //   return postJson(`https://api.audioaddict.com/v1/${network}/tracks/${track.trackId}/vote/up`, {}, {
  //     'x-session-key': '0ffbc9bdae68faa9a65127c71289daa5'
  //   })
  // }

  // voteDown (track) {
  //   const network = config.networks.find(n => n.id === track.networkId).key
  //   return postJson(`https://api.audioaddict.com/v1/${network}/tracks/${track.trackId}/vote/down`, {}, {
  //     'x-session-key': '0ffbc9bdae68faa9a65127c71289daa5'
  //   })
  // }

  // deleteVote (track) {
  //   const network = config.networks.find(n => n.id === track.networkId).key
  //   return fetch(`https://api.audioaddict.com/v1/${network}/tracks/${track.trackId}/vote`, {
  //     method: 'DELETE',
  //     headers: {
  //       'x-session-key': '0ffbc9bdae68faa9a65127c71289daa5'
  //     }
  //   }).then(res => res.json())
  // }

  async getTrack (track) {
    const result = await getJson(`https://api.audioaddict.com/v1/${track.network.key}/tracks/${track.trackId}?audio_token=${config.session.audioToken}`)
    result.content.assets.forEach(asset => {
      // get ext from url
      const url = new URL(asset.url)
      asset.ext = url.pathname.split('.').pop()
    })
    return result
  }

  getTrackWithoutContent (trackId, networkId) {
    return getJson(`https://api.audioaddict.com/v1/${networkId}/tracks/${trackId}?audio_token=${config.session.audioToken}`)
  }

  async nowPlaying (channel) {
    // https://api.audioaddict.com/v1/di/currently_playing/channel/1
    const net = config.networks.by({id: channel.networkId })
    const result = await getJson(`https://api.audioaddict.com/v1/${net.key}/currently_playing/channel/${channel.id}`)
    const track = await getJson(`https://api.audioaddict.com/v1/${net.key}/tracks/${result.track.id}/${net.id}?audio_token=${config.session.audio_token}`)
    track.content.assets.forEach(asset => {
      // get ext from url
      const url = new URL(asset.url)
      asset.ext = url.pathname.split('.').pop()
    })
    return { started: new Date(result.track.startTime), track }
  }

  /**
   * @param {Channel[]} channels
   */
  generatePlaylist (channels) {
    const playlist = []
    playlist.push('[playlist]')
    playlist.push(`NumberOfEntries=${channels.length}`)
    channels.forEach((channel, i) => {
      playlist.push(`File${i}=http://prem1.di.fm/${channel.key}_hi?${listenerKey}`)
      playlist.push(`Title${i}=${channel3.name}`)
      playlist.push(`Length${i}=0`)
    })
    return playlist.join('\n')
  }

  getChannel (channel) {
    return channelD[channel]
  }

  /**
   * Gets all channels
   */
  get channels () {
    return config.channels // 1 = all
  }

  /** @param {Channel} */
  async tuneIn (channel) {
    const result = await getJson(`https://api.audioaddict.com/v1/di/routines/channel/${channel.id}?tune_in=true&audio_token=${config.session.audioToken}`)
    result.tracks.forEach(track => {
      track.content.assets.forEach(asset => {
        // get ext from url
        const url = new URL(asset.url)
        asset.ext = url.pathname.split('.').pop()
      })
    })

    return result
  }

  async ping () {
    return getJson(`https://api.audioaddict.com/v1/ping`)
  }

  /**
   * @param {channel} channel
   * @returns {Promise<trackHistory[]>}
   */
  async trackHistory (channel) {
    const network = config.networks.find(n => n.id === channel.networkId).key
    return getJson(`https://api.audioaddict.com/v1/${network}/track_history/channel/${channel.id}`)
  }

  sessions () {
    return fetch(`https://api.audioaddict.com/v1/di/members/${config.session.memberId}/active_sessions?page=1&per_page=100`, {
      headers: {
        'x-session-key': config.session.key
      },
    }).then(r => r.json())

    // https://api.audioaddict.com/v1/di/qualities?all=true
    // https://api.audioaddict.com/v1/di/members/307868/social_identities
  }

  auth() {
    fetch('https://api.audioaddict.com/v1/di/members/authenticate', {
      headers: {
        'content-type': 'application/json',
      },
      body: JSON.stringify({
        username: "",
        password: "",
      }),
      method: 'POST'
    });
  }

  async batchInfo () {
    const res = await fetch(`https://api.audioaddict.com/v1/di/mobile/batch_update?stream_set_key=public3`, {
      headers: {
        'Authorization': 'Basic ZXBoZW1lcm9uOmRheWVpcGgwbmVAcHA='
      }
    })
    const data = await res.json()
    return data
  }
}

const audioAddict = new AudioAddict()
globalThis.audioAddict = audioAddict

export { audioAddict }
