// Klient B: Vill kommunicera med en annan klient (t.ex. Klient A) med ett specifikt ID.
function sendChannelToSpecificClient(targetClientId) {
  // Skapa en ny MessageChannel som ska skickas till ClientMyAdmin
  const channelToTarget = new MessageChannel();

  // ClientMyAdmin behåller port1 för kommunikation med oss efter att den vidarebefordrats
  channelToTarget.port1.onmessage = (event) => {
    console.log(`Vi mottog meddelande från ClientMyAdmin (via den överförda kanalen):`, event.data);
  };
  channelToTarget.port1.start(); // Starta porten för att ta emot meddelanden

  // Skicka port2 och mål-ID till Service Workern
  navigator.serviceWorker.ready.then(registration => {
    registration.active.postMessage(
      {
        targetClientId,
        type: 'TRANSFER_CHANNEL',
        port: channelToTarget.port2 // Denna port skickas till SW
      },
      [channelToTarget.port2] // Viktigt: Överför porten
    );
  })

  console.log(`Vi har bett Service Worker att överföra vår MessageChannel till ClientMyAdmin med ID: ${targetClientId}`);

  // Exempel: Skicka ett meddelande till Klient A via den överförda porten efter en kort fördröjning
  setTimeout(() => {
      channelToTarget.port1.postMessage('Hej från DI via den överförda kanalen!');
  }, 2000);

  return channelToTarget.port1
}

export {
  sendChannelToSpecificClient
}