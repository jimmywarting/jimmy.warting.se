import nameify from 'https://cdn.jsdelivr.net/npm/filenamify@6.0.0/+esm'
import { audioAddict } from './audioaddict.js'
import kv from 'https://localwebcontainer.com/clientmyadmin/shared/kv.js'
import css from './channel-list.css'
// import html from './channel-list.html'
import { values, shuffle, makeFileHandleRecursive, lazy } from './utils.js'
import * as util from './utils.js'
import { db } from './db.js'
import { ID3Parser } from './id3.js'
import { sortTracks } from './sortModule.js';


let notification
const sw = await navigator.serviceWorker.ready
globalThis.util = util
globalThis.notifications = await sw.getNotifications()
globalThis.kv = kv

const UFID_OWNER = new Uint8Array([97, 117, 100, 105, 111, 97, 100, 100, 105, 99, 116, 0]) // audioaddict
const q = () => db.transaction('tracks', 'readwrite').objectStore('tracks')
const qq = (tx, success, failure) => {
  tx.onsuccess = e => success(e.target.result)
  failure && (tx.onerror = e => failure(e.target.error) )
}

globalThis.q = q
globalThis.qq = qq

function calculateRating(positive, negative) {
  const total = positive + negative;
  if (total === 0) return 0; // Undvik delning med noll
  const score = (positive / total) * 10;
  return Math.round(score * 10) / 10; // Avrundat till en decimal
}

/** @type {FileSystemDirectoryHandle} */
const root = await kv('get', 'root') || await navigator.storage.getDirectory()

// if (root.type === 'client') {
//   // hanterad av drag-n-drop från clientmyadmin
//   const { sendChannelToSpecificClient } = await import('./broadcast.js')
//   const port = sendChannelToSpecificClient(root.root)
//   port.onmessage = e => {
//     console.log('Meddelande från ClientMyAdmin:', e.data)
//   }
// }

const audioDir = await root.getDirectoryHandle('audio', { create: true })
const player = document.querySelector('#player')
const audio = player

globalThis.audioDir = audioDir
globalThis.nowPlaying = null
globalThis.nowPlayingFile = null

const session = navigator.mediaSession

function updatePositionState() {
  navigator.mediaSession.setPositionState({
    duration: player.duration,
    playbackRate: player.playbackRate,
    position: player.currentTime,
  });
  navigator.mediaSession.playbackState = player.paused ? 'paused' : 'playing';
}

session.setActionHandler("enterpictureinpicture", () => {
  pip()
})

session.setActionHandler("previoustrack", () => {
  currentTrack.timesSkipped++
  currentTrack.save()
  currentTrack.elm.previousSibling.track.play()
})

session.setActionHandler("nexttrack", () => {
  currentTrack.timesSkipped++
  currentTrack.save()
  currentTrack.elm.nextSibling.track.play()
})

session.setActionHandler('play', () => {
  player.play()
  video?.play()
})

session.setActionHandler('pause', () => {
  player.pause()
  globalThis.video?.pause()
  updatePositionState()
})

session.setActionHandler('stop', () => {
  player.pause()
  globalThis.video?.pause()
  updatePositionState()
})

session.setActionHandler('seekto', evt => {
  if (evt.seekTime) {
    player.currentTime = evt.seekTime
  }
  updatePositionState()
})

globalThis.updatePositionState = updatePositionState

session.setActionHandler('seekbackward', evt => {
  console.log('seekbackward', evt)
  if (evt.seekOffset) {
    player.currentTime = Math.max(0, player.currentTime - evt.seekOffset);
  }
  updatePositionState()
})

session.setActionHandler('seekforward', evt => {
  console.log('seekforward', evt)
  if (evt.seekOffset) {
    player.currentTime = Math.min(player.duration, player.currentTime + evt.seekOffset);
  }
  updatePositionState()
})

player.addEventListener('ended', () => {
  currentTrack.lastPlayedDate = new Date()
  currentTrack.PCNT++
  currentTrack.updateId3PlayCount()
  currentTrack.save()
  currentTrack.elm.nextSibling.track.play()
})

player.addEventListener('play', async () => {
  const img = await currentTrack.getImage()
  const src = img.url
  session.metadata = new MediaMetadata({
    title: currentTrack.displayTitle,
    artist: currentTrack.displayArtist,
    artwork: [{ src }]
  })
  session.playbackState = 'playing'

  notifications.forEach(n => {
    if (n.tag === 'Now Playing') {
      n.close()
    }
  })
  notifications.length = 0

  notification = await sw.showNotification('Nu spelas:', {
    body: currentTrack.displayTitle + ' av ' + currentTrack.displayArtist,
    icon: src,
    image: src,
    silent: true,
    actions: [
      { action: 'upvote', title: '👍 Gillade förra låten' },
      { action: 'downvote', title: '👎 Gillade inte förra låten' },
    ]
  })

  globalThis.notification = notification
})

const channel = audioAddict.channels.by({ key: 'trance' })
const playPauseBtn = document.querySelector('.player-wrapper #play-pause');
const currentTimeEl = document.querySelector('.player-wrapper #current-time');
const durationEl = document.querySelector('.player-wrapper #duration');
const progressBar = document.querySelector('.player-wrapper #progress-bar');
const volumeSlider = document.querySelector('.player-wrapper #volume');
const muteToggle = document.querySelector('.player-wrapper #mute-toggle');
const trackName = document.querySelector('.player-wrapper .track-info');
const playIcon = 'play_arrow';
const pauseIcon = 'pause';
const volOn = 'volume_up';
const volOff = 'volume_off';

function formatTime(sec) {
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
}

playPauseBtn.addEventListener('click', () => {
  if (audio.paused) {
    audio.play();

  } else {
    audio.pause();

  }
});

audio.addEventListener('play', () => {
  playPauseBtn.innerHTML = pauseIcon;
})
audio.addEventListener('pause', () => {
  playPauseBtn.innerHTML = playIcon;
})

function updateSeekbarBackground() {
  const duration = audio.duration;
  const currentTime = audio.currentTime;
  if (!duration || isNaN(duration)) return;

  // currentTimeLabel.textContent = formatTime(currentTime);
  // durationLabel.textContent = formatTime(duration);

  const buffered = audio.buffered;
  const playedPercentage = (currentTime / duration) * 100;
  const finalGradientParts = [];
  let currentOffset = 0;
  let totalBufferedSeconds = 0;

  if (playedPercentage > 0) {
    finalGradientParts.push(`var(--offline-color) 0%`, `var(--offline-color) ${playedPercentage}%`);
    currentOffset = playedPercentage;
  }

  for (let i = 0; i < buffered.length; i++) {
    const start = buffered.start(i);
    const end = buffered.end(i);

    totalBufferedSeconds += (end - start);

    const startPercentage = (start / duration) * 100;
    const endPercentage = (end / duration) * 100;

    if (startPercentage > currentOffset) {
      finalGradientParts.push(`#535557 ${currentOffset}%`, `#535557 ${startPercentage}%`);
    }

    const greenStart = Math.max(startPercentage, playedPercentage);
    if (endPercentage > greenStart) {
      finalGradientParts.push(`var(--buffered-color) ${greenStart}%`, `var(--buffered-color) ${endPercentage}%`);
    }
    currentOffset = Math.max(currentOffset, endPercentage);
  }

  if (currentOffset < 100) {
    finalGradientParts.push(`#535557 ${currentOffset}%`, `#535557 100%`);
  }

  // progressBar.style.background = `linear-gradient(to right, ${finalGradientParts.join(", ")})`;

  const audioFileSizeMB = currentTrack.metadata.size
  const downloadedMB = (totalBufferedSeconds / duration) * audioFileSizeMB;
  // downloadedLabel.textContent = `${downloadedMB.toFixed(2)} MB`;
}

audio.addEventListener('timeupdate', () => {
  currentTimeEl.textContent = formatTime(audio.currentTime);
  progressBar.value = audio.currentTime;
  updateSeekbarBackground()
})
audio.addEventListener('loadedmetadata', () => {
  durationEl.innerHTML = formatTime(audio.duration)
  progressBar.max = audio.duration;
  updatePositionState()
})
progressBar.addEventListener('input', () => {
  audio.currentTime = progressBar.value;
});

function updateVolume() {
  sessionStorage.volume = audio.volume = volumeSlider.value;
  muteToggle.innerHTML = audio.volume === 0 ? volOff : volOn;
  const val = (volumeSlider.value - volumeSlider.min) / (volumeSlider.max - volumeSlider.min) * 100;
  volumeSlider.style.background = `linear-gradient(to right, #ff3c00 0%, #ff3c00 ${val}%, #ddd ${val}%, #ddd 100%)`;
}

volumeSlider.addEventListener('input', updateVolume);

volumeSlider.value = sessionStorage.volume ?? 1;
updateVolume()

// updateSliderBackground(slider); // Init vid sidladdning


muteToggle.addEventListener('click', () => {
  audio.muted = !audio.muted;
  muteToggle.innerHTML = audio.muted ? volOff : volOn;
});

document.getElementById('backward').addEventListener('click', () => {
  audio.currentTime = 0; // Simulates previous track
});

document.getElementById('forward').addEventListener('click', () => {
  audio.currentTime = audio.duration; // Simulates next track
});

// Init
playPauseBtn.innerHTML = playIcon;
muteToggle.innerHTML = volOn;

globalThis.values
// globalThis.playlist = playlist
globalThis.channel = channel
globalThis.currentTrack = null
const pl = document.querySelector('#playlist')
class Track {
  #asset;

  constructor (obj) {
    Object.assign(this, obj)
    const elm = document.createElement('track-item')
    elm.track = this

    Object.defineProperty(this, 'elm', { value: elm, enumerable: false })
    pl.append(elm)
  }

  set asset (asset) { this.#asset = asset }
  get asset () {
    if (this.#asset) {
      // figure out the expiration date
      const url = new URL(this.#asset.url)
      const exp = +new Date(url.searchParams.get('exp'))

      // check if it will last for the duration of the track
      if (exp > (Date.now() + this.duration * 1000)) {
        // if it will last for the duration of the track, return it
        return this.#asset
      } else {
        this.#asset = null
      }
    }

    return audioAddict.getTrack(this).then(track => {
      this.votes ??= {}
      this.votes.up = track.votes.up
      this.votes.down = track.votes.down
      this.#asset = track.content.assets[0]
      return this.#asset
    })
  }

  skip () {
    this.timesSkipped++
    this.save()
    this.elm.nextSibling.track.play()
  }

  async getRemoteId3TagSize () {
    if (this.metadata.RemoteId3TagSize) {
      return this.metadata.RemoteId3TagSize
    }

    const res = await fetch((await this.asset).url, {
      headers: { range: 'bytes=0-10' }
    })

    const uint8 = await res.bytes()
    const { totalSize } = ID3Parser.parseID3v2Header(uint8)
    this.metadata.remoteId3TagSize = totalSize
    this.save()

    return totalSize
  }

  async #fetch(headers = {}, as = 'bytes') {
    const res = await fetch((await this.asset).url, { headers })
    return res === 'res' ? res : res[as]()
  }

  async getImage () {
    // Return cached blob if available
    if (this.images.blob) {
      return this.images.blob
    }

    // Check if we have a local file and get image from APIC if available
    if (this.metadata.fileHandle) {
      const id3 = await this.getId3()
      const frame = id3.get('APIC')
      if (frame) {
        const pic = await ID3Parser.readPictureFrame(frame)
        return pic.data
      }
    }

    // Check if we have a remote byte range for the image
    // if so, fetch that image from the server and cache it
    if (this.images.byteRange) {
      const res = await this.#fetch({ range: this.images.byteRange }, 'res')
      const file = await res.file({
        type: this.images.type,
        name: 'image.' + this.images.type.split('/').pop()
      })
      this.images.blob = file
      this.save()
      return
    }

    // Otherwise, get remote ID3 and extract original ID3 frames and get APIC
    const id3 = await this.getId3()
    const frame = id3.get('APIC')

    if (frame) {
      // If APIC frame exists, read and cache it
      const pic = await ID3Parser.readPictureFrame(frame)
      const offset = frame.offset + pic.offset
      const { type, size } = pic.data
      const byteRange = `bytes=${offset}-${offset + size - 1}`
      this.images.byteRange = byteRange
      this.images.type = type
      this.images.hasAPIC = true
      this.images.blob = pic.data
      this.save()
    } else {
      // Fallback: fetch image which isn't attached in APIC and is instead
      // hosted remotely... this CDN is unfortunately CORS blocked, so we need
      // to proxy it
      this.images.hasAPIC = false
      const q = new URLSearchParams({
        cors: JSON.stringify({ url: this.images.default })
      })
      const res = await fetch('https://adv-cors.deno.dev/?' + q)
      if (!res.ok) {
        throw new Error('Failed to fetch image: ' + res.statusText)
      }
      // Cache the fetched image blob
      this.images.blob = await res.file({ type: 'image/jpeg' })
      this.save()
    }

    return this.images.blob
  }

  get channel () {
    return config.channels.by({ id: this.channelId })
  }

  async sync () {
    const dir = audioDir.getDirectoryHandle(this.channel.name, { create: false })
    for await (const [name, handle] of await dir) {
      if (handle.kind === 'file' && name.endsWith('.mp3')) {
        const ufid = await lazy(handle).getFile().slice(20, 54).bytes()
        const owner = UFID_OWNER.every((v, i) => v === ufid[i])

        if (!owner) return

        const dv = new DataView(ufid.buffer, 12)

        const trackId = dv.getUint32(0)
        const channelId = dv.getUint32(4)
        const channel = config.channels.by({id: channelId })
        const playCount = dv.getUint32(30)

        qq(q().index('trackId').get(trackId), async track => {
          if (track) return
          track = await audioAddict.getTrackWithoutContent(
            trackId,
            channelId,
          )
          track = Track.fromTrackAndChannel(track, channel)
          track.metadata.fileHandle = handle
          track.filename = handle.name
          track.PCNT = playCount
          track.save()
        }, console.error)
      }
    }
  }

  static fromTrackAndChannel (track, channel) {
    const asset = track.content.assets[0]
    const filename = nameify(track.track + '.' + asset.ext)
    const UFID = new DataView(new ArrayBuffer(8))
    UFID.setUint32(0, track.id)
    UFID.setUint32(4, channel.id)

    return new Track({
      asset: asset,
      artist: track.artist,
      title: track.title,
      track: track.track,
      displayArtist: track.displayArtist,
      displayTitle: track.displayTitle,
      mix: track.mix,
      duration: Math.floor(track.length),
      images: track.images,
      trackId: track.id,
      version: track.version,
      channelId: channel.id,
      filename,
      UFID,
      timesStarted: 0,
      PCNT: 0,
      timesSkipped: 0,
      lastPlayedDate: null,
      votes: {
        up: track.votes.up,
        down: track.votes.down,
        me: null
      },
      metadata: {
        formatId: asset.content_format_id,
        qualityId: asset.content_quality_id,
        size: asset.size,
        lastModifiedDate: null,
        fileHandle: null
      }
    })
  }

  async getId3 () {
    if (this.metadata.fileHandle) {
      const file = await this.metadata.fileHandle.getFile()
      return new ID3Parser(file).init()
    } else {
      const tagSize = await this.getRemoteId3TagSize()
      const uint8 = await this.#fetch({ range: 'bytes=0-' + tagSize }, 'blob')
      return new ID3Parser(uint8).init()
    }
  }

  async download () {
    if (this.metadata.fileHandle) return

    const progress = this.elm.progress
    const dataset = this.elm.progress.closest('.track').dataset
    progress.max = this.metadata.size
    progress.value = 0
    dataset.state = 'loading'
    const res = await fetch((await this.asset).url)
    res.clone().body.pipeTo(new WritableStream({
      write(chunk) { progress.value += chunk.length },
    }))
    const file = await res.file({ name: this.filename })
    const id3 = await lazy(new ID3Parser(file)).init()

    const frame = id3.get('APIC')
    if (frame) {
      const pic = await ID3Parser.readPictureFrame(frame)
      const file = await pic.data.convertToImage('webp', .9)
      Object.assign(frame, ID3Parser.createAPIC(file, 3, pic.description))
    } else {
      const img = await this.getImage()
      const file = await img.convertToImage('webp', .9)
      const apic = ID3Parser.createAPIC(file)
      id3.frames.push(apic)
    }

    const PCNT = new DataView(new ArrayBuffer(4))
    PCNT.setUint32(0, this.PCNT)

    id3.deleteAll('PCNT', 'TCON', 'TALB')

    // UFID and PCNT frames go first because they are fixed size and easy to
    // read and update without a id3 parser
    id3.frames.unshift({
      frameId: 'UFID', // Unique File Identifier
      flags: 0,
      data: new Blob([ UFID_OWNER, this.UFID ])
    }, {
      frameId: 'PCNT', // Play Count
      flags: 0,
      data: new Blob([ PCNT ])
    }, {
      frameId: 'TCON', // Genre
      flags: 0,
      data: new Blob([ ID3Parser.UTF8, this.channel.name ])
    }, {
      frameId: 'TALB', // Album
      flags: 0,
      data: new Blob([ ID3Parser.UTF8, this.channel.name ])
    })

    delete id3.v1
    const channelDir = await audioDir.getDirectoryHandle(this.channel.name, { create: true })
    const fileHandle = await channelDir.getFileHandle(this.filename, { create: true })
    const writable = await fileHandle.createWritable()

    await writable.write({ type: "write", position: 0, data: id3.file });
    await writable.close()
    progress.value = progress.max
    this.metadata.fileHandle = fileHandle
    this.metadata.lastModifiedDate = file.lastModifiedDate
    this.metadata.localSize = file.size
    this.images = { default: this.images.default }
    this.save()
    dataset.state = 'done'
  }

  async updateId3PlayCount () {
    if (!this.metadata.fileHandle) return

    /** @type {FileSystemFileHandle} */
    const handle = this.metadata.fileHandle
    const writable = await handle.createWritable({
      keepExistingData: true
    })

    const PCNT = new DataView(new ArrayBuffer(4))
    PCNT.setUint32(0, this.PCNT)

    await writable.write({
      type: 'write',
      position: 50,
      data: PCNT
    })

    await writable.close()
  }

  get network () {
    return config.networks.by({id: this.channel.networkId })
  }

  get networkId () {
    return this.network.id
  }

  get networkKey () {
    return this.network.key
  }

  async play () {
    // await this.download()
    const meta = this.metadata
    if (meta.fileHandle) {
      const file = await meta.fileHandle.getFile()
      player.src = file.url
      player.play().catch(() => {})
    } else {
      const asset = await this.asset
      player.src = asset.url
      player.play().catch(() => {})
    }
    trackName.innerText = player.title = this.track
    currentTrack = this
    this.timesStarted++
    this.save()
    this.elm.nextSibling?.track?.download()
    votedUp.innerText = this.votes?.up || 0
    votedDown.innerText = this.votes?.down || 0
    stars.innerText = calculateRating(this.votes?.up || 0, this.votes?.down || 0)
  }

  save () {
    this.elm.track = this
    qq(q().put(this), () => {}, console.error)
  }
}

qq(q().index('channelId').getAll(channel.id), async result => {
  const allTracks = new Set(result.map(t => t.trackId))

  result = shuffle(result)
  sortTracks(result)
  console.log(result)
  if (result.length) {
    new Track(result.shift()).play()
  }

  const skeleton = Array(5).fill(0).map(_ => new Track())

  for (const track of result) {
    new Track(track)
  }

  const { tracks } = await audioAddict.tuneIn(channel)
  console.log(tracks)
  const tx = q()
  for (const track of tracks) {
    if (allTracks.has(track.track_id)) {
      // skeleton.pop()
    } else {
      const dbTrack = Track.fromTrackAndChannel(track, channel)
      tx.add(dbTrack)
      skeleton.pop().elm.replaceWith(dbTrack.elm)
    }
  }
})

function html(strings, ...values) {
  return strings.reduce((result, str, i) => {
    const val = values[i];
    const value = Array.isArray(val) ? val.join('') : val ?? '';
    return result + str + value;
  }, '');
}

const select = html`<select id="channel-select">
  <button>
    <selectedcontent></selectedcontent>
    <span class="arrow"></span>
  </button>

  ${audioAddict.channels.map(channel => html`
    <option value="${channel.id}">
      <img loading="lazy" width="40" height="40" src="${channel.images.square}" alt="${channel.name}">
      <div class="genre-title">${channel.name}</div>
      <div class="genre-desc">${channel.description}</div>
    </option>
  `)}
</select>`


document.querySelector('main').insertAdjacentHTML('afterbegin', select)
