import { LitElement, html } from 'https://cdn.jsdelivr.net/gh/lit/dist@3/core/lit-core.min.js'
import styles from './download-dialog.css' with { type: 'css' }
import { XIcon } from '../icons.js'

class DownloadDialog extends LitElement {
	static properties = {
		open: { type: Boolean },
		channelName: { type: String }
	}

	static styles = [styles]

	constructor () {
		super()
		this.open = false
		this.channelName = ''
	}

	updated (changedProperties) {
		if (changedProperties.has('open')) {
			const dialog = this.shadowRoot.querySelector('dialog')
			if (dialog) {
				if (this.open && !dialog.open) {
					dialog.showModal()
				} else if (!this.open && dialog.open) {
					dialog.close()
				}
			}
		}
	}

	#handleClose (e) {
		const dialog = e.target
		if (dialog.returnValue === 'download') {
			const form = dialog.querySelector('form')
			const formData = new FormData(form)

			const downloadData = {
				metadataOnly: formData.get('metadataOnly') === 'on'
			}

			// Only include enabled options with values
			if (formData.get('songs-enabled') === 'on' && formData.get('songs')) {
				downloadData.songs = parseInt(formData.get('songs'))
			}
			if (formData.get('minutes-enabled') === 'on' && formData.get('minutes')) {
				downloadData.minutes = parseInt(formData.get('minutes'))
			}
			if (formData.get('megabytes-enabled') === 'on' && formData.get('megabytes')) {
				downloadData.megabytes = parseInt(formData.get('megabytes'))
			}

			this.dispatchEvent(new CustomEvent('download-requested', {
				bubbles: true,
				composed: true,
				detail: downloadData
			}))
		}
		this.open = false
	}

	firstUpdated() {
		globalThis.downloadDialog = this.shadowRoot.querySelector('dialog')
	}

	render () {
		const dialogTitle = this.channelName
			? `Ladda ner låtar från ${this.channelName}`
			: 'Ladda ner låtar'

		return html`
			<dialog closedby="any" @close=${this.#handleClose}>
				<form method="dialog">
					<div class="dialog-header">
						<h2>${dialogTitle}</h2>
						<button class="close-button" type="submit" aria-label="Stäng">
							${XIcon}
						</button>
					</div>

					<div class="dialog-content">
						<div class="download-options">
							<!-- Metadata only - at the top as requested -->
							<div class="metadata-toggle">
								<label>
									<input
										type="checkbox"
										name="metadataOnly"
									>
									<span>Endast metadata</span>
								</label>
								<p class="help-text">
									Ladda endast ner låtinformation utan ljudfiler (sparar utrymme)
								</p>
							</div>

							<!-- Download options - all checkboxes, not radio buttons -->
							<div class="option-group">
								<label>
									<input
										type="checkbox"
										name="songs-enabled"
										id="songs-enabled"
									>
									<span>Antal låtar</span>
								</label>
								<input
									type="number"
									name="songs"
									min="1"
									placeholder="Ange antal låtar"
									class="type-input"
								>
							</div>

							<div class="option-group">
								<label>
									<input
										type="checkbox"
										name="minutes-enabled"
										id="minutes-enabled"
									>
									<span>Speltid (minuter)</span>
								</label>
								<input
									type="number"
									name="minutes"
									min="1"
									placeholder="Ange antal minuter"
									class="type-input"
								>
							</div>

							<div class="option-group">
								<label>
									<input
										type="checkbox"
										name="megabytes-enabled"
										id="megabytes-enabled"
									>
									<span>Lagringsstorlek (MB)</span>
								</label>
								<input
									type="number"
									name="megabytes"
									min="1"
									placeholder="Ange MB"
									class="type-input"
								>
								<p class="help-text">1000 MB = 1 GB</p>
							</div>
						</div>

						<div class="dialog-actions">
							<button type="submit" value="cancel">
								Avbryt
							</button>
							<button type="submit" value="download" class="primary-button">
								Starta nedladdning
							</button>
						</div>
					</div>
				</form>
			</dialog>
		`
	}
}

customElements.define('download-dialog', DownloadDialog)

export { DownloadDialog }
