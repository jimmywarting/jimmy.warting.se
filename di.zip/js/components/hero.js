import { LitElement, html } from 'https://cdn.jsdelivr.net/gh/lit/dist@3/core/lit-core.min.js'
import styles from './hero.css' with { type: 'css' }
import { ArrowLeftIcon, CloudIcon, CloudOffIcon } from '../icons.js'

class Hero extends LitElement {
	static properties = {
		imageUrl: { type: String },
		title: { type: String },
		subtitle: { type: String },
		showBackButton: { type: Boolean },
		isOfflineMode: { type: Boolean }
	}

	static styles = [styles]

	constructor () {
		super()
		this.imageUrl = ''
		this.title = ''
		this.subtitle = ''
		this.showBackButton = false
		this.isOfflineMode = false
	}

	#handleBackClick () {
		this.dispatchEvent(new CustomEvent('back', { bubbles: true, composed: true }))
	}

	#handleOfflineToggle () {
		const newOfflineMode = !this.isOfflineMode
		this.dispatchEvent(new CustomEvent('offline-toggle', {
			bubbles: true,
			composed: true,
			detail: { isOfflineMode: newOfflineMode }
		}))
	}

	render () {
		const backgroundStyle = this.imageUrl
			? `background-image: linear-gradient(to bottom, #0c0e1d80, #0c0e1d), url('${this.imageUrl}');`
			: 'background-color: #1a1a36;'

		const modeClass = this.isOfflineMode ? 'offline' : 'online'
		const modeIcon = this.isOfflineMode ? CloudOffIcon : CloudIcon
		const modeTitle = this.isOfflineMode ? 'Offline-läge (Endast nedladdat)' : 'Online-läge (Alla låtar)'

		return html`
			<div class="hero" style="${backgroundStyle}">
				<div class="hero-header">
					${this.showBackButton
						? html`
							<button class="hero-button" @click=${this.#handleBackClick} title="Tillbaka" aria-label="Tillbaka">
								${ArrowLeftIcon}
							</button>
						`
						: html`<div></div>`
					}
					<button
						class="hero-button offline-toggle ${modeClass}"
						@click=${this.#handleOfflineToggle}
						title="${modeTitle}"
						aria-label="${modeTitle}"
					>
						${modeIcon}
					</button>
				</div>

				<div class="hero-content">
					${this.imageUrl
						? html`
							<div class="hero-image-container">
								<img src="${this.imageUrl}" alt="${this.title || ''} omslag">
							</div>
						`
						: ''
					}
					${this.subtitle ? html`<p class="hero-subtitle">${this.subtitle}</p>` : ''}
					${this.title ? html`<h1 class="hero-title">${this.title}</h1>` : ''}

					<div class="hero-slot-content">
						<slot></slot>
					</div>
				</div>
			</div>
		`
	}
}

customElements.define('app-hero', Hero)

export { Hero }
