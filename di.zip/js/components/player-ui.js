import { LitElement, html, render } from 'https://cdn.jsdelivr.net/gh/lit/dist@3/core/lit-core.min.js'
import styles from './player-ui.css' with { type: 'css' }
import material from 'https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200' with { type: 'css' }
import { audioPlayer, audio } from '../audio-player.js'

import {
	HardDriveIcon,
	PauseIcon,
	PlayIcon,
	SkipBackIcon,
	SkipForwardIcon,
	ThumbsDownIcon,
	ThumbsUpIcon,
	Volume2Icon,
	VolumeXIcon,
	WifiIcon
} from '../icons.js'

class PlayerUI extends LitElement {
	static properties = {
		track: { type: Object },
	}

	static styles = [ material, styles ]

	constructor () {
		super()
		this.track = null
		globalThis.playerUI = this
	}

	#updateVolume (evt) {
		const elm = evt.target
		const vol = elm.valueAsNumber
		sessionStorage.volume = audio.volume = vol
		// muteToggle.innerHTML = audio.volume === 0 ? volOff : volOn;
		const val = (vol - elm.min) / (elm.max - elm.min) * 100;
		elm.style.background = `linear-gradient(to right, #ff3c00 0%, #ff3c00 ${val}%, #ddd ${val}%, #ddd 100%)`;
	}

	// volumeSlider.addEventListener('input', updateVolume);
	// volumeSlider.value = sessionStorage.volume ?? 1;
	// updateVolume()

	#handlePrev () {
		this.dispatchEvent(new CustomEvent('prev', { bubbles: true, composed: true }))
	}

	#handleNext () {
		this.dispatchEvent(new CustomEvent('next', { bubbles: true, composed: true }))
	}

	#handleSeek (e) {
		audio.currentTime = e.target.valueAsNumber
	}

	#handleVolumeChange (e) {
		const newVolume = parseFloat(e.target.value)
		this.dispatchEvent(new CustomEvent('volume-change', {
			bubbles: true,
			composed: true,
			detail: { volume: newVolume }
		}))
	}

	#handleMuteToggle () {
		audio.muted = !audio.muted
	}

	render () {
		const isCached = !!this.track?.metadata?.fileHandle
		const upVotes = this.track?.votes?.up || 0
		const downVotes = this.track?.votes?.down || 0
		const trackTitle = this.track?.title || 'Ingen låt vald'
		// average rating based on 0-10 scale - calculated from up/down votes
		const totalVotes = upVotes + downVotes
		const averageRating = (totalVotes > 0 ? (upVotes / totalVotes) * 10 : 0).toFixed(1)

		return html`
			<footer class="footer-player">
				<!-- Progress bar at the top of the footer -->
				${audioPlayer.components.progressBar}

				<div id="controls">
					<!-- Left side: prev, play/pause, next -->
					<div class="left-controls">
						<button id="back" class="material-symbols-outlined">skip_previous</button>
						<button
						  id="play-pause"
							@click=${audioPlayer.togglePlayPause}
							class="material-symbols-outlined"
						></button>
						<button id="forward" class="material-symbols-outlined">skip_next</button>

						<!-- Volume control -->
						<button
							id="mute-toggle"
							title="Mute"
							class="material-symbols-outlined"
							@click=${this.#handleMuteToggle}
						>volume_up</button>

						<input
							type="range"
							id="volume"
							min="0"
							max="1"
							step="0.01"
							value="1"
							@input=${this.#updateVolume}
						>

						<!-- Time display -->
						${audioPlayer.components.timeDisplay}
					</div>

					<!-- Track info -->
					<div class="track-info">
						<span data-before='var(--currentTrackTitle, "Ingen låt vald")'></span>
					</div>

					<!-- Right side: cache indicator, votes, volume -->
					<div class="right-icons">
						<!-- Vote buttons -->
						<span class="reaction">
							<span class="item voteUpButton">
								<span class="emoji">👍</span>
								<span id="votedUp" class="count">${upVotes}</span>
							</span>
							<span class="divider"></span>
							<span class="item voteDownButton">
								<span class="emoji">👎</span>
								<span id="votedDown" class="count">${downVotes}</span>
							</span>
							<span class="divider"></span>
							<span class="item">
								<span class="emoji">⭐️</span>
								<span id="stars" class="count">${averageRating}</span>
							</span>
						</span>

						<!-- Cache indicator -->
						<span class="cache-icon ${isCached ? 'cached' : 'streaming'}" title="${isCached ? 'Nedladdad' : 'Strömmar'}">
							${isCached ? HardDriveIcon : WifiIcon}
						</span>
					</div>
				</div>
			</footer>
		`
	}
}

customElements.define('player-ui', PlayerUI)

export { PlayerUI }
