import { LitElement, html } from 'https://cdn.jsdelivr.net/gh/lit/dist@3/core/lit-core.min.js'
import styles from './playlist-view.css' with { type: 'css' }
import { DeleteIcon, DownloadIcon, MenuIcon, PauseIcon } from '../icons.js'
import './hero.js'

class PlaylistView extends LitElement {
	static properties = {
		channel: { type: Object },
		tracks: { type: Array },
		stationTitle: { type: String },
		isOfflineMode: { type: Boolean }
	}

	static styles = [styles]

	constructor () {
		super()
		this.channel = null
		this.tracks = []
		this.stationTitle = 'Station'
		this.isOfflineMode = false
	}

	#handleOfflineToggle (e) {
		this.isOfflineMode = e.detail.isOfflineMode
		this.dispatchEvent(new CustomEvent('offline-toggle', {
			bubbles: true,
			composed: true,
			detail: { isOfflineMode: this.isOfflineMode }
		}))
	}

	#handleTrackClick (track) {
		this.dispatchEvent(new CustomEvent('track-click', {
			bubbles: true,
			composed: true,
			detail: { track }
		}))
	}

	render () {
		if (!this.channel) {
			return html``
		}

		const heroBackground = this.channel.images?.squareBlob?.url || ''
		const heroSubtitle = `${this.stationTitle} ${this.channel.name || ''} Mix`

		return html`
			<div class="content-wrapper hide-scrollbar playlist-view">

				<!-- HERO BANNER SECTION -->
				<app-hero
					.imageUrl=${heroBackground}
					.subtitle=${heroSubtitle}
					.showBackButton=${true}
					.isOfflineMode=${this.isOfflineMode}
					@back=${() => this.dispatchEvent(new CustomEvent('back', { bubbles: true, composed: true }))}
					@offline-toggle=${this.#handleOfflineToggle}
				></app-hero>

				<!-- TRACK LIST SECTION -->
				<section class="track-list-container">
					${this.tracks?.map((track, index) => html`
						<div
							class="track-item ${track.isPlaying ? 'now-playing' : ''} ${track.metadata?.fileHandle ? 'downloaded' : ''}"
							@click=${() => this.#handleTrackClick(track)}
						>

							<div class="track-number-or-icon">
								${track.isPlaying ? PauseIcon : html`<span>${index + 1 < 10 ? '0' : ''}${index + 1}</span>`}
							</div>

							<div class="track-info">
								<div class="track-art-wrapper">
									<img loading="lazy" src="${track.images?.default?.url}.webp?width=50&quality=90" alt="Omslag för ${track.title}">
								</div>
								<div class="track-text">
									<p class="track-title">${track.title}</p>
									<p class="track-artist">${track.artist?.name || ''}</p>
								</div>
							</div>

							<div class="track-metadata">
								${track.isNew ? html`<span class="badge new-badge">NY</span>` : ''}
								${track.metadata?.fileHandle
									? html`<span class="delete">${DeleteIcon}</span>`
									: html`<span class="download">${DownloadIcon}</span>`
								}
								<button class="track-menu-button">${MenuIcon}</button>
							</div>
						</div>
					`)}
				</section>

			</div>
		`
	}
}

customElements.define('playlist-view', PlaylistView)

export { PlaylistView }
