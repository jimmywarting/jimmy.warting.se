import { LitElement, html } from 'https://cdn.jsdelivr.net/gh/lit/dist@3/core/lit-core.min.js'
import styles from './radio-network-selector.css' with { type: 'css' }

class RadioNetworkSelector extends LitElement {
	static properties = {
		networks: { type: Array },
		activeIndex: { type: Number }
	}

	static styles = [styles]

	constructor () {
		super()
		this.networks = []
		this.activeIndex = 0
	}

	#handleNetworkClick (index) {
		this.dispatchEvent(new CustomEvent('network-change', {
			bubbles: true,
			composed: true,
			detail: { index }
		}))
	}

	render () {
		return html`
			<section class="network-selector">
				${this.networks.map((network, index) => html`
					<button
						class="network-button ${index === this.activeIndex ? 'active' : ''}"
						@click=${() => this.#handleNetworkClick(index)}
						title="${network.name}"
					>
						<img
							src="/img/${network.key.toLowerCase()}.svg"
							alt="${network.key}"
						>
					</button>
				`)}
			</section>
		`
	}
}

customElements.define('radio-network-selector', RadioNetworkSelector)

export { RadioNetworkSelector }
