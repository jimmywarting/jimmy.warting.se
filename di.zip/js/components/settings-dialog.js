import { LitElement, html } from 'https://cdn.jsdelivr.net/gh/lit/dist@3/core/lit-core.min.js'
import styles from './settings-dialog.css' with { type: 'css' }
import { XIcon } from '../icons.js'

const micAccess = await navigator.permissions.query({name: 'microphone'})

class SettingsDialog extends LitElement {
	static properties = {
		open: { type: Boolean },
		activeTab: { type: String },
		audioDevices: { type: Array },
		settings: { type: Object }
	}

	static styles = [styles]

	constructor () {
		super()
		this.open = false
		this.activeTab = 'notification'
		this.audioDevices = []
		this.settings = this.#loadSettings()
	}

	#loadSettings () {
		try {
			const saved = localStorage.getItem('di-4-free-settings')
			return saved ? JSON.parse(saved) : this.#getDefaultSettings()
		} catch (e) {
			console.error('Failed to load settings:', e)
			return this.#getDefaultSettings()
		}
	}

	#getDefaultSettings () {
		return {
			notificationsEnabled: false,
			notifyNewTrack: false,
			inactivityPause: false,
			audioOutput: 'default',
			qualityWifi: 'high',
			qualityMobile: 'medium',
			qualityDownload: 'high',
			maxSongs: '',
			maxHours: '',
			maxSizeGB: '',
			maxSongsPerStation: '',
			ttlDays: '',
			autoReplaceOld: false,
			wifiOnlyDownload: true,
			protectUpvoted: true,
			autoOfflineMode: false
		}
	}

	#saveSettings () {
		try {
			localStorage.setItem('di-4-free-settings', JSON.stringify(this.settings))
		} catch (e) {
			console.error('Failed to save settings:', e)
		}
	}

	async connectedCallback () {
		super.connectedCallback()
		await this.#loadAudioDevices()
	}

	async #loadAudioDevices () {
		micAccess.addEventListener('change', async () => {
			const devices = await navigator.mediaDevices.enumerateDevices()
			this.audioDevices = devices.filter(device => device.kind === 'audiooutput')
		})

		const devices = await navigator.mediaDevices.enumerateDevices()
		this.audioDevices = devices.filter(device => device.kind === 'audiooutput')
	}

	updated (changedProperties) {
		if (changedProperties.has('open')) {
			const dialog = this.shadowRoot.querySelector('dialog')
			if (dialog) {
				if (this.open && !dialog.open) {
					dialog.showModal()
				} else if (!this.open && dialog.open) {
					dialog.close()
				}
			}
		}
	}

	#handleClose (e) {
		const dialog = e.target
		const form = dialog.querySelector('form')
		if (form) {
			const formData = new FormData(form)
			// Update settings from form data
			for (const [key, value] of formData.entries()) {
				if (value === 'on') {
					this.settings[key] = true
				} else if (value === '') {
					this.settings[key] = ''
				} else {
					this.settings[key] = value
				}
			}
			// Handle checkboxes that aren't in formData when unchecked
			const checkboxes = form.querySelectorAll('input[type="checkbox"]')
			checkboxes.forEach(cb => {
				if (!formData.has(cb.name)) {
					this.settings[cb.name] = false
				}
			})
			this.#saveSettings()
		}
		this.open = false
	}

	#handleTabChange (tab) {
		this.activeTab = tab
	}

	firstUpdated () {
		globalThis.settingsDialog = this.shadowRoot.querySelector('dialog')
	}

	render () {
		return html`
			<dialog closedby="any" @close=${this.#handleClose}>
				<form method="dialog">
					<div class="dialog-header">
						<h2>Inställningar</h2>
						<button class="close-button" type="submit" aria-label="Stäng">
							${XIcon}
						</button>
					</div>

					<div class="dialog-content">
						<nav class="side-menu">
							<button
								type="button"
								class="menu-item ${this.activeTab === 'notification' ? 'active' : ''}"
								@click=${() => this.#handleTabChange('notification')}
							>
								Notifikationer
							</button>
							<button
								type="button"
								class="menu-item ${this.activeTab === 'audio' ? 'active' : ''}"
								@click=${() => this.#handleTabChange('audio')}
							>
								Ljud
							</button>
							<button
								type="button"
								class="menu-item ${this.activeTab === 'storage' ? 'active' : ''}"
								@click=${() => this.#handleTabChange('storage')}
							>
								Lagring
							</button>
							<button
								type="button"
								class="menu-item ${this.activeTab === 'misc' ? 'active' : ''}"
								@click=${() => this.#handleTabChange('misc')}
							>
								Övrigt
							</button>
						</nav>

						<div class="settings-panel">
							${this.#renderActiveTab()}
						</div>
					</div>
				</form>
			</dialog>
		`
	}

	#renderActiveTab () {
		switch (this.activeTab) {
			case 'notification':
				return this.#renderNotificationSettings()
			case 'audio':
				return this.#renderAudioSettings()
			case 'storage':
				return this.#renderStorageSettings()
			case 'misc':
				return this.#renderMiscSettings()
			default:
				return html``
		}
	}

	#renderNotificationSettings () {
		const notificationPermission = typeof Notification !== 'undefined'
			? Notification.permission
			: 'default'
		const notificationsGranted = notificationPermission === 'granted'

		return html`
			<div class="settings-section">
				<h3>Notifikationsinställningar</h3>

				${notificationPermission === 'denied'
					? html`
						<div class="warning-message">
							<p>Notifikationer är blockerade i din webbläsare. Aktivera dem i webbläsarinställningarna för att använda dessa funktioner.</p>
						</div>
					`
					: notificationPermission === 'default'
						? html`
							<div class="info-message">
								<p>Du behöver ge tillstånd för notifikationer för att använda dessa funktioner.</p>
								<button type="button" class="primary-button" @click=${this.#requestNotificationPermission}>
									Begär tillstånd
								</button>
							</div>
						`
						: ''
				}

				<div class="setting-item ${!notificationsGranted ? 'disabled' : ''}">
					<label>
						<input
							type="checkbox"
							name="notificationsEnabled"
							?checked=${this.settings.notificationsEnabled}
							?disabled=${!notificationsGranted}
						>
						<span>Aktivera notifikationer</span>
					</label>
					<p class="setting-description">Visa systemnotifikationer från appen</p>
				</div>

				<div class="setting-item ${!notificationsGranted ? 'disabled' : ''}">
					<label>
						<input
							type="checkbox"
							name="notifyNewTrack"
							?checked=${this.settings.notifyNewTrack}
							?disabled=${!notificationsGranted}
						>
						<span>Visa när ny låt börjar</span>
					</label>
					<p class="setting-description">Få en notifikation när nästa låt börjar spelas</p>
				</div>

				<div class="setting-item ${!notificationsGranted ? 'disabled' : ''}">
					<label>
						<input
							type="checkbox"
							name="inactivityPause"
							?checked=${this.settings.inactivityPause}
							?disabled=${!notificationsGranted}
						>
						<span>Pausa vid inaktivitet</span>
					</label>
					<p class="setting-description">Visa "Är du där?" och pausa spelaren om ingen interaktion sker</p>
				</div>
			</div>
		`
	}

	#renderAudioSettings () {
		return html`
			<div class="settings-section">
				<h3>Ljudinställningar</h3>

				<div class="setting-item">
					<label for="audioOutput">Ljudutgång</label>
					<select id="audioOutput" name="audioOutput" .value=${this.settings.audioOutput}>
						<option value="default">Standard</option>
						${this.audioDevices.map(device => html`
							<option value="${device.deviceId}" ?selected=${this.settings.audioOutput === device.deviceId}>
								${device.label || `Enhet ${device.deviceId.slice(0, 8)}`}
							</option>
						`)}
					</select>
					<p class="setting-description">Välj vilken enhet som ska användas för uppspelning</p>
				</div>

				<div class="setting-item">
					<label for="qualityWifi">Ljudkvalitet (WiFi)</label>
					<select id="qualityWifi" name="qualityWifi" .value=${this.settings.qualityWifi}>
						<option value="low" ?selected=${this.settings.qualityWifi === 'low'}>Låg (64 kbps)</option>
						<option value="medium" ?selected=${this.settings.qualityWifi === 'medium'}>Medel (128 kbps)</option>
						<option value="high" ?selected=${this.settings.qualityWifi === 'high'}>Hög (320 kbps)</option>
					</select>
					<p class="setting-description">Kvalitet när du är ansluten till WiFi</p>
				</div>

				<div class="setting-item">
					<label for="qualityMobile">Ljudkvalitet (Mobildata)</label>
					<select id="qualityMobile" name="qualityMobile" .value=${this.settings.qualityMobile}>
						<option value="low" ?selected=${this.settings.qualityMobile === 'low'}>Låg (64 kbps)</option>
						<option value="medium" ?selected=${this.settings.qualityMobile === 'medium'}>Medel (128 kbps)</option>
						<option value="high" ?selected=${this.settings.qualityMobile === 'high'}>Hög (320 kbps)</option>
					</select>
					<p class="setting-description">Kvalitet när du använder mobildata</p>
				</div>

				<div class="setting-item">
					<label for="qualityDownload">Ljudkvalitet (Nedladdning)</label>
					<select id="qualityDownload" name="qualityDownload" .value=${this.settings.qualityDownload}>
						<option value="low" ?selected=${this.settings.qualityDownload === 'low'}>Låg (64 kbps)</option>
						<option value="medium" ?selected=${this.settings.qualityDownload === 'medium'}>Medel (128 kbps)</option>
						<option value="high" ?selected=${this.settings.qualityDownload === 'high'}>Hög (320 kbps)</option>
					</select>
					<p class="setting-description">Kvalitet för nedladdade låtar</p>
				</div>
			</div>
		`
	}

	#renderStorageSettings () {
		return html`
			<div class="settings-section">
				<h3>Lagringsinställningar</h3>

				<div class="setting-item">
					<label for="maxSongs">Max antal låtar totalt</label>
					<input
						type="number"
						id="maxSongs"
						name="maxSongs"
						min="0"
						.value=${this.settings.maxSongs}
						placeholder="Obegränsat"
					>
					<p class="setting-description">Maximalt antal låtar att ladda ner totalt</p>
				</div>

				<div class="setting-item">
					<label for="maxHours">Max antal timmar totalt</label>
					<input
						type="number"
						id="maxHours"
						name="maxHours"
						min="0"
						.value=${this.settings.maxHours}
						placeholder="Obegränsat"
					>
					<p class="setting-description">Maximalt antal timmar musik att ladda ner</p>
				</div>

				<div class="setting-item">
					<label for="maxSizeGB">Max lagringsstorlek (GB)</label>
					<input
						type="number"
						id="maxSizeGB"
						name="maxSizeGB"
						min="0"
						step="0.1"
						.value=${this.settings.maxSizeGB}
						placeholder="Obegränsat"
					>
					<p class="setting-description">Maximal lagringsstorlek för nedladdade låtar</p>
				</div>

				<div class="setting-item">
					<label for="maxSongsPerStation">Max låtar per station</label>
					<input
						type="number"
						id="maxSongsPerStation"
						name="maxSongsPerStation"
						min="0"
						.value=${this.settings.maxSongsPerStation}
						placeholder="Obegränsat"
					>
					<p class="setting-description">Maximalt antal låtar per radiostation</p>
				</div>

				<div class="setting-item">
					<label for="ttlDays">Tid att leva (dagar)</label>
					<input
						type="number"
						id="ttlDays"
						name="ttlDays"
						min="0"
						.value=${this.settings.ttlDays}
						placeholder="Aldrig"
					>
					<p class="setting-description">Radera gamla låtar efter X dagar</p>
				</div>

				<div class="setting-item">
					<label>
						<input
							type="checkbox"
							name="autoReplaceOld"
							?checked=${this.settings.autoReplaceOld}
						>
						<span>Ersätt gamla låtar automatiskt</span>
					</label>
					<p class="setting-description">Ersätt gamla låtar med nya när lagringsgränsen nås</p>
				</div>

				<div class="setting-item">
					<label>
						<input
							type="checkbox"
							name="wifiOnlyDownload"
							?checked=${this.settings.wifiOnlyDownload}
						>
						<span>Ladda endast ner via WiFi</span>
					</label>
					<p class="setting-description">Förhindra nedladdningar när du använder mobildata</p>
				</div>

				<div class="setting-item">
					<label>
						<input
							type="checkbox"
							name="protectUpvoted"
							?checked=${this.settings.protectUpvoted}
						>
						<span>Skydda uppröstade låtar</span>
					</label>
					<p class="setting-description">Radera aldrig låtar som du har gillat</p>
				</div>
			</div>
		`
	}

	#renderMiscSettings () {
		return html`
			<div class="settings-section">
				<h3>Övriga inställningar</h3>

				<div class="setting-item">
					<label>
						<input
							type="checkbox"
							name="autoOfflineMode"
							?checked=${this.settings.autoOfflineMode}
						>
						<span>Automatisk offline-läge</span>
					</label>
					<p class="setting-description">Byt automatiskt till offline-läge när du inte är ansluten till WiFi</p>
				</div>
			</div>
		`
	}

	// Event handler
	async #requestNotificationPermission () {
		const permission = await Notification.requestPermission()
		if (permission === 'granted') {
			this.settings.notificationsEnabled = true
			this.#saveSettings()
		}
		this.requestUpdate()
	}
}

customElements.define('settings-dialog', SettingsDialog)

export { SettingsDialog }
