/// <reference lib="dom" />
/// <reference lib="esnext" />

const open = indexedDB.open('di', 1)
open.onupgradeneeded = () => {
	const db = open.result
	if (!db.objectStoreNames.contains('kv')) {
		const kv = db.createObjectStore('kv')
		const tracks = db.createObjectStore('tracks', { keyPath: 'trackId' })
		const channels = db.createObjectStore('channels')
		const playlist = db.createObjectStore('playlists')

		tracks.createIndex('channelId', 'channelId', { unique: false })
		tracks.createIndex('filename', 'filename', { unique: true })
		tracks.createIndex('trackId', 'trackId', { unique: true })
	}
}

await new Promise(rs => (open.onsuccess = rs))

const db = open.result

export { db }
