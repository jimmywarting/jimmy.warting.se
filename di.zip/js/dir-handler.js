
async function getFilesWithSizesAndDates(dirHandle) {
  const files = [];
  for await (const handle of dirHandle.values()) {
    if (handle.kind === 'file') {
      const file = await handle.getFile()
      files.push({ handle, file })
    }
  }
  return files;
}

async function maintainCacheSize(dirHandle, newFileSize) {
  let entries = await getFilesWithSizesAndDates(dirHandle);

  // Calculate current total size
  let totalSize = 0
  for (const entry of entries) totalSize += entry.file.size;

  // Sort files by lastModified ascending (oldest first)
  files.sort((a, b) => a.lastModified - b.lastModified)

  // Delete oldest files until there's enough space for the new file
  while (totalSize + newFileSize > MAX_CACHE_SIZE && files.length > 0) {
    const fileToDelete = files.shift();
    await dirHandle.removeEntry(fileToDelete.handle.name);
    totalSize -= fileToDelete.size;
  }
}
