const decoderLatin1 = new TextDecoder("iso-8859-1")
const decoderUtf16 = new TextDecoder("utf-16")
const decoderUtf8 = new TextDecoder("utf-8")

/**
 * @typedef {object} ID3Frame
 * @property {number} encoding - Kodningsbyte för textbaserade ramar.
 * @property {string} frameId - ID för ramen (t.ex. "TIT2").
 * @property {number} flags - Flaggor associerade med ramen.
 * @property {number} offset - Offset i blobben där ramdata börjar.
 * @property {Blob} data - Blob som innehåller ramdata.
 */

// Definiera en symbol för att beskriva ramar, för att undvika namnkollisioner.
const ID3_FRAME_DESCRIPTION = Symbol('description');
const defaultType = { type: 'text/plain; charset=utf-8' }
const terminator = Uint8Array.of(0x00)
const utf8encodingByte = Uint8Array.of(0x03) // UTF-8

// Denna objekt kan antingen vara en statisk egenskap i klassen eller en global konstant.
// För enkelhetens skull, och eftersom det är statisk data, kan den ligga utanför klassen.
const frameDescriptions = {
  // Textramar (T***)
  'AENC': 'Audio encryption',
  'APIC': 'Attached picture',
  'COMM': 'Comments',
  'COMR': 'Commercial frame',
  'ENCR': 'Encryption method registration',
  'EQUA': 'Equalisation',
  'ETCO': 'Event timing codes',
  'GEOB': 'General encapsulated object',
  'GRID': 'Group identification registration',
  'IPLS': 'Involved people list',
  'LINK': 'Linked information',
  'MCDI': 'Music CD identifier',
  'MLLT': 'MPEG location lookup table',
  'OWNE': 'Ownership frame',
  'PRIV': 'Private frame',
  'PCNT': 'Play counter',
  'POPM': 'Popularimeter',
  'POSS': 'Position synchronisation frame',
  'RBUF': 'Recommended buffer size',
  'RVAD': 'Relative volume adjustment',
  'RVRB': 'Reverb',
  'SYLT': 'Synchronized lyric/text',
  'SYTC': 'Synchronized tempo codes',
  'TALB': 'Album/Movie/Show title',
  'TBPM': 'Beats per minute',
  'TCOM': 'Composer',
  'TCON': 'Content type (Genre)',
  'TCOP': 'Copyright message',
  'TDAT': 'Date',
  'TDLY': 'Playlist delay',
  'TENC': 'Encoded by',
  'TEXT': 'Lyricist/Text writer',
  'TFLT': 'File type',
  'TIPL': 'Involved people list',
  'TIT1': 'Content group description',
  'TIT2': 'Title/songname/content description',
  'TIT3': 'Subtitle/Description refinement',
  'TKEY': 'Initial key',
  'TLAN': 'Language(s)',
  'TLEN': 'Length',
  'TMED': 'Media type',
  'TOAL': 'Original album/movie/show title',
  'TOFN': 'Original filename',
  'TOLY': 'Original lyricist(s)/text writer(s)',
  'TOPE': 'Original artist(s)/performer(s)',
  'TOWN': 'File owner/licensee',
  'TPE1': 'Lead performer(s)/Soloist(s)',
  'TPE2': 'Band/orchestra/accompaniment',
  'TPE3': 'Conductor/performer refinement',
  'TPE4': 'Interpreted, remixed, or otherwise modified by',
  'TPOS': 'Part of a set',
  'TPRO': 'Produced notice',
  'TPUB': 'Publisher',
  'TRCK': 'Track number/Position in set',
  'TRDA': 'Recording dates',
  'TRSN': 'Internet radio station name',
  'TRSO': 'Internet radio station owner',
  'TSIZ': 'Size',
  'TSRC': 'ISRC (international standard recording code)',
  'TSSE': 'Software/Hardware and settings used for encoding',
  'TYER': 'Year',
  'TXXX': 'User defined text information frame',

  // URL-ramar (W***)
  'WCOM': 'Commercial information',
  'WCOP': 'Copyright/Legal information',
  'WOAF': 'Official audio file webpage',
  'WOAR': 'Official artist/performer webpage',
  'WOAS': 'Official audio source webpage',
  'WORS': 'Official internet radio station homepage',
  'WPAY': 'Payment',
  'WPUB': 'Publishers official webpage',
  'WXXX': 'User defined URL link frame',

  // Andra ramar
  'PRIV': 'Private frame',
  'PCNT': 'Play counter',
  'POPM': 'Popularimeter',
  'COMM': 'Comments',
  'MCDI': 'Music CD identifier',
  'ETCO': 'Event timing codes',
  'SYLT': 'Synchronized lyric/text',
  'USLT': 'Unsynchronized lyric/text transcription',
  'GEOB': 'General encapsulated object',
  'SIGN': 'Signature frame',
  'SEEK': 'Seek frame',
  'RVRB': 'Reverb',
  'EQU2': 'Equalization (2)',
  'RBUF': 'Recommended buffer size',
  'AENC': 'Audio encryption',
  'ASPI': 'Audio seek point index',

  // Ramar specifika för ID3v2.4
  'MCDI': 'Music CD identifier',
  'TIPL': 'Involved people list',
  'TMCL': 'Musician credits list',
  'IPLS': 'Involved people list',

  // Föråldrade eller sällan använda
  'TDEN': 'Encoding time',
  'TDOR': 'Original release time',
  'TDRC': 'Recording time',
  'TDRL': 'Release time',
  'TDTG': 'Tagging time',

  // Övriga
  'USER': 'Terms of use',
  'COMR': 'Commercial frame',
  'ENCR': 'Encryption method registration',
  'GRID': 'Group identification registration',
  'SEEK': 'Seek frame',
  'SIGN': 'Signature frame',
  'PRIV': 'Private frame',
  'PCNT': 'Play counter',
  'POPM': 'Popularimeter',
  'RBUF': 'Recommended buffer size',
  'RVAD': 'Relative volume adjustment',
  'RVRB': 'Reverb',
  'SYTC': 'Synchronized tempo codes',
  'TDRC': 'Recording time',
  'TDRL': 'Release time',
  'TDTG': 'Tagging time',
  'TIPL': 'Involved people list',
  'TMCL': 'Musician credits list',
  'TSOA': 'Album sort order',
  'TSOP': 'Performer sort order',
  'TSOT': 'Title sort order',
  'TSRC': 'ISRC',
  'TSSE': 'Software/Hardware and settings used for encoding',
  'TSST': 'Set subtitle',
  'UFID': 'Unique file identifier',
}

/**
 * En klass för att parsa och hantera ID3-taggar (v1 och v2) i ljudfiler (Blobs/Files).
 */
class ID3Parser {
  static TERMINATOR = terminator
  static UTF8 = utf8encodingByte

  // Privata egenskaper för att lagra parsade data
  v1 = null;
  v2 = null;
  /** @type {ID3Frame[]} */
  frames = [];
  audioData = null;
  padding = null;
  #mp3 = null;

  /**
   * Konstruerar en ID3Parser-instans.
   * @param {Blob | File} fileBlob - Ljudfilen eller blobben att parsa.
   * @param {string} [fileName='audio.mp3'] - Namnet på filen, används för rekonstruktion.
   * @throws {Error} Om input inte är en Blob eller File.
   */
  constructor(fileBlob) {
    if (!(fileBlob instanceof Blob)) {
      throw new Error("Input måste vara en Blob eller File.");
    }
    this.#mp3 = fileBlob;
  }

  /**
   * Hjälpfunktion för att parsa en ID3v1-tagg från en Uint8Array.
   * @param {Uint8Array} view - Uint8Array som innehåller ID3v1-taggen.
   * @returns {object | null} Den parsade ID3v1-taggdatan, eller null om den inte hittades.
   */
  static #parseID3v1(view) {
    // Kontrollera "TAG"-identifierare i början av vyn
    if (view[0] !== 0x54 || view[1] !== 0x41 || view[2] !== 0x47) {
      return null;
    }
    const decoder = new TextDecoder("iso-8859-1");

    return {
      title: decoder.decode(view.slice(3, 33)).replace(/\0/g, '').trim(), // Ta bort nollbyten och trimma
      artist: decoder.decode(view.slice(33, 63)).replace(/\0/g, '').trim(),
      album: decoder.decode(view.slice(63, 93)).replace(/\0/g, '').trim(),
      year: decoder.decode(view.slice(93, 97)).replace(/\0/g, '').trim(),
      comment: decoder.decode(view.slice(97, 127)).replace(/\0/g, '').trim(),
      genreByte: view[127]
    };
  }

  /**
   * Hjälpfunktion för att avkoda textbyten baserat på kodningsbyte.
   * @param {Uint8Array} bytes - Byten att avkoda.
   * @param {number} encodingByte - Kodningstypen (0=ISO-8859-1, 1=UTF-16 med BOM, 2=UTF-16BE, 3=UTF-8).
   * @returns {string} Den avkodade texten.
   */
  static #decodeText(bytes, encodingByte) {
    switch (encodingByte) {
      case 0: // ISO-8859-1 (Latin-1)
        return new TextDecoder('latin1').decode(bytes).replace(/\0/g, '').trim();
      case 1: // UTF-16 med BOM
        return new TextDecoder('utf-16').decode(bytes).replace(/\0/g, '').trim();
      case 2: // UTF-16BE utan BOM
        return new TextDecoder('utf-16be').decode(bytes).replace(/\0/g, '').trim();
      case 3: // UTF-8
        return new TextDecoder('utf-8').decode(bytes).replace(/\0/g, '').trim();
      default:
        console.warn(`Okänd textkodningsbyte: ${encodingByte}. Återgår till standard TextDecoder.`);
        return new TextDecoder().decode(bytes).replace(/\0/g, '').trim();
    }
  }

  static #synchsafeInteger(bytes) {
    return (bytes[0] << 21) | (bytes[1] << 14) | (bytes[2] << 7) | bytes[3];
  }

  describeFrame(id) {
    return frameDescriptions[id] ?? 'Okänd ram';
  }

  /**
   * Hjälpfunktion för att parsa en ID3v2-header från en Uint8Array.
   * @param {Uint8Array} view - Uint8Array som innehåller ID3v2-headern.
   * @returns {object | null} Den parsade ID3v2-headerdatan, eller null om det inte är en ID3v2-header.
   */
  static parseID3v2Header(view) {
    // Kontrollera "ID3"-identifierare
    if (view[0] !== 0x49 || view[1] !== 0x44 || view[2] !== 0x33) {
      return null;
    }

    const version = view[3];
    const revision = view[4];
    const flags = view[5];
    // ID3v2 tag-storlek är kodad i 4 byte, där den mest signifikanta biten i varje byte är 0 (synchsafe integer).
    const size =
      ((view[6] & 0x7f) << 21) |
      ((view[7] & 0x7f) << 14) |
      ((view[8] & 0x7f) << 7) |
      (view[9] & 0x7f);

    const result = {
      versionMajor: version,
      versionMinor: revision,
      flags,
      tagSize: size, // Den initialt parsade taggstorleken
      totalSize: 10 + size, // Headerstorlek (10 byte) + Taggdata storlek
      blob: null // Detta kommer att ställas in dynamiskt efter att ramar har parsats
    };

    return result;
  }

  /**
   * Läser och avkodar innehållet i en textram.
   * @param {object} frame - Blobben som innehåller de råa ramdata (inklusive kodningsbyte).
   * @returns {Promise<string>} Ett promise som löser sig med den avkodade texten.
   */
  static async readTextFrame(frame) {
    if (!frame || !frame.data) {
      throw new Error("Invalid frame object provided.");
    }
    const frameBytes = await frame.data.bytes();
    const encodingByte = frameBytes[0];
    const textBytes = frameBytes.slice(1);
    // frame.data.slice(1,frame.data.size, frame.data.type).bytes().then(console.log)
    return ID3Parser.#decodeText(textBytes, encodingByte);
  }

  /**
   * Initierar parsingsprocessen. Denna metod bör anropas efter instansiering.
   */
  async init () {
    const blob = this.#mp3
    const { size } = blob

    // Läs de första 10 byten för ID3v2-headern och de sista 128 byten för ID3v1-taggen.
    const combinedBlob = new Blob([
      blob.slice(0, 10),
      blob.slice(size - 128)
    ]);

    const bytes = await combinedBlob.bytes();
    const headerBytes = bytes.slice(0, 10);
    const footerBytes = bytes.slice(10); // Detta är den potentiella ID3v1-taggen

    this.v2 = ID3Parser.parseID3v2Header(headerBytes);
    this.v1 = ID3Parser.#parseID3v1(footerBytes);

    // Om ID3v1-tagg hittas, lagra dess blob för potentiell omskrivning
    if (this.v1) {
      this.v1.blob = blob.slice(size - 128, size);
    }

    let offset = 10; // Börja läsa ramar efter ID3v2-headern

    if (this.v2) {
      const frames = this.frames; // Fånga this.frames för closure

      // Loopa genom blobben för att hitta och parsa ID3v2-ramar
      while (offset < this.v2.totalSize) {
        // Läs de nästa 10 byten för ram-headern
        const frameHeaderBytes = await blob.slice(offset, offset + 11).bytes();
        const frameId = new TextDecoder("iso-8859-1").decode(frameHeaderBytes.slice(0, 4));

        // Stoppa om frameId är padding (alla nollor) eller ogiltig
        if (/^\0{4}$/.test(frameId)) {
          this.padding = {
            [ID3_FRAME_DESCRIPTION]: 'Padding',
            offset: offset,
            data: blob.slice(offset, this.v2.totalSize)
          };
          break; // Slut på ramar, resten är padding
        }

        // Ramstorleken är 4 byte, icke-synchsafe integer
        const frameSize =
          (frameHeaderBytes[4] << 24) |
          (frameHeaderBytes[5] << 16) |
          (frameHeaderBytes[6] << 8) |
          frameHeaderBytes[7];

        // Om frameSize är 0 eller sträcker sig utanför ID3v2-taggen, sluta läsa
        if (frameSize <= 0 || offset + 10 + frameSize > this.v2.totalSize) {
          // Om det fortfarande finns data mellan nuvarande offset och totalSize, är det padding
          if (offset < this.v2.totalSize) {
            this.padding = {
              [ID3_FRAME_DESCRIPTION]: 'Padding',
              offset: offset,
              data: blob.slice(offset, this.v2.totalSize)
            };
          }
          break;
        }

        let encoding = null
        let type = ''

        if (frameId[0] === 'T' || frameId === 'APIC') {
          encoding = frameHeaderBytes[10]; // Kodningsbyte för textbaserade ramar
          type = 'text/plain' +
            ( encoding === 0 ? '; charset=iso-8859-1'
            : encoding === 1 ? '; charset=utf-16'
            : encoding === 2 ? '; charset=utf-16be'
            : encoding === 3 ? '; charset=utf-8'
            : '');
        }

        const frame = {
          [ID3_FRAME_DESCRIPTION]: frameDescriptions[frameId] || 'Okänd ram',
          encoding,
          frameId: frameId,
          // Flaggor är 2 byte
          flags: (frameHeaderBytes[8] << 8) | frameHeaderBytes[9],
          offset: offset + 10, // Data börjar efter den 10-byte långa headern
          data: blob.slice(offset + 10, offset + 10 + frameSize, type)
        }

        frames.push(frame)

        offset += 10 + frameSize; // Flytta offset till början av nästa ram
      }

      const self = this

      Object.defineProperties(this.v2, {
        // Lägg till dynamiska getters för tagSize och totalSize för ID3v2-objektet
        // Detta säkerställer att storlekarna uppdateras om ramar ändras.
        tagSize: {
          get() {
            let calculatedSize = 0;
            for (const frame of frames) {
              calculatedSize += frame.data.size + 10; // 10 byte för ramens header
            }
            return calculatedSize;
          },
          enumerable: true
        },
        totalSize: {
          get() {
            return this.tagSize + 10; // Headerstorlek + taggstorlek
          },
          enumerable: true
        },
        // Dynamiskt lägg till en getter till #v2-objektet för att rekonstruera dess blob
        blob: {
          get() {
            const calculatedTagSize = this.tagSize; // Använd den dynamiska taggstorleken

            // Update id3v2 till 2.4
            headerBytes[3] = this.versionMajor;

            // Använd de ursprungliga headerbyten för att modifiera storleken
            // Uppdatera taggstorleken i headern (synchsafe integer)
            headerBytes[6] = (calculatedTagSize >> 21) & 0x7f;
            headerBytes[7] = (calculatedTagSize >> 14) & 0x7f;
            headerBytes[8] = (calculatedTagSize >> 7) & 0x7f;
            headerBytes[9] = calculatedTagSize & 0x7f;

            const frameBlobs = self.frames.map(frame => {
              const frameHeader = new Uint8Array(10);

              // Sätt Frame ID
              for (let i = 0; i < 4; i++) {
                frameHeader[i] = frame.frameId.charCodeAt(i);
              }

              // Sätt ramstorlek (4 byte, big-endian, INTE synchsafe för ID3v2.3/2.4)
              const size = frame.data.size;
              frameHeader[4] = (size >> 24) & 0xFF;
              frameHeader[5] = (size >> 16) & 0xFF;
              frameHeader[6] = (size >> 8) & 0xFF;
              frameHeader[7] = size & 0xFF;

              // Sätt flaggor
              frameHeader[8] = (frame.flags >> 8) & 0xFF;
              frameHeader[9] = frame.flags & 0xFF;

              return new Blob([frameHeader, frame.data]);
            })

            // ID3v2-taggblobben består av den uppdaterade headern och alla ramblobs
            return new Blob([headerBytes, ...frameBlobs]);
          }
        }
      })
    }

    // Bestäm ljuddatabloben
    const audioStartOffset = this.v2 ? this.v2.totalSize : 0;
    const audioEndOffset = this.v1 ? blob.size - 128 : blob.size;

    this.audioData = {
      [ID3_FRAME_DESCRIPTION]: 'Audio data',
      offset: audioStartOffset,
      data: blob.slice(audioStartOffset, audioEndOffset)
    }

    return this
  }

  static async readPictureFrame(frame) {
    const blob = frame.data
    const encodingByte = frame.encoding

    const encoding =
      encodingByte === 0x00 ? 'iso-8859-1' :
      encodingByte === 0x01 ? 'utf-16' :
      encodingByte === 0x03 ? 'utf-8' :
      null

    if (!encoding) throw new Error('Okänd encoding: ' + encodingByte)

    const decoder = new TextDecoder(encoding)
    const ascii = new TextDecoder('ascii')

    const chunkSize = 256
    let readBytes = 0 // start directly at encodingByte
    let buffer = new Uint8Array(0)

    let mimeEnd = -1
    let descEnd = -1
    let pictureTypeIndex = -1
    let descriptionStart = -1
    let offset = -1

    let done = false

    while (!done) {
      const chunk = new Uint8Array(await blob.slice(readBytes, readBytes + chunkSize).arrayBuffer())
      const merged = new Uint8Array(buffer.length + chunk.length)
      merged.set(buffer)
      merged.set(chunk, buffer.length)
      buffer = merged

      // MIME slutar vid första null
      if (mimeEnd === -1) {
        mimeEnd = buffer.indexOf(0x00, 1)
        if (mimeEnd === -1) {
          readBytes += chunkSize
          continue
        }
        pictureTypeIndex = mimeEnd + 1
        descriptionStart = mimeEnd + 2
      }

      // Description slutar olika beroende på encoding
      if (encodingByte === 0x01) {
        // UTF-16 terminator = 0x00 0x00
        for (let i = descriptionStart; i < buffer.length - 1; i += 2) {
          if (buffer[i] === 0x00 && buffer[i + 1] === 0x00) {
            descEnd = i
            offset = i + 2
            done = true
            break
          }
        }
      } else {
        // Latin1/UTF-8 = enkel null
        descEnd = buffer.indexOf(0x00, descriptionStart)
        if (descEnd !== -1) {
          offset = descEnd + 1
          done = true
        }
      }

      readBytes += chunkSize
      if (readBytes > blob.size) throw new Error('Kunde inte hitta slut på description')
    }

    // offset++
    const mime = ascii.decode(buffer.slice(1, mimeEnd))
    const pictureType = buffer[pictureTypeIndex]
    const description = decoder.decode(buffer.slice(descriptionStart, descEnd))

    const imageBlob = blob.slice(offset)
    const fileName = `image.${mime.split('/').pop() || 'bin'}`

    return {
      pictureType,
      description,
      offset,
      data: new File([imageBlob], fileName, { type: mime })
    }
  }

  set (frameId, data, encoding = null) {
    if (typeof data === 'string') {
      encoding = 3
      data = new Blob([utf8encodingByte, data], defaultType)
    }

    // skriver över första ramen
    const frame = this.get(frameId)
    if (frame) {
      frame.encoding = encoding || frame.encoding
      frame.data = data
    } else {
      this.frames.push({
        [ID3_FRAME_DESCRIPTION]: frameDescriptions[frameId] || 'Okänd ram',
        frameId,
        encoding,
        offset: this.getOffset(),
        flags: 0,
        data
      })
    }
  }

  get (frameId) {
    // Hitta den första ramen med det angivna frameId
    return this.frames.find(frame => frame.frameId === frameId) || null;
  }

  has (frameId) {
    // Kontrollera om det finns en ram med det angivna frameId
    return this.frames.some(frame => frame.frameId === frameId);
  }

  getAll (frameId) {
    // Hitta alla ramar med det angivna frameId
    return this.frames.filter(frame => frame.frameId === frameId);
  }

  deleteAll (...frameIds) {
    // Ta bort alla ramar med det angivna frameId
    const arr = this.frames

    // - Måste iterera baklänges för att undvika indexproblem vid borttagning
    // - Kan inte använda filter() eftersom det inte modifierar den ursprungliga arrayen
    for (let i = arr.length; i--;) {
      if (frameIds.includes(arr[i].frameId)) {
        arr.splice(i, 1)
      }
    }
  }

  delete (frame) {
    // Ta bort en specifik ram från listan
    const index = this.frames.indexOf(frame);
    if (index !== -1) {
      this.frames.splice(index, 1);
    }
  }

  getOffset (frame) {
    let offset = 20
    for (const cur of this.frames) {
      if (frame === cur) break
      offset += cur.data.size + 10
    }
    return offset
  }

  static createAPIC(file, pictureType = 3, description = '') {
    const textEncoder = new TextEncoder() // UTF-8 by default

    return {
      encoding: 3,
      frameId: 'APIC',
      flags: 0,
      data: new Blob([
        utf8encodingByte,
        textEncoder.encode(file.type),
        terminator,
        Uint8Array.of(pictureType),
        textEncoder.encode(description),
        terminator,
        file
      ], defaultType)
    }
  }

  async updateToUTF8 () {
    // Uppdatera alla textbaserade ramar till UTF-8
    for (const frame of this.frames) {
      if (frame.frameId.startsWith('T') && frame.encoding !== 3) {
        const text = await ID3Parser.readTextFrame(frame)
        frame.data = new Blob([utf8encodingByte, text], defaultType);
        frame.encoding = 3; // Sätt kodning till UTF-8
      } else if (frame.frameId === 'APIC') {
        const pic = await ID3Parser.readPictureFrame(frame)
        Object.assign(frame, ID3Parser.createAPIC(pic.data, pic.pictureType, pic.description))
      }
    }
    return this
  }

  /**
   * Uppdaterar innehållet i en textram. Sparas alltid i UTF-8
   * @param {object} frame - Ramobjektet att uppdatera.
   * @param {string} newText - Det nya textinnehållet.
   */
  updateTextFrame(frame, newText) {
    const frameContentBytes = new TextEncoder().encode('\x03' + newText)
    this.setFrameData(frame, new Blob([frameContentBytes]));
  }

  /**
   * Rekonstruerar hela ljudfilen som en Blob.
   * Denna getter kombinerar den uppdaterade ID3v2-taggen, padding, ljuddata och ID3v1-taggen.
   * @returns {Promise<File>} Ett promise som löser sig med det rekonstruerade File-objektet.
   */
  get file() {
    const parts = [];

    // Lägg till ID3v2-tagg-bloben om den finns
    parts.push(this.v2?.blob || '');

    // Lägg till padding om det finns
    parts.push(this.padding?.data || '');

    // Lägg till ljuddata
    parts.push(this.audioData?.data || '');

    // Lägg till ID3v1-tagg-bloben om den finns
    parts.push(this.v1?.blob || '');

    return new File(parts, this.#mp3.name || 'music.mp3', {
      type: 'audio/mpeg',
      lastModified: Date.now()
    })
  }
}

// blob.slice(readBytes, readBytes + chunkSize, blob.type).text().then(text => {
//   const result = text.split('\x00').slice(0, 3).join(', ')
//   const [mimeType, pictureType, description] = result.split(', ');
//   console.log(`MIME: ${mimeType}, Picture Type: ${pictureType && pictureType.charCodeAt(0) || 0}, Description: ${description}`);
// })


export {
  ID3Parser,
  terminator,
  utf8encodingByte
}

/*
// const webp = await fetch('https://httpbin.org/image/webp').then(res => res.blob());
new ID3Parser(blob, 'test.mp3').init().then(async id3 => {
  for (const frame of id3.frames) {
    if (frame.frameId.startsWith('T') && frame.encoding !== 3) {
      const text = await ID3Parser.readTextFrame(frame)
      frame.data = new Blob([utf8, text], { type: 'text/plain; charset=utf-8' })
      frame.encoding = 3
    } else if (frame.frameId === 'APIC') {
      const pic = await ID3Parser.readPictureFrame(frame);
      frame.data = new Blob([utf8, pic.data.type, nullish, String.fromCharCode(pic.pictureType), 'image', nullish, pic.data ]);
    }
  }

  const v1 = id3.v1
  if (v1) {
    const mapping = {
      title: 'TIT2',
      artist: 'TPE1',
      album: 'TALB',
      year: 'TYER',
    }

    for (const [key, val] of Object.entries(mapping)) {
      if (v1[key] && !id3.has(key)) {
        id3.set(key, val)
      }
    }
  }

  delete id3.v1
  id3.v2.versionMajor = 4

  // writeFile('music.mp3', await id3.file.bytes(), console.log)
})
*/

globalThis.ID3Parser = ID3Parser