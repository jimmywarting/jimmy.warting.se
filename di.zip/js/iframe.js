class SandboxAudio {
  /** @type {SandboxAudio} */
  static instance

  static getInstance () {
    return SandboxAudio.instance ??= new SandboxAudio()
  }

  constructor () {
    const jsCode = () => {
      const audio = new Audio()
      globalThis.audio = audio
      audio.crossOrigin = 'anonymous'
      audio.autoplay = true
      globalThis.audio = audio

      onmessage = evt => {
        const [port] = evt.ports

        const mediaEvents = [
          'abort', 'canplay', 'canplaythrough', 'durationchange', 'emptied',
          'ended', 'error', 'loadeddata', 'loadedmetadata', 'loadstart',
          'pause', 'play', 'playing', 'progress', 'ratechange', 'seeked',
          'seeking', 'stalled', 'suspend', 'waiting', 'volumechange',
          'timeupdate'
        ]

        mediaEvents.forEach(eventType => {
          audio.addEventListener(eventType, () => {
            port.postMessage({
              type: 'event',
              event: eventType,
              state: {
                currentTime: audio.currentTime,
                duration: audio.duration,
                paused: audio.paused,
                volume: audio.volume,
                src: audio.src,
                muted: audio.muted
              }
            })
          })
        })

        port.onmessage = e => {
          console.log(e)
          const { type, key, value, args } = e.data
          switch (type) {
            case 'set': audio[key] = value; break
            case 'call':
              try { audio[key](...(args || [])) }
              catch (err) { console.error(err) }
              break
          }
          console.log(audio[key])
        }
      }
    }

    const code = `<script>(${jsCode.toString()})()</script>`
    const blob = new Blob([code], { type: 'text/html' })
    const url = URL.createObjectURL(blob)

    const iframe = document.createElement('iframe')
    iframe.src = url
    iframe.sandbox = 'allow-scripts'
    iframe.allow = 'autoplay'
    iframe.hidden = true

    const mc = new MessageChannel()
    mc.port1.start()

    iframe.onload = () => {
      URL.revokeObjectURL(url)
      iframe.contentWindow.postMessage({ s: 1 }, '*', [mc.port2])
      iframe.onload = null
    }

    document.body.appendChild(iframe)

    this.port1 = mc.port1
  }

  set (key, value) {
    console.log('SandboxAudio set', key, value)
    this.port1.postMessage({ type: 'set', key, value })
  }

  call (method, args = []) {
    this.port1.postMessage({ type: 'call', key: method, args })
  }
}

export { SandboxAudio }