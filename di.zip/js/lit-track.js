import nameify from 'https://cdn.jsdelivr.net/npm/filenamify@7.0.1/filenamify.js/+esm'
import { db } from './db.js'
import { ID3Parser } from './id3.js'
import { audioAddict } from './audioAddict.js'

const q = () => db.transaction('tracks', 'readwrite').objectStore('tracks')
const qq = (tx, success, failure) => {
	tx.onsuccess = e => success(e.target.result)
	failure && (tx.onerror = e => failure(e.target.error))
}

class Track {
	#asset

	constructor (obj) {
		Object.assign(this, obj)
	}

	set asset (asset) { this.#asset = asset }
	get asset () {
		if (this.#asset) {
			// figure out the expiration date
			const url = new URL(this.#asset.url)
			const exp = +new Date(url.searchParams.get('exp'))

			// check if it will last for the duration of the track
			if (exp > (Date.now() + this.duration * 1000)) {
				// if it will last for the duration of the track, return it
				return this.#asset
			} else {
				this.#asset = null
			}
		}

		return audioAddict.getTrack(this).then(track => {
			this.votes ??= {}
			this.votes.up = track.votes.up
			this.votes.down = track.votes.down
			this.#asset = track.content.assets[0]
			return this.#asset
		})
	}

	skip () {
		this.timesSkipped++
		this.save()
		this.elm.nextSibling.track.play()
	}

	async getRemoteId3TagSize () {
		if (this.metadata.RemoteId3TagSize) {
			return this.metadata.RemoteId3TagSize
		}

		const uint8 = await this.#fetch({ range: 'bytes=0-10' })
		const { totalSize, ...rest } = ID3Parser.parseID3v2Header(uint8)
		console.log({rest})
		this.metadata.remoteId3TagSize = totalSize
		this.save()

		return totalSize
	}

	async #fetch (headers = {}, as = 'bytes') {
		const res = await fetch((await this.asset).url, { headers })
		return res === 'res' ? res : res[as]()
	}

	async getImage () {
		// Return cached blob if available
		if (this.images.blob) {
			return this.images.blob
		}

		// Check if we have a local file and get image from APIC if available
		if (this.metadata.fileHandle) {
			const id3 = await this.getId3()
			const frame = id3.get('APIC')
			if (frame) {
				const pic = await ID3Parser.readPictureFrame(frame)
				return pic.data
			}
		}

		// Check if we have a remote byte range for the image
		// if so, fetch that image from the server and cache it
		if (this.images.byteRange) {
			const res = await this.#fetch({ range: this.images.byteRange }, 'res')
			const file = await res.file({
				type: this.images.type,
				name: 'image.' + this.images.type.split('/').pop()
			})
			this.images.blob = file
			this.save()
			return
		}

		// Otherwise, get remote ID3 and extract original ID3 frames and get APIC
		const id3 = await this.getId3()
		const frame = id3.get('APIC')

		if (frame) {
			// If APIC frame exists, read and cache it
			const pic = await ID3Parser.readPictureFrame(frame)
			const offset = frame.offset + pic.offset
			const { type, size } = pic.data
			const byteRange = `bytes=${offset}-${offset + size - 1}`
			this.images.byteRange = byteRange
			this.images.type = type
			this.images.hasAPIC = true
			this.images.blob = pic.data
			this.save()
		} else {
			// Fallback: fetch image which isn't attached in APIC and is instead
			// hosted remotely... this CDN is unfortunately CORS blocked, so we need
			// to proxy it
			this.images.hasAPIC = false
			const q = new URLSearchParams({
				cors: JSON.stringify({ url: this.images.default })
			})
			const res = await fetch('https://adv-cors.deno.dev/?' + q)
			if (!res.ok) {
				throw new Error('Failed to fetch image: ' + res.statusText)
			}
			// Cache the fetched image blob
			this.images.blob = await res.file({ type: 'image/jpeg' })
			this.save()
		}

		return this.images.blob
	}

	get channel () {
		return config.channels.by({ id: this.channelId })
	}

	async sync () {
		const dir = audioDir.getDirectoryHandle(this.channel.name, { create: false })
		for await (const [name, handle] of await dir) {
			if (handle.kind === 'file' && name.endsWith('.mp3')) {
				const ufid = await lazy(handle).getFile().slice(20, 54).bytes()
				const owner = UFID_OWNER.every((v, i) => v === ufid[i])

				if (!owner) return

				const dv = new DataView(ufid.buffer, 12)

				const trackId = dv.getUint32(0)
				const channelId = dv.getUint32(4)
				const channel = config.channels.by({ id: channelId })
				const playCount = dv.getUint32(30)

				qq(q().index('trackId').get(trackId), async track => {
					if (track) return
					track = await audioAddict.getTrackWithoutContent(
						trackId,
						channelId
					)
					track = Track.fromTrackAndChannel(track, channel)
					track.metadata.fileHandle = handle
					track.filename = handle.name
					track.PCNT = playCount
					track.save()
				}, console.error)
			}
		}
	}

	static fromTrackAndChannel (track, channel) {
		const asset = track.content.assets[0]
		const filename = nameify(track.track + '.' + asset.ext)
		const UFID = new DataView(new ArrayBuffer(8))
		UFID.setUint32(0, track.id)
		UFID.setUint32(4, channel.id)

		return new Track({
			asset,
			artist: track.artist,
			title: track.title,
			track: track.track,
			displayArtist: track.displayArtist,
			displayTitle: track.displayTitle,
			mix: track.mix,
			duration: Math.floor(track.length),
			images: track.images,
			trackId: track.id,
			version: track.version,
			channelId: channel.id,
			isrc: track.isrc,
			filename,
			isExplicit: !!track.parentalAdvisory,
			UFID,

			lastPlaybackRate: 1,
			lastVolume: 1,

			timestamps: {
				downloaded: new Date(), // När låten laddades ner
				releaseDate: null, // Låtens release datum
				lastMetadataUpdate: null, // när metadata senast uppdaterades
				metadataFetchedAt: null, // senast hämtade metadata (ex: up/down votes)
				events: [] // lyssnings event för låten
			},
			votes: {
				up: track.votes.up,
				down: track.votes.down,
				me: null
			},
			metadata: {
				formatId: asset.content_format_id,
				qualityId: asset.content_quality_id,
				size: asset.size,
				fileHandle: null
			}
		})
	}

	async getId3 () {
		if (this.metadata.fileHandle) {
			const file = await this.metadata.fileHandle.getFile()
			return new ID3Parser(file).init()
		} else {
			const tagSize = await this.getRemoteId3TagSize()
			const uint8 = await this.#fetch({ range: 'bytes=0-' + tagSize }, 'blob')
			return new ID3Parser(uint8).init()
		}
	}

	async download () {
		if (this.metadata.fileHandle) return

		dataset.state = 'loading'
		const res = await fetch((await this.asset).url)
		res.clone().body.pipeTo(new WritableStream({
			write (chunk) { progress.value += chunk.length }
		}))
		const file = await res.file({ name: this.filename })
		const id3 = await lazy(new ID3Parser(file)).init()

		const frame = id3.get('APIC')
		if (frame) {
			const pic = await ID3Parser.readPictureFrame(frame)
			const file = await pic.data.convertToImage('webp', 0.9)
			Object.assign(frame, ID3Parser.createAPIC(file, 3, pic.description))
		} else {
			const img = await this.getImage()
			const file = await img.convertToImage('webp', 0.9)
			const apic = ID3Parser.createAPIC(file)
			id3.frames.push(apic)
		}

		// This will be overwritten later
		id3.deleteAll('TCON', 'TALB')

		// UFID and PCNT frames go first because they are fixed size and easy to
		// read and update without a id3 parser
		id3.frames.unshift({
			frameId: 'UFID', // Unique File Identifier
			flags: 0,
			data: new Blob([UFID_OWNER, this.UFID])
		}, {
			frameId: 'TCON', // Genre
			flags: 0,
			data: new Blob([ID3Parser.UTF8, this.channel.name])
		}, {
			frameId: 'TALB', // Album
			flags: 0,
			data: new Blob([ID3Parser.UTF8, this.channel.name])
		})

		if (this.isrc) {
			id3.frames.push({
				frameId: 'TSRC', // ISRC - International Standard Recording Code
				flags: 0,
				data: new Blob([ID3Parser.UTF8, this.isrc])
			})
		}

		delete id3.v1
		const channelDir = await audioDir.getDirectoryHandle(this.channel.name, { create: true })
		const fileHandle = await channelDir.getFileHandle(this.filename, { create: true })
		const writable = await fileHandle.createWritable()

		await writable.write({ type: 'write', position: 0, data: id3.file })
		await writable.close()
		progress.value = progress.max
		this.metadata.fileHandle = fileHandle
		this.metadata.lastModifiedDate = file.lastModifiedDate
		this.metadata.localSize = file.size
		this.images = { default: this.images.default }
		this.save()
		dataset.state = 'done'
	}

	async updateId3PlayCount () {
		if (!this.metadata.fileHandle) return

		/** @type {FileSystemFileHandle} */
		const handle = this.metadata.fileHandle
		const writable = await handle.createWritable({
			keepExistingData: true
		})

		const PCNT = new DataView(new ArrayBuffer(4))
		PCNT.setUint32(0, this.PCNT)

		await writable.write({
			type: 'write',
			position: 50,
			data: PCNT
		})

		await writable.close()
	}

	get network () {
		return config.networks.by({ id: this.channel.networkId })
	}

	get networkId () {
		return this.network.id
	}

	get networkKey () {
		return this.network.key
	}

	async play () {
		// await this.download()
		const meta = this.metadata
		if (meta.fileHandle) {
			const file = await meta.fileHandle.getFile()
			player.src = file.url
			player.play().catch(() => {})
		} else {
			const asset = await this.asset
			player.src = asset.url
			player.play().catch(() => {})
		}
		trackName.innerText = player.title = this.track
		currentTrack = this
		this.timesStarted++
		this.save()
		this.elm.nextSibling?.track?.download()
		votedUp.innerText = this.votes?.up || 0
		votedDown.innerText = this.votes?.down || 0
		stars.innerText = calculateRating(this.votes?.up || 0, this.votes?.down || 0)
	}

	save () {
		qq(q().put(this), () => {}, console.error)
	}
}

export { Track }
