import { LitElement, html } from 'https://cdn.jsdelivr.net/gh/lit/dist@3/core/lit-core.min.js'
import './polyfills.js'
// import { audioAddict } from './audioaddict.js'
import { db } from './db.js'
import { Track } from './lit-track.js'
import { audioPlayer } from './audio-player.js'
import { importState } from './global-store.js'
import './components/playlist-view.js'
import './components/radio-network-selector.js'
import './components/hero.js'
import './components/player-ui.js'
import './components/settings-dialog.js'
import './components/download-dialog.js'
import { InfoIcon, SettingsIcon } from './icons.js'
import style from './lit.css' with { type: 'css' }

importState(globalThis.config.state)
// const iterableToSignal = (transformer =>
//   (items, init = [], s = signal(init)) => transformer(items, s), s
// )(async (items, s) => { for await (const item of items) s.set(item) })


const q = () => db.transaction('tracks', 'readwrite').objectStore('tracks')
const qq = (tx, success, failure) => {
	tx.onsuccess = e => success(e.target.result)
	failure && (tx.onerror = e => failure(e.target.error))
}

// HJÄLPFUNKTIONER FÖR FORMATERING AV STATISTIK
function formatDurationHours (seconds) {
	const totalHours = seconds / 3600

	if (totalHours >= 24) {
		const days = Math.floor(totalHours / 24)
		const remainingHours = (totalHours % 24)
		const hourPart = remainingHours.toFixed(1) > 0.1 ? ` ${remainingHours.toFixed(1)}h` : ''

		return `${days}d${hourPart}`
	}

	return `${totalHours.toFixed(1)}h`
}

function formatSize (mb) {
	if (mb >= 1024 * 1024) {
		return `${(mb / 1024 / 1024).toFixed(1)} TB`
	} else if (mb >= 1024) {
		return `${(mb / 1024).toFixed(1)} GB`
	}
	return `${mb.toFixed(1)} MB`
}

class MusicPlayer extends LitElement {
	static properties = {
		tracks: { type: Array },
		frequentlyPlayed: { type: Array },
		activeIndex: { type: Number },
		albums: { type: Array },
		tags: { type: Array },
		activeTag: { type: String },
		isOfflineMode: { type: Boolean },
		tagCounts: { type: Object },
		aggregatedStats: { type: Object },
		includeMetadata: { type: Boolean },
		showConfirmDeletion: { type: Boolean },
		view: { type: String },
		showMetadataTooltip: { type: Boolean },
		// NYTT: Håller den kanal som användaren klickade på för att se spellistan
		activeChannel: { type: Object },
		// Player state properties (bound to audioPlayer)
		currentTrack: { type: Object },
		isPlaying: { type: Boolean },
		currentTime: { type: Number },
		duration: { type: Number },
		volume: { type: Number },
	}

	constructor () {
		super()
    console.dir(this)
		this.networks = config.networks
		this.activeIndex = 0
		this.isOfflineMode = false
		this.tagCounts = {}
		this.aggregatedStats = {}
		this.includeMetadata = false
		this.showConfirmDeletion = false
		this.view = 'main' // Standardvy
		this.showMetadataTooltip = false
		this.activeChannel = null

		// Initialize player state from audioPlayer
		this.currentTrack = audioPlayer.currentTrack
		this.isPlaying = audioPlayer.isPlaying
		this.duration = audioPlayer.duration
		this.volume = audioPlayer.volume

		audioPlayer.addEventListener('trackchange', (e) => {
			this.currentTrack = e.detail.track
		})

		this.loadStationData(0)
	}

	resetConfirmation () {
		this.showConfirmDeletion = false
	}

	confirmDeletion () {
		const channelsToClear = this.getFilteredChannels()
		const shouldClearMetadata = this.includeMetadata

		channelsToClear.forEach(channel => {
			// Rensa nedladdad statistik
			channel.downloadedSongs = 0
			channel.downloadedDuration = 0
			channel.downloadedSizeMB = 0

			if (shouldClearMetadata) {
				// Rensa metadata (totala låtar etc.)
				channel.totalSongs = 0
				channel.totalDuration = 0
				channel.totalSizeMB = 0
			}
		})

		this.resetConfirmation()
		this.calculateAggregatedStats()
		this.requestUpdate()
	}

	getFilteredChannels () {
		let channelsByTag = this.channels.filter(channel =>
			this.activeTag.channels.includes(channel.id)
		)

		if (this.isOfflineMode) {
			channelsByTag = channelsByTag.filter(album => album.downloadedSongs > 0)
		}

		return channelsByTag
	}

	loadStationData (index) {
		this.activeIndex = index

		const networkId = this.networks[index].id

		if (!networkId) {
			this.tags = []
			this.channels = []
			this.activeTag = 'ALL'
			this.aggregatedStats = {}
			this.requestUpdate()
			return
		}

		const newData = config.channels.filter(channel => channel.networkId === networkId)

		this.tags = config.filters.filter(filter => filter.networkId === networkId)
		this.channels = newData
		this.activeTag = this.tags[0]

		this.calculateTagCounts()
		this.calculateAggregatedStats()
	}

	calculateTagCounts () {
		return
		const newCounts = {}
		const filterableChannels = this.channels

		// const filterableChannels = this.isOfflineMode
		//     ? this.channels.filter(channel => channel.downloadedSongs > 0)
		//     : this.channels.filter(channel => channel.totalSongs > 0);

		this.tags.forEach(tag => {
			// newCounts[tag] = filterableChannels.filter(channel =>
			//     channel.title.toUpperCase().includes(tag)
			// ).length;
			newCounts[tag] = tag.channels.length
		})
		console.log({ newCounts })
		this.tagCounts = newCounts
	}

	calculateAggregatedStats () {
		const finalAlbums = this.getFilteredChannels()

		const totals = finalAlbums.reduce((sum, album) => {
			sum.totalSongs += album.totalSongs
			sum.downloadedSongs += album.downloadedSongs
			sum.totalDuration += album.totalDuration
			sum.totalSizeMB += album.totalSizeMB
			sum.downloadedDuration += album.downloadedDuration
			sum.downloadedSizeMB += album.downloadedSizeMB
			return sum
		}, {
			totalSongs: 0,
			downloadedSongs: 0,
			totalDuration: 0,
			totalSizeMB: 0,
			downloadedDuration: 0,
			downloadedSizeMB: 0
		})

		this.aggregatedStats = totals
	}

	updated (changedProperties) {
		if (changedProperties.has('isOfflineMode') || changedProperties.has('channels') || changedProperties.has('activeTag')) {
			this.calculateTagCounts()
			this.calculateAggregatedStats()
		}

		if (changedProperties.has('activeIndex')) {
			this.resetConfirmation()
		}
	}

	// Hanterar byte av radionätverk
	handleNetworkChange (e) {
		this.loadStationData(e.detail.index)
	}

	// NYTT: Album/Kanal klick i rutnätet
	handleChannelClick (channel) {
		this.activeChannel = channel
		this.view = 'playlist'
		this.tracks = []

		qq(q().index('channelId').getAll(channel.id), tracks => {
			if (tracks.length) {
				this.tracks = tracks.map(t => new Track(t))
				globalThis.tracks = this.tracks
			} else {
				audioAddict.tuneIn(channel).then(result => {
					const network = config.networks.by({ id: config.channels[2].networkId })

					const liveTrack = Track.fromTrackAndChannel({
						content: {
							assets: [{
								content_format_id: 1,
								content_quality_id: 1,
								size: 0,
								ext: 'mp3',
								url: `http://prem1.di.fm/${channel.key}_hi?${config.listenerKey}`
							}]
						},
						artist: { name: channel.name },
						title: 'Live Stream',
						track: 'Live Stream',
						displayArtist: channel.name,
						displayTitle: 'Live Stream',
						mix: null,
						length: Infinity,
						images: channel.images,
						id: channel.key,
						version: 1,
						votes: { up: 0, down: 0, me: null },
						channelId: channel.id,
						isrc: null
					}, channel)

					const tracks = result.tracks.map(track => Track.fromTrackAndChannel(track, channel))
					tracks.unshift(liveTrack)
					tracks.forEach(track => track.save())
					this.tracks = tracks
					globalThis.tracks = this.tracks
				})
			}
		})
	}

	// Downloaded TimeStamp
	// LastPlayed TimeStamp
	// Modified TimeStamp
	// Skip Count
	// Skip TimeStamps
	// Last Skip TimeStamp
	// First Skip TimeStamp

	handleTagClick (tag) {
		this.activeTag = tag
	}

	toggleOfflineMode () {
		this.isOfflineMode = !this.isOfflineMode
	}

	renderStats (channel) {
		// TODO: Återaktivera när vi har denna info tillgänglig
		return null

		if (channel.totalSongs === 0) {
			return null
		}

		const downloadedSongs = channel.downloadedSongs || 0
		const totalSongs = channel.totalSongs || 0

		const downloadedSize = formatSize(channel.downloadedSizeMB || 0)
		const totalSize = formatSize(channel.totalSizeMB || 0)

		const downloadedDuration = formatDurationHours(channel.downloadedDuration || 0)
		const totalDuration = formatDurationHours(channel.totalDuration || 0)

		return html`
            <dl class="stats-compact-container">

                <!-- Låtar -->
                <dt>Låtar:</dt>
                <dd>
                    <span title="${downloadedSongs} låtar nedladdade">${downloadedSongs}</span>
                    /
                    <span title="Totalt ${totalSongs} låtar i kanalen">${totalSongs}</span>
                </dd>

                <!-- Storlek -->
                <dt>Storlek:</dt>
                <dd>
                    <span title="Nedladdad storlek: ${downloadedSize}">${downloadedSize}</span>
                    /
                    <span title="Total storlek: ${totalSize}">${totalSize}</span>
                </dd>

                <!-- Speltid -->
                <dt>Speltid:</dt>
                <dd>
                    <span title="Nedladdad speltid: ${downloadedDuration}">${downloadedDuration}</span>
                    /
                    <span title="Total speltid: ${totalDuration}">${totalDuration}</span>
                </dd>

            </dl>
        `
	}

	renderAggregatedFooter () {
		const stats = this.aggregatedStats

		const filteredChannels = this.getFilteredChannels()
		const channelCount = filteredChannels.length

		if (channelCount === 0) {
			return null
		}

		const titleText = `Sammanställning för "${this.activeTag.name}" (${this.activeTag.channels.length} kanaler) -  253 tracks (2d 05h 47m)`

		const downloadedSongs = stats.downloadedSongs
		const totalSongs = stats.totalSongs

		const downloadedSize = formatSize(stats.downloadedSizeMB)
		const totalSize = formatSize(stats.totalSizeMB)

		const downloadedDuration = formatDurationHours(stats.downloadedDuration)
		const totalDuration = formatDurationHours(stats.totalDuration)

		const isOfflineText = this.isOfflineMode ? ' (Offline: Endast nedladdat visas)' : ''

		const targetText = channelCount === 1 ? 'denna kanal' : `dessa ${channelCount} kanaler`

		const deleteMessage = this.includeMetadata
			? html`Detta tar bort ALLA låtar OCH metadata för ${targetText}.`
			: html`Detta rensar ALLT nedladdat innehåll från ${targetText}.`

		const confirmationModal = html`
            <div class="nuke-prompt confirmation-modal">
                <p>${deleteMessage} Är du säker?</p>
                <div class="confirm-buttons-container">
                    <button class="confirm-button" @click=${this.confirmDeletion}>Ja, Radera</button>
                    <button class="cancel-button" @click=${this.resetConfirmation}>Avbryt</button>
                </div>
            </div>
        `

		const metadataTooltip = html`
            <div class="metadata-tooltip-box">
                <p>Rensar även uppspelningshistorik (lyssnade låtar), gilla/ogilla-status och statistik (antal spelningar per låt).</p>
            </div>
        `

		return html`
      <footer class="aggregated-footer-container">
        <p class="footer-title">${titleText}${isOfflineText}</p>

        <div class="footer-stats-grid">

          <!-- LÅTAR -->
          <div>
            <span class="stat-value">${downloadedSongs} / ${totalSongs}</span>
            <span class="stat-label">Låtar (Nedladdade / Totalt)</span>
          </div>

          <!-- STORLEK -->
          <div>
            <span class="stat-value">${downloadedSize} / ${totalSize}</span>
            <span class="stat-label">Storlek (Nedladdat / Totalt)</span>
          </div>

          <!-- SPELTID -->
          <div>
            <span class="stat-value">${downloadedDuration} / ${totalDuration}</span>
            <span class="stat-label">Speltid (Nedladdat / Totalt)</span>
          </div>

        </div>

          <!-- Raderingskontroller -->
          <div class="delete-controls-section">
              <hr class="delete-separator neutral-separator">

              ${this.showConfirmDeletion
		? confirmationModal
		: html`
                            <div class="delete-control-row">
                                <!-- Checkbox Group -->
                                <div class="checkbox-group">
                                    <div class="checkbox-container">
                                        <input
                                            id="include-metadata-checkbox"
                                            type="checkbox"
                                            class="custom-checkbox"
                                            ?checked=${this.includeMetadata}
                                            @change=${(e) => { this.includeMetadata = e.target.checked }}
                                        >
                                        <label for="include-metadata-checkbox" class="checkbox-label">
                                            Inklusive metadata
                                        </label>

                                        <!-- Frågetecken ikon med tooltip (Visa/Dölj vid hover) -->
                                        <button
                                            class="info-toggle-button"
                                            @mouseenter=${() => this.showMetadataTooltip = true}
                                            @mouseleave=${() => this.showMetadataTooltip = false}
                                            aria-label="Vad innebär metadata?"
                                        >
                                            ${InfoIcon}
                                        </button>
                                    </div>

                                    <!-- Tooltipen renderas om state är satt till true -->
                                    ${this.showMetadataTooltip ? metadataTooltip : null}

                                </div>

                                <!-- Knapp: Radera alla låtar -->
                                <button
                                    class="delete-button"
                                    @click=${() => { this.showConfirmDeletion = true }}
                                >
                                    Radera alla låtar
                                    <span class="channel-count-display">(${channelCount} kanaler)</span>
                                </button>
                            </div>
                        `}
                </div>
            </footer>
        `
	}

	// Playlist View - now delegated to its own web component
	renderPlaylistView () {
		if (!this.activeChannel) {
			this.view = 'main'
			return
		}

		const stationTitle = this.networks[this.activeIndex].name || 'Station'

		return html`
            <playlist-view
                .channel=${this.activeChannel}
                .tracks=${this.tracks}
                .stationTitle=${stationTitle}
                .isOfflineMode=${this.isOfflineMode}
                @back=${this._handlePlaylistBack}
                @offline-toggle=${this._handleOfflineToggle}
                @track-click=${this._handlePlaylistTrackClick}
            ></playlist-view>
        `
	}

	_handlePlaylistBack () {
		this.view = 'main'
	}

	_handleOfflineToggle (e) {
		this.isOfflineMode = e.detail.isOfflineMode
	}

	_handlePlaylistTrackClick (e) {
		const track = e.detail.track
		this._playTrack(track)
		// No longer switch to player view - footer player is always visible
	}

	// Footer player (always visible)
	renderFooterPlayer () {
		return html`
			<player-ui
				.track=${this.currentTrack}
				.volume=${this.volume}
				@play-pause=${this._handlePlayPause}
				@prev=${this._handlePrev}
				@next=${this._handleNext}
				@volume-change=${this._handleVolumeChange}
				@mute-toggle=${this._handleMuteToggle}
			></player-ui>
		`
	}

	_handlePlayPause () {
		audioPlayer.togglePlayPause()
	}

	_handlePrev () {
		audioPlayer.prev()
	}

	_handleNext () {
		audioPlayer.next()
	}

	_handleSeek (e) {
		audioPlayer.seek(e.detail.time)
	}

	_handleVolumeChange (e) {
		audioPlayer.setVolume(e.detail.volume)
	}

	_handleMuteToggle () {
		audioPlayer.toggleMute()
	}

	_playTrack (track) {
		// Always update playlist in audioPlayer when playing a track
		// This ensures the playlist is in sync for next/prev navigation
		if (this.tracks) {
			audioPlayer.setPlaylist(this.tracks)
		}
		audioPlayer.playTrack(track)
	}

	_handleDownloadRequested (e) {
		// Handle download request from download-dialog
		const { metadataOnly, songs, minutes, megabytes } = e.detail
		console.log('Download requested:', { metadataOnly, songs, minutes, megabytes })
		// Download logic would be implemented here based on the active channel/playlist
		// For now, just log the request
	}

	// Huvudrender-metoden som hanterar vy-byte
	render () {
		let content
		if (this.view === 'playlist') {
			content = this.renderPlaylistView()
		} else {
			content = this.renderMainView()
		}

		return html`
			${content}
      <settings-dialog></settings-dialog>
			<download-dialog></download-dialog>
			${this.renderFooterPlayer()}
		`
	}

	renderMainView () {
		const displayAlbums = this.getFilteredChannels()

		const getTagCount = (tag) => {
			return tag.channels.length
		}

		return html`
            <div class="content-wrapper hide-scrollbar">

                <!-- HERO SECTION with Radio Network Selector inside -->
                <app-hero
                    .isOfflineMode=${this.isOfflineMode}
                    @offline-toggle=${(e) => { this.isOfflineMode = e.detail.isOfflineMode }}
                >
                    <radio-network-selector
                        .networks=${this.networks}
                        .activeIndex=${this.activeIndex}
                        @network-change=${this.handleNetworkChange}
                    ></radio-network-selector>
                </app-hero>

                <!-- NY SEKTION: 3.5. TAG FILTER -->
                <section class="tag-filter-container">
                    <div class="tag-carousel">
                        ${this.tags.map(tag => {
                          const count = getTagCount(tag)

                          if (count === 0 && tag !== this.activeTag) {
                              return null
                          }

                          return html`
                              <button
                                  class="tag-pill ${tag === this.activeTag ? 'active-tag' : ''}"
                                  @click=${() => this.handleTagClick(tag)}
                              >
                                  ${tag.name}
                                  <span class="tag-count">(${count})</span>
                              </button>
                          `
                        })}
                    </div>

                    <!-- Settings button -->
                    <button
                      class="settings-button"
                      title="Inställningar"
                      @click=${() => settingsDialog.showModal()}
                    >
                        ${SettingsIcon}
                    </button>
                </section>


                <!-- 4. KANAL RUTNÄT SECTION -->
                <section>
                    ${displayAlbums.length === 0 && this.networks.length === 0
                      ? html`<p style="text-align: center; color: #f5d020; padding: 2rem; font-weight: 600;">Alla stationer saknar nedladdat innehåll och har filtrerats bort.</p>`
                      : displayAlbums.length === 0 && this.activeTag !== 'ALL'
                        ? html`<p style="text-align: center; color: #f5d020; padding: 2rem;">Inga kanaler matchar filtret "${this.activeTag}".</p>`
                        : displayAlbums.length === 0 && this.isOfflineMode && this.activeTag === 'ALL'
                          ? html`<p style="text-align: center; color: #f5d020; padding: 2rem;">Denna station har inga kanaler med nedladdat innehåll.</p>`
                          : ''
}
                    <div class="channel-grid">

                        ${displayAlbums.map(channel => html`
                                <div
                                    class="album-card"
                                    @click=${() => this.handleChannelClick(channel)}
                                >
                                    <div class="card-glow cover">
																				<img
																					loading="lazy"
																					src="${channel.images.compact.url}.webp?width=150&quality=90"
																					alt="Omslag för ${channel.name}"
																				>
                                    </div>
                                    <p title="${channel.name}">${channel.name}</p>

                                    ${this.renderStats(channel)}
                                </div>
                        `)}

                    </div>
                </section>

                <!-- AGGREGERAD STATISTIK FOOTER OCH RENSNINGSKNAPPAR -->
                ${this.renderAggregatedFooter()}

            </div>
        `
	}

	// Ren CSS för komponenten
	static styles = [style]

	// Funktion för att generera Placeholdxr URL:er
	generatePlaceholderUrl (channel) {
		console.log(channel)
		const query = title.replace(/ /g, '+')
		return `https://placeholdxr.com/api/image/${query}?width=${size}&height=${size}&format=webp&color=${color}`
	}
}

customElements.define('music-player', MusicPlayer)
