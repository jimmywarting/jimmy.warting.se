registerPaint('buffered-bar', class {
	static get inputProperties () {
		return ['--buffered-ranges', '--buffered-color']
	}

	paint (ctx, size, props) {
		ctx.fillStyle = '#535557'
		ctx.fillRect(0, 0, size.width, size.height)
		const ranges = props.get('--buffered-ranges').toString().split(',').map(Number)

		ctx.fillStyle = props.get('--buffered-color')
		for (let i = 0; i < ranges.length; i += 2) {
			const startX = (ranges[i] / 100) * size.width
			const endX = (ranges[i + 1] / 100) * size.width
			ctx.fillRect(startX, 0, endX - startX, size.height)
		}
	}
})
