const playlist = document.getElementById('playlist')
const selectionBox = document.getElementById('selection-box')
let items = Array.from(playlist.querySelectorAll('track-item'))
let lastSelectedIndex = null // Används för Shift-klick intervallmarkering

// --- Hantering av enskilda klick på spår (Shift, Ctrl/Cmd) ---
playlist.addEventListener('click', (e) => {
	// Hitta det närmaste track-item-elementet om klicket var inuti ett sådant
	const item = e.target.closest('track-item')
	if (!item) return // Om klicket inte var på ett spår, gör inget

	const index = parseInt(item.dataset.index)
	const isShift = e.shiftKey
	const isCtrlOrCmd = e.ctrlKey || e.metaKey // Ctrl för Windows/Linux, Cmd för Mac

	if (isShift && lastSelectedIndex !== null) {
		// Om Shift är nedtryckt och ett tidigare objekt markerats, markera ett intervall
		const [start, end] = [lastSelectedIndex, index].sort((a, b) => a - b)
		for (let i = start; i <= end; i++) {
			items[i].classList.add('selected')
		}
	} else if (isCtrlOrCmd) {
		// Om Ctrl/Cmd är nedtryckt, växla markeringsstatusen för det klickade spåret
		item.classList.toggle('selected')
	} else {
		// Annars (standardklick), avmarkera alla spår och markera endast det klickade spåret
		items.forEach(el => el.classList.remove('selected'))
		item.classList.add('selected')
	}

	lastSelectedIndex = index // Uppdatera senast markerade index
})

// --- Variabler och tillstånd för drag-to-select ---
let isDragging = false
let startPageX = 0
let startPageY = 0 // Startkoordinater för dragningen (i dokumentet)
let currentClientX = 0
let currentClientY = 0 // Nuvarande muskoordinater (i viewport)
let currentPageX = 0
let currentPageY = 0 // Nuvarande muskoordinater (i dokumentet)
let initialCtrlKey = false // Sparar tillståndet för Ctrl/Cmd vid mousedown
const initialSelections = new Set() // Lagrar ID:n för initialt markerade objekt för Ctrl-drag
let scrollIntervalId = null // För setInterval för autoscroll
let startClientX = 0
let startClientY = 0 // Startkoordinater för musen (i viewport)

// --- Funktion för att uppdatera markeringsrutan och markera/avmarkera objekt ---
const updateSelectionState = () => {
	if (!isDragging) return // Uppdatera endast om dragning pågår

	// Beräkna urvalsrutans position och storlek baserat på dokumentkoordinater (pageX/pageY)
	// Detta är avgörande för att boxen ska växa och scrolla med sidan
	const left = Math.min(startPageX, currentPageX)
	const top = Math.min(startPageY, currentPageY)
	const width = Math.abs(startPageX - currentPageX)
	const height = Math.abs(startPageY - currentPageY)

	// Uppdatera selectionBoxens CSS-stil (position: absolute)
	Object.assign(selectionBox.style, {
		left: `${left}px`,
		top: `${top}px`,
		width: `${width}px`,
		height: `${height}px`
	})

	// selRectDocument är markeringsrutans gränser i dokumentkoordinater.
	// Denna används för att jämföra med itemRectDocument som också är i dokumentkoordinater.
	const selRectDocument = {
		left,
		right: left + width,
		top,
		bottom: top + height
	}

	// Loopa igenom alla spår för att kontrollera överlappning
	items.forEach(item => {
		const itemRect = item.getBoundingClientRect() // Spårets position och dimensioner i viewport

		// Konvertera spårets position till dokumentkoordinater
		const itemRectDocument = {
			left: itemRect.left + window.scrollX,
			right: itemRect.right + window.scrollX,
			top: itemRect.top + window.scrollY,
			bottom: itemRect.bottom + window.scrollY
		}

		// Kontrollera om spåret överlappar med markeringsrutan i dokumentkoordinater
		const overlaps =
      selRectDocument.left < itemRectDocument.right &&
      selRectDocument.right > itemRectDocument.left &&
      selRectDocument.top < itemRectDocument.bottom &&
      selRectDocument.bottom > itemRectDocument.top

		// Bestäm om objektet ska vara markerat baserat på överlappning och modifieringstangenter
		let shouldBeSelected

		if (initialCtrlKey) {
			// Om Ctrl/Cmd var nedtryckt vid start av dragningen (toggle-läge)
			const wasInitiallySelected = initialSelections.has(item.dataset.index)
			shouldBeSelected = overlaps ? !wasInitiallySelected : wasInitiallySelected
		} else {
			// Standard drag (ingen Ctrl/Cmd eller bara Shift), markera om det överlappar
			shouldBeSelected = overlaps
		}

		// Uppdatera klasslistan baserat på den beräknade statusen
		if (shouldBeSelected) {
			item.classList.add('selected')
		} else {
			item.classList.remove('selected')
		}
	})
}

// --- Funktion för automatisk scrollning under dragning ---
const autoScroll = () => {
	if (!isDragging) {
		clearInterval(scrollIntervalId) // Stoppa intervallet om dragningen avslutats
		scrollIntervalId = null
		return
	}

	const scrollThreshold = 50 // Avstånd från viewportens kanter för att trigga scroll
	const scrollSpeed = 30 // **Ökad scrollhastighet i pixlar per intervall**

	let scrolled = false

	// Scrolla uppåt
	if (currentClientY < scrollThreshold && window.scrollY > 0) {
		window.scrollBy(0, -scrollSpeed)
		scrolled = true
	} else if (currentClientY > window.innerHeight - scrollThreshold && window.scrollY + window.innerHeight < document.body.scrollHeight) {
		// Scrolla nedåt
		window.scrollBy(0, scrollSpeed)
		scrolled = true
	}

	// Om sidan scrollade, måste vi uppdatera markeringen eftersom itemRects har ändrats
	// och selectionBoxens visuella position måste justeras.
	if (scrolled) {
		// Uppdatera currentPageX/Y baserat på den nya scrollpositionen (mouse position + scroll)
		currentPageX = currentClientX + window.scrollX
		currentPageY = currentClientY + window.scrollY
		updateSelectionState() // Uppdatera urvalet efter scrollning
	}
}

// --- Hantering av musknappen nedtryckt (startar dragning) ---
document.addEventListener('mousedown', (e) => {
	// Vi lyssnar på hela dokumentet men begränsar dragstarten till endast spellistan
	const inPlaylist = playlist.contains(e.target)
	// Starta dragning endast om klicket var inuti spellistan OCH INTE direkt på ett track-item
	if (!inPlaylist || e.target.closest('track-item')) {
		return
	}

	items = Array.from(playlist.querySelectorAll('track-item'))

	// Förhindra standardbeteende (t.ex. textmarkering)
	e.preventDefault()

	isDragging = true

	// Spara initiala muskoordinater direkt från händelsen
	startClientX = e.clientX
	startClientY = e.clientY
	startPageX = e.pageX
	startPageY = e.pageY

	// Sätt initial currentX/Y/pageX/pageY
	currentClientX = e.clientX
	currentClientY = e.clientY
	currentPageX = e.pageX
	currentPageY = e.pageY

	// Spara tillståndet för Ctrl/Cmd-tangenten vid start av dragningen
	initialCtrlKey = e.ctrlKey || e.metaKey

	// Lagra initiala markeringar för att hantera toggle-beteendet med Ctrl-drag
	initialSelections.clear()
	items.forEach(item => {
		if (item.classList.contains('selected')) {
			initialSelections.add(item.dataset.index)
		}
	})

	// Om ingen modifieringstangent (Ctrl/Cmd) hölls nere, rensa alla befintliga markeringar
	if (!initialCtrlKey) {
		items.forEach(el => el.classList.remove('selected'))
	}

	// Initiala inställningar för selectionBox: visa den och sätt startpositionen med noll dimensioner
	selectionBox.hidden = false // Visa markeringsrutan
	Object.assign(selectionBox.style, {
		left: `${startPageX}px`, // Använd pageX för absolut position
		top: `${startPageY}px`, // Använd pageY för absolut position
		width: '0px',
		height: '0px'
	})

	// Starta auto-scroll intervallet
	if (scrollIntervalId) {
		clearInterval(scrollIntervalId)
	}
	scrollIntervalId = setInterval(autoScroll, 30) // Kör var 30:e ms

	// --- Hantering av musrörelse under dragning ---
	const onMouseMove = (moveEvent) => {
		if (!isDragging) return // Se till att dragning pågår

		// Uppdatera nuvarande muskoordinater
		currentClientX = moveEvent.clientX
		currentClientY = moveEvent.clientY
		currentPageX = moveEvent.pageX
		currentPageY = moveEvent.pageY

		// Uppdatera markeringsrutan och objektmarkeringar
		updateSelectionState()
	}

	// --- Hantering av musknappen släppt (avslutar dragning) ---
	const onMouseUp = () => {
		isDragging = false
		selectionBox.hidden = true // Dölj markeringsrutan

		// Ta bort eventlyssnare som lagts till på dokumentet för att förhindra minnesläckor
		document.removeEventListener('mousemove', onMouseMove)
		document.removeEventListener('mouseup', onMouseUp)

		// Stoppa auto-scroll intervallet
		if (scrollIntervalId) {
			clearInterval(scrollIntervalId)
			scrollIntervalId = null
		}
	}

	// Lägg till eventlyssnare för musrörelse och musknapp släppt på HELA dokumentet.
	// Detta är viktigt för att dragningen ska fungera även om musen rör sig utanför spellistan under draget.
	document.addEventListener('mousemove', onMouseMove)
	document.addEventListener('mouseup', onMouseUp)
})
