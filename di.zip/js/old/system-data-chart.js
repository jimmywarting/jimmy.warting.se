// Filnamn: system-data-chart.js
import { Chart, registerables } from 'https://cdn.jsdelivr.net/npm/chart.js@4.4.9/+esm'
import zoomPlugin from 'https://cdn.jsdelivr.net/npm/chartjs-plugin-zoom@2.2.0/+esm'

Chart.register(zoomPlugin, ...registerables)

class SystemDataChart extends HTMLElement {
	constructor () {
		super()
		this.attachShadow({ mode: 'open' })

		this.dataPoints = []
		this.totalDownloaded = 0
		this.totalOnDisk = 0
		this.cacheUsage = 0
		this.isDownloading = true
		this.stateChangeTime = performance.now()
		this.stateDuration = this.getRandomInt(3000, 7000)
		this.startTime = performance.now()

		this.shadowRoot.innerHTML = `
      <style>
        :host {
          display: block;
          max-width: 1000px;
          margin: 30px auto;
          font-family: Arial, sans-serif;
          color: #eee;
          background-color: #121212;
          border-radius: 8px;
          box-shadow: 0 0 15px rgba(255 255 255 / 0.1);
        }
        canvas {
          background-color: #222;
          width: 100%;
          height: 600px;
          border-radius: 8px;
          display: block;
        }
      </style>
      <canvas></canvas>
    `

		this.ctx = this.shadowRoot.querySelector('canvas').getContext('2d')
	}

	connectedCallback () {
		this.initChart()
		this.intervalId = setInterval(() => this.simulateDownload(), 1000)
	}

	disconnectedCallback () {
		if (this.chart) this.chart.destroy()
		// clearInterval(this.intervalId);
	}

	getRandomInt (min, max) {
		return Math.floor(Math.random() * (max - min + 1)) + min
	}

	formatBytes (bytes) {
		const units = ['bytes', 'KiB', 'MiB', 'GiB']
		let i = 0
		while (bytes >= 1024 && i < units.length - 1) {
			bytes /= 1024
			i++
		}
		return `${bytes.toFixed(2)} ${units[i]}`
	}

	formatDuration (seconds) {
		if (seconds < 60) return `${seconds.toFixed(1)} s`
		if (seconds < 3600) return `${(seconds / 60).toFixed(1)} min`
		return `${(seconds / 3600).toFixed(1)} h`
	}

	async getCacheUsage () {
		if (navigator.storage && navigator.storage.estimate) {
			try {
				const est = await navigator.storage.estimate()
				return est.usageDetails?.caches || 0
			} catch {
				return 0
			}
		}
		return 0
	}

	initChart () {
		this.chart = new Chart(this.ctx, {
			type: 'line',
			data: {
				labels: [],
				datasets: [
					{
						label: 'Nedladdat',
						data: [],
						fill: false,
						borderColor: 'dodgerblue',
						tension: 0.1,
						pointRadius: 0
					},
					{
						label: 'RAM',
						data: [],
						fill: false,
						borderColor: 'limegreen',
						tension: 0.1,
						pointRadius: 0
					},
					{
						label: 'Hårddisk',
						data: [],
						fill: false,
						borderColor: 'mediumpurple',
						tension: 0.1,
						pointRadius: 0
					},
					{
						label: 'Cache',
						data: [],
						fill: false,
						borderColor: 'orange',
						tension: 0.1,
						pointRadius: 0
					}
				]
			},
			options: {
				responsive: true,
				animation: true,
				plugins: {
					legend: {
						labels: { color: '#ddd' }
					},
					tooltip: {
						backgroundColor: '#333',
						titleColor: '#eee',
						bodyColor: '#ccc',
						callbacks: {
							title: context => this.formatDuration(+context[0].label),
							label: context => `${context.dataset.label}: ${this.formatBytes(context.raw)}`
						}
					},
					zoom: {
						pan: {
							enabled: true,
							mode: 'x',
							modifierKey: 'ctrl'
						},
						zoom: {
							wheel: {
								enabled: true
							},
							pinch: {
								enabled: true
							},
							mode: 'x'
						}
					}
				},
				scales: {
					x: {
						title: {
							display: true,
							text: 'Tid',
							color: '#ddd'
						},
						ticks: {
							color: '#ddd',
							callback: value => {
								const seconds = this.chart.data.labels[value]
								return this.formatDuration(seconds)
							}
						},
						grid: {
							color: '#444'
						}
					},
					y: {
						type: 'linear',
						display: true,
						position: 'left',
						title: {
							display: true,
							text: 'Data',
							color: '#ddd'
						},
						ticks: {
							color: '#ddd',
							callback: value => this.formatBytes(value)
						},
						grid: {
							color: '#444'
						}
					}
				}
			}
		})
	}

	async simulateDownload () {
		const now = performance.now()

		const timeInSeconds = (now - this.startTime) / 1000

		const memoryUsed = performance.memory ? performance.memory.usedJSHeapSize : 0
		this.cacheUsage = await this.getCacheUsage()

		this.dataPoints.push({
			time: timeInSeconds,
			downloaded: this.totalDownloaded,
			ram: memoryUsed,
			disk: this.totalOnDisk,
			cache: this.cacheUsage
		})

		this.chart.data.labels.push(timeInSeconds)
		this.chart.data.datasets[0].data.push(this.totalDownloaded)
		this.chart.data.datasets[1].data.push(memoryUsed)
		this.chart.data.datasets[2].data.push(this.totalOnDisk)
		this.chart.data.datasets[3].data.push(this.cacheUsage)

		if (this.dataPoints.length > 300) {
			this.dataPoints.shift()
			this.chart.data.labels.shift()
			this.chart.data.datasets.forEach(ds => ds.data.shift())
		}

		this.chart.update('none')
	}
}

customElements.define('system-data-chart', SystemDataChart)
