const iframe = document.createElement('iframe')
iframe.hidden = true
iframe.sandbox = 'allow-scripts'

const iframeScript = `
  <script>
    window.addEventListener('message', async (event) => {
      const port = event.ports[0]
      try {
        const response = await fetch(...event.data)
        port.postMessage({
          status: response.status,
          statusText: response.statusText,
          headers: [...response.headers],
          body: response.body,
          url: response.url
        }, [response.body])
      } catch (err) {
        port.postMessage({ error: err.message })
      }
    })
  <\/script>
`

iframe.srcdoc = iframeScript
document.body.appendChild(iframe)

await new Promise(rs => iframe.onload = rs)
const win = iframe.contentWindow

/**
 * An anonymous fetch function that uses an hidden iframe
 * to hide referrer and sets the origin to 'null'.
 *
 * @param { string | URL } url
 * @param { RequestInit } options
 * @returns { Promise<Response> }
 */
async function xFetch (url, options = {}) {
	const mc = new MessageChannel()

	win.postMessage([url, options], '*', [mc.port2])

	const evt = await new Promise(rs => mc.port1.onmessage = rs)

	const { error, body, status, statusText, headers } = evt.data

	if (error) throw new Error(error)

	const res = new Response(body, {
		status,
		statusText,
		headers
	})

	Object.defineProperty(res, 'url', {
		value: evt.data.url,
		writable: false,
		enumerable: true,
		configurable: false
	})

	return res
}

globalThis.fetch = xFetch
