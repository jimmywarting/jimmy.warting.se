import _butterchurn from 'https://cdn.jsdelivr.net/npm/butterchurn@2.6.7/+esm';
import butterchurnPresets from 'https://cdn.jsdelivr.net/npm/butterchurn-presets@2.4.7/+esm'

const pip = async () => {
  const butterchurn = _butterchurn.default
  const audio = globalThis.player
  const video = document.createElement('video')
  const canvas = document.createElement('canvas');

  video.srcObject = canvas.captureStream()
  video.muted = true
  video.play()
  canvas.width = screen.width
  canvas.height = screen.height

  const presetList = Object.values(butterchurnPresets.getPresets());
  let presetIndex = 0

  const audioContext = new AudioContext()
  const sourceNode = audioContext.createMediaElementSource(audio);

  const analyserNode = audioContext.createAnalyser()

  sourceNode.connect(analyserNode);
  analyserNode.connect(audioContext.destination);

  const visualizer = butterchurn.createVisualizer(audioContext, canvas, {
    width: canvas.width,
    height: canvas.height
  })

  visualizer.loadPreset(presetList[presetIndex], 0);
  visualizer.connectAudio(analyserNode);

  animate();

  // Cycle presets every 20 seconds
  setInterval(() => {
    presetIndex = (presetIndex + 1) % presetList.length;
    visualizer.loadPreset(presetList[presetIndex], 2.0);
  }, 20000);

  if (video.readyState === 0) {
    await new Promise(rs => video.onloadedmetadata = rs)
  }

  video.requestPictureInPicture()
  document.body.appendChild(video)
  // video.requestFullscreen()

  function animate() {
    requestAnimationFrame(animate);
    visualizer?.render();
  }

  globalThis.video = video
}

globalThis.pip = pip

export {
  pip
}