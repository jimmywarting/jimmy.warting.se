Blob.prototype.bytes ??= function bytes() {
  return this.arrayBuffer().then(ab => new Uint8Array(ab))
}

Blob.prototype.to ??= function to(Klass) {
  return this.arrayBuffer().then(ab => new Klass(ab))
}

Response.prototype.file = async function file({ type, name, lastModified } = {}) {
  // Step 1: Read the response content as a Blob
  const blob = await this.blob();

  // Step 2: Get the Content-Disposition header
  const contentDisposition = this.headers.get('Content-Disposition');

  // Step 3: Try to extract filename from Content-Disposition
  let inferredName = 'download';
  if (contentDisposition?.includes('filename=')) {
    const match = contentDisposition.match(/filename\*?=(?:UTF-8'')?["']?([^"';\n]+)["']?/i);
    if (match?.[1]) {
      inferredName = decodeURIComponent(match[1]);
    }
  } else {
    // Step 4: If no Content-Disposition, try to extract filename from URL pathname
    try {
      const url = new URL(this.url);
      const lastSegment = url.pathname.split('/').filter(Boolean).pop();
      if (lastSegment) inferredName = lastSegment;
    } catch {
      // URL might be empty or invalid, fallback to default
    }
  }

  // Step 5: Determine the MIME type
  const inferredType = type ?? (blob.type || this.headers.get('Content-Type') || '');

  // Step 6: Determine lastModified time
  let inferredLastModified = Date.now();
  if (typeof lastModified === 'number') {
    inferredLastModified = lastModified;
  } else if (this.headers.has('Last-Modified')) {
    const parsed = Date.parse(this.headers.get('Last-Modified'));
    if (!isNaN(parsed)) inferredLastModified = parsed;
  }

  // Step 7: Create and return the File object
  return new File([blob], name ?? inferredName, {
    type: inferredType,
    lastModified: inferredLastModified
  });
};

Object.defineProperty(Blob.prototype, 'url', {
  get () {
    return URL.createObjectURL(this)
  }
})

Object.defineProperty(Blob.prototype, 'img', {
  get () {
    const img = new Image()
    img.src = this.url
    img.alt = this.name || ''
    img.addEventListener('load', () => {
      URL.revokeObjectURL(img.src)
    }, { once: true })
    return img
  }
})

Blob.prototype.convertToImage = async function  (type, quality = 1) {
  console.log(this)
  const bitmap = await createImageBitmap(this)
  const { width, height } = bitmap

  const canvas = new OffscreenCanvas(width, height)
  const ctx = canvas.getContext('2d')
  ctx.drawImage(bitmap, 0, 0, width, height)

  const targetMime = 'image/' + type
  const convertedBlob = await canvas.convertToBlob({ type: targetMime, quality })

  const originalSize = this.size
  const convertedSize = convertedBlob.size
  const sizeDiff = originalSize - convertedSize
  const percentDiff = ((sizeDiff / originalSize) * 100).toFixed(1)

  const originalName = this instanceof File ? this.name : 'image.unknown'
  const filename = originalName.replace(/\.[^./\\]+$/, '.' + type)

  console.groupCollapsed(`[convertToImage] ${this.type} → ${targetMime}`)
  console.log('Filename:', originalName, '→', filename)
  console.log('Resolution:', width + 'x' + height)
  console.log('Quality:', quality)
  console.log('Original MIME type:', this.type)
  console.log('Converted MIME type:', convertedBlob.type)
  console.log('Original size:', originalSize, 'bytes')
  console.log('Converted size:', convertedSize, 'bytes')

  if (convertedSize < originalSize) {
    console.log('Saved:', sizeDiff, 'bytes')
    console.log('Reduction:', percentDiff + '%')
  } else {
    console.warn('No savings. Converted image is larger or equal in size.')
    console.log('Overhead:', Math.abs(sizeDiff), 'bytes')
    console.log('Increase:', Math.abs(percentDiff) + '%')
  }

  console.groupEnd()

  if (convertedSize >= originalSize) {
    return this instanceof File
      ? this
      : new File([this], originalName, { type: this.type })
  }

  return new File([convertedBlob], filename, { type: convertedBlob.type })
}

Array.prototype.by ??= function (query) {
  const [key, value] = Object.entries(query)[0]

  if (!this._byKeyMap) {
    Object.defineProperty(this, '_byKeyMap', {
      value: new Map(),
      enumerable: false,
      writable: true
    })
  }

  if (!this._byKeyMap.has(key)) {
    const map = new Map()
    for (const item of this) {
      if (item && typeof item === 'object' && key in item) {
        map.set(item[key], item)
      }
    }
    this._byKeyMap.set(key, map)
  }

  return this._byKeyMap.get(key).get(value)
}
