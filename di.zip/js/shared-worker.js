// sharedworker.js
import './polyfills.js'
import { audioAddict } from './audioaddict.js'
import { state } from './global-store.js'

globalThis.onconnect = async (event) => {
  const port = event.ports[0]
  port.postMessage('Hello from SharedWorker!')

  port.onmessage = (e) => {
    const writable = e.data.config.getWriter()
    writable.write({
        ...globalThis.config,
        state: Object.entries(state).map(([k,v]) => [k,v.v])
    })
  }
}