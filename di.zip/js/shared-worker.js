globalThis.onconnect = async (event) => {
  const source = event.source
  function log(err) {
    source.postMessage(err)
    return {}
  }
  await import('./polyfills.js').catch(log)
  await import('./audioaddict.js').catch(log)
  await import('./missing.js').catch(log)
  const { state } = await import('./global-store.js').catch(log)

  const port = event.ports[0]

  port.onmessage = (e) => {
    const writable = e.data.config.getWriter()
    console.log('initial state sent to SharedWorker')
    writable.write({
        ...globalThis.config,
        state: Object.entries(state).map(([k,v]) => [k,v.v])
    })
  }
}