// sortModule.js

const defaultSortOptions = [
  { id: 'size', label: 'Storlek', checked: false, order: 'Stigande' },
  { id: 'displayTitle', label: 'Namn', checked: true, order: 'Stigande' },
  { id: 'displayArtist', label: 'Artist', checked: false, order: 'Stigande' },
  { id: 'album', label: 'Album', checked: false, order: 'Stigande' },
  { id: 'duration', label: 'Längd', checked: false, order: 'Stigande' },
  { id: 'rating', label: 'Betyg', checked: false, order: 'Stigande' },
  { id: 'lastplayed', label: 'Senast spelad', checked: false, order: 'Stigande' },
  { id: 'reaction', label: 'Reaktion', checked: false, order: 'Stigande' },
  { id: 'PCNT', label: 'Antal spelningar', checked: false, order: 'Stigande' },
  { id: 'fileHandle', label: 'Nedladdad', checked: false, order: 'Stigande' },
  { id: 'cached', label: 'temporärt cachad', checked: false, order: 'Stigande' },
  { id: 'randomness', label: 'Slumpa', checked: false, order: 'Lägg till ny' }
]

const stored = localStorage.getItem('sortOptions');
const sortOptions = stored ? JSON.parse(stored) : defaultSortOptions

let draggedItem;

function saveToLocalStorage(data) {
  localStorage.setItem('sortOptions', JSON.stringify(data));
}

function renderList() {
  const list = document.getElementById('sort-list');
  list.innerHTML = '';
  sortOptions.forEach(option => {
    const li = document.createElement('li');
    li.setAttribute('draggable', 'true');
    li.dataset.id = option.id;

    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.id = option.id;
    checkbox.checked = option.checked;
    checkbox.addEventListener('change', () => {
      option.checked = checkbox.checked;
      saveToLocalStorage(sortOptions);
    });

    const label = document.createElement('label');
    label.htmlFor = option.id;
    label.textContent = option.label;

    const button = document.createElement('button');
    button.className = 'order-toggle';
    button.textContent = option.order;
    button.addEventListener('click', () => {
      option.order = option.order === 'Stigande' ? 'Fallande' : 'Stigande';
      button.textContent = option.order;
      saveToLocalStorage(sortOptions);
    })

    const dragIcon = document.createElement('span');
    dragIcon.className = 'drag-indicator';
    dragIcon.textContent = '≡';

    li.append(checkbox, label, button, dragIcon);
    list.appendChild(li);

    li.addEventListener('dragstart', () => {
      draggedItem = li;
      li.classList.add('dragging');
    });

    li.addEventListener('dragend', () => {
      draggedItem = null;
      li.classList.remove('dragging');
    });

    li.addEventListener('dragover', e => {
      e.preventDefault();
    });

    li.addEventListener('drop', () => {
      if (draggedItem !== li) {
        const items = Array.from(list.children);
        const draggedIndex = items.indexOf(draggedItem);
        const droppedIndex = items.indexOf(li);

        sortOptions.splice(droppedIndex, 0, sortOptions.splice(draggedIndex, 1)[0]);
        saveToLocalStorage(sortOptions);
        renderList();
      }
    });
  });
}


renderList()

function sortTracks(tracks) {
  return tracks.sort((a, b) => {
    for (const option of sortOptions) {
      if (!option.checked) continue;

      // special case for size & fileHandle that lives in metadata
      if (option.id === 'size') {
        a = a.metadata;
        b = b.metadata;
      }


      let aValue = a[option.id];
      let bValue = b[option.id];

      if (option.id === 'fileHandle') {
        aValue = !a.metadata.fileHandle;
        bValue = !b.metadata.fileHandle
      }

      if (typeof aValue === 'string') aValue = aValue.toLowerCase();
      if (typeof bValue === 'string') bValue = bValue.toLowerCase();

      // use localeCompare for string comparison
      if (typeof aValue === 'string' && typeof bValue === 'string') {
        const comparison = aValue.localeCompare(bValue);
        if (comparison !== 0) return option.order === 'Stigande' ? comparison : -comparison;
      }

      if (aValue < bValue) return option.order === 'Stigande' ? -1 : 1;
      if (aValue > bValue) return option.order === 'Stigande' ? 1 : -1;
    }

    return 0; // If all options are equal
  });
}

// Exportera det som behövs
export {
  sortOptions,
  sortTracks
}