import body from './track.html'
import css from './track.css'

let downloadIntervals = {};

const canvas = new OffscreenCanvas(45, 45)
const ctx = canvas.getContext('2d')
const placeholder = await fetch('/img/placeholder.png').then(res => res.blob())
// const bitmap = await createImageBitmap(placeholder, {
//   resizeWidth: 45,
//   resizeHeight: 45,
//   resizeQuality: 'high'
// })
// // convert bitmap to blob
// ctx.drawImage(bitmap, 0, 0, 45, 45)
// const fallbackImage = await canvas.convertToBlob({ type: 'image/webp' })
const fallbackURL = placeholder.url


function downloadBtnClick(evt, track, progress) {
  evt.stopPropagation();
  const state = track.dataset.state;
  const id = track.dataset.id;

  switch (state) {
    case "idle": {
      console.log("Startar nedladdning:", id);
      track.dataset.state = "loading";
      let value = 0;
      downloadIntervals[id] = setInterval(() => {
        value += 5;
        progress.value = value;
        if (value >= 100) {
          clearInterval(downloadIntervals[id]);
          delete downloadIntervals[id];
          track.dataset.state = "done";
        }
      }, 100);
      break;
    }
    case "loading": {
      console.log("Avbryter nedladdning:", id);
      clearInterval(downloadIntervals[id]);
      delete downloadIntervals[id];
      progress.value = 0;
      track.dataset.state = "idle";
      break;
    }
    case "done": {
      console.log("Tömmer cache:", id);
      track.dataset.state = "idle";
      progress.value = ""
      break;
    }
  }
}

const unit = 'B0KB0MB0GB0TB0PB0EB0ZB0YB'.split('0')
/** @param {number} size */
const bytes = (size, i = 0) => {
  for (;1000<=size;i++)size/=1000;
  return `${Math.round(size)} ${unit[i]}`
}

function formatTimeAndSize(seconds, size) {
  // Tid
  const hrs = Math.floor(seconds / 3600);
  const mins = Math.floor((seconds % 3600) / 60);
  const secs = Math.floor(seconds % 60);

  const timeStr = hrs > 0
    ? `${('0' + hrs).slice(-2)}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`
    : `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;

  // Kombinera
  return `${timeStr} 📦 ${bytes(size)}`;
}

const objectObserver = new IntersectionObserver((entries) => {
  entries.forEach(async entry => {
    const elm = entry.target
    const img = elm.wrapper.querySelector('img')
    const track = elm.track

    if (entry.isIntersecting) {
      elm.cover ??= track.getImage().then(async file => {
        const bitmap = await createImageBitmap(file, {
          resizeWidth: 45,
          resizeHeight: 45,
          resizeQuality: 'high'
        })
        // convert bitmap to blob
        ctx.drawImage(bitmap, 0, 0, 45, 45)
        const blob = await canvas.convertToBlob({ type: 'image/webp' })
        elm.cover = blob
        return blob
      })
      const cover = await elm.cover
      img.src = cover.url
      await img.decode()
      URL.revokeObjectURL(img.src)
    } else {
      entry.target.wrapper.querySelector('img').src = fallbackURL
    }
  })
})

const rtf = new Intl.RelativeTimeFormat('sv', { numeric: 'auto', style: 'short' })


function getRelativeLastPlayed(date) {
  const now = new Date()
  const diffMs = now - date
  const seconds = Math.round(diffMs / 1000)

  if (seconds < 60) return rtf.format(-seconds, 'second')
  const minutes = Math.round(seconds / 60)
  if (minutes < 60) return rtf.format(-minutes, 'minute')
  const hours = Math.round(minutes / 60)
  if (hours < 24) return rtf.format(-hours, 'hour')
  const days = Math.round(hours / 24)
  if (days < 30) return rtf.format(-days, 'day')
  const months = Math.round(days / 30)
  if (months < 12) return rtf.format(-months, 'month')
  const years = Math.round(months / 12)
  return rtf.format(-years, 'year')
}

customElements.define('track-item', class extends HTMLElement {
  #track
  get track () {
    return this.#track
  }
  set track (track) {
    if (!track.track) return // just a placeholder for now.

    this.#track = track

    const [
      wrapper,
      img,,
      title,
      meta,,,
      downloadBtn,
      progress
    ] = this.root.querySelectorAll('*')
    this.wrapper = wrapper
    this.progress = progress
    title.innerText = track.track
    meta.innerText = formatTimeAndSize(track.duration, track.metadata.size) +
    ` • Spelningar ${track.PCNT
    } • Skippat ${track.timesSkipped
    } • Senast spelad ${track.lastPlayedDate ? track.lastPlayedDate.toLocaleString() : 'Aldrig'}`

    meta.innerText = '⏰︎ ' + formatTimeAndSize(track.duration, track.metadata.size) +
    ` • ⏵︎ ${track.PCNT
    } • ⏭︎ ${track.timesSkipped
    } • ⏰︎ ${track.lastPlayedDate ? track.lastPlayedDate.toLocaleString() : 'Aldrig'}`

    meta.innerText = '⌛ ' + formatTimeAndSize(track.duration, track.metadata.size) +
    ` ▶️ ${track.PCNT
    } ⏭️ ${track.timesSkipped
    } 📅 ${track.lastPlayedDate ? getRelativeLastPlayed(track.lastPlayedDate) : 'Aldrig'}`

    downloadBtn.disabled = false

    if (track.metadata.fileHandle) {
      progress.value = progress.max
      wrapper.dataset.state = 'done'
    } else {
      wrapper.dataset.state = 'idle'
    }

    objectObserver.observe(this)

    wrapper.onclick = evt => track.play()
  }

  constructor() {
    super()
    const shadowRoot = this.root = this.attachShadow({ mode: 'open' })
    shadowRoot.append(body.cloneNode(true))
    shadowRoot.adoptedStyleSheets.push(css)
  }
})

/*
setTimeout(() => {
  track.querySelector("strong").innerText = "En Vacker Låt";
  track.querySelector(".track-meta").innerText = "03:58 • 5.1 MB";
  track.dataset.state = "idle";
  track.dataset.id = "sk1";

  const downloadBtn = track.querySelector("button");
  const progress = track.querySelector("progress");
  downloadBtn.disabled = false;

  track.addEventListener("click", (e) => {
    e.stopPropagation();
    playTrack(track);
  });
})
*/

// globalThis.extractImagesFromMP3Stream = extractImagesFromMP3Stream;

// const mp3 = 'https://content.audioaddict.com/prd/4/6/e/8/f/3161bb47c0dfb8a5c050983bfccf1f5da18.mp3?purpose=playback&audio_token=3118dc1b990755c7d8ee8e0d531ac6e3&network=di&device=chrome_137_mac_os_x_10_15_7&exp=2025-06-06T15:11:36Z&auth=9479905d28e62e46df32c92fb4d9c176875300c7'
// const ctrl = new AbortController()
// const res = await fetch(mp3, { signal: ctrl.signal })
// const [img] = await extractImagesFromMP3Stream(res.body)
// ctrl.abort()
// const blob = await fetch(mp3, {
//   headers: {
//     Range: `bytes=2-`
//   }
// })

/*
async function extractImagesFromMP3Stream(stream) {
  const reader = stream.getReader();
  const decoder = new TextDecoder();
  const images = [];
  let offset = 0;
  let buffer = new Uint8Array();
  let done = false;

  const concat = (a, b) => {
    const tmp = new Uint8Array(a.length + b.length);
    tmp.set(a, 0);
    tmp.set(b, a.length);
    return tmp;
  };

  const syncsafeToInt = (bytes) => {
    return (
      (bytes[0] & 0x7f) << 21 |
      (bytes[1] & 0x7f) << 14 |
      (bytes[2] & 0x7f) << 7 |
      (bytes[3] & 0x7f)
    );
  };

  while (!done) {
    const { value, done: isDone } = await reader.read();
    if (value) buffer = concat(buffer, value);
    done = isDone;

    if (buffer.length < 10) continue;
    if (decoder.decode(buffer.slice(0, 3)) !== "ID3") return [];

    const tagSize = syncsafeToInt(buffer.slice(6, 10)) + 10;
    if (buffer.length < tagSize && !done) continue;

    let pos = 10;
    while (pos + 10 < tagSize) {
      const frameId = decoder.decode(buffer.slice(pos, pos + 4));
      const size = buffer[pos + 4] << 24 | buffer[pos + 5] << 16 | buffer[pos + 6] << 8 | buffer[pos + 7];
      if (size === 0 || pos + 10 + size > buffer.length) break;

      if (frameId === 'APIC') {
        const encoding = buffer[pos + 10];
        const mimeStart = pos + 11;
        const mimeEnd = buffer.indexOf(0, mimeStart);
        const mimeType = decoder.decode(buffer.slice(mimeStart, mimeEnd));
        const pictureType = buffer[mimeEnd + 1];

        const descStart = mimeEnd + 2;
        let descEnd = descStart;
        let description = '';

        if (encoding === 0x00) {
          // ISO-8859-1
          descEnd = buffer.indexOf(0, descStart);
          description = new TextDecoder("iso-8859-1").decode(buffer.slice(descStart, descEnd));
          descEnd += 1;
        } else if (encoding === 0x01) {
          // UTF-16 with BOM
          for (let i = descStart; i < pos + 10 + size - 1; i++) {
            if (buffer[i] === 0x00 && buffer[i + 1] === 0x00) {
              descEnd = i;
              break;
            }
          }
          description = new TextDecoder("utf-16").decode(buffer.slice(descStart, descEnd));
          descEnd += 2;
        }

        const imageStart = descEnd;
        const imgOffset = offset + imageStart;
        const imgSize = size - (imageStart - (pos + 10));

        images.push({
          offset: imgOffset,
          size: imgSize,
          type: mimeType,
          pictureType,
          description
        });
      }

      pos += 10 + size;
    }

    break;
  }

  return images;
}
*/
