
class Channel {
  ad_channels = ''
  ad_dfp_unit_id = ''
  /** @type {Object[]} */
  artists = []
  asset_id = 0
  asset_url = ''
  banner_url = ''
  channel_director = ''
  /** @type {number[]} */
  channel_filter_ids = []
  created_at = ''
  description = ''
  description_long = ''
  description_short = ''
  favorite = false
  id = 0
  images = {}
  /** Url slug of the channel name */
  key = ''
  /** The name of the channel */
  name = ''
  network_id = 0
  premium_id = null
  public = false
  /** @type {Object[]} */
  similar_channels = []
  tracklist_server_id = 0
  updated_at = ''
}

class Config {
  adwords_conversion = {}
  alexa_skill_url = ''
  api = {}
  appDeployTime = ''
  apps = {}
  appVersion = ''
  asset_paths = {}
  banners = []
  calendar = {}
  channel_filters = []
  channelFavorites = {}
  /** @type {Channel[]} */
  channels = []
  chrome_extension = {}
  clevertap = {}
  crowdfunding = {}
  currentUserType = ''
  discord_url = ''
  email = {}
  external_players = {}
  facebook = {}
  firebase = {}
  followed_items = {}
  google_gtag_config = {}
  has_trial_page = false
  instructions = {}
  listen_url = ''
  messages = []
  mobile_webview = false
  modals = {}
  network_description = ''
  network_key = ''
  network_name = ''
  networks = []
  performance_reporting = false
  playlists = {}
  po_rollout = {}
  recaptcha = {}
  requestEnv = {}
  service_key = ''
  service_name = ''
  sidepanel = {}
  stream_set_configs = []
}

export { Config, Channel }