// === CRC32 (för bytes) ===
function makeCrc32Table () {
	const table = new Uint32Array(256)
	for (let i = 0; i < 256; i++) {
		let t = i
		for (let j = 0; j < 8; j++) {
			t = t & 1 ? (t >>> 1) ^ 0xedb88320 : t >>> 1
		}
		table[i] = t
	}
	return table
}

const CRC32_TABLE = makeCrc32Table()

function crc32 (bytes) {
	let crc = ~0
	for (let i = 0; i < bytes.length; i++) {
		crc = (crc >>> 8) ^ CRC32_TABLE[(crc ^ bytes[i]) & 0xff]
	}
	return ~crc >>> 0
}

// === BloomFilter ===
class BloomFilter {
	constructor ({ size, hashes, seed = 0, bits }) {
		this.size = size
		this.hashes = hashes
		this.seed = seed
		this.bits = bits // Uint32Array
	}

	getBit (index) {
		const wordIndex = index >>> 5
		const bitIndex = index & 31
		return (this.bits[wordIndex] >>> bitIndex) & 1
	}

	indexesForBytes (baseBytes) {
		const indexes = []

		for (let i = 0; i < this.hashes; i++) {
			const suffix = new TextEncoder().encode(`:${this.seed + i}`)
			const full = new Uint8Array(baseBytes.length + suffix.length)
			full.set(baseBytes)
			full.set(suffix, baseBytes.length)
			const hash = crc32(full)
			indexes.push(hash % this.size)
		}

		return indexes
	}

	testBytes (bytes) {
		if (!this.size || !this.hashes) return false
		return this.indexesForBytes(bytes).every(index => this.getBit(index))
	}
}

// // Förbered bytes (strikt!)
// const id = 16450834;
// const encoded = new TextEncoder().encode(id.toString());

// const result = filter.testBytes(encoded);
// console.log(`ID ${id} finns i filtret?`, result ? "JA ✅" : "NEJ ❌");

/**
 * Creates a lookup object where each specified key from each object in the array
 * is used as a property in the result. If multiple objects share the same key value,
 * the last one overwrites the previous. Objects in the result are mutable references.
 *
 * @template T - Type of the objects in the array
 * @param {T[]} arr - The array of objects to index.
 * @param {(keyof T)[]} keys - A list of keys whose values will be used as properties in the result.
 * @returns {Record<string | number | symbol, T>} An object mapping key values to the corresponding object.
 */
function makeDictionary (arr, keys) {
	const result = Object.create(null)

	for (const item of arr) {
		for (const key of keys) { result[item[key]] = item }
	}

	return result
}

const pick = (...k) => o => k.flat().reduce((a, x) => (a[x] = o[x], a), {})
const call = (m, ...a) => o => o[m](...a)

async function getJson (u, headers = {}) {
	const res = await fetch(u, { headers })
	const text = await res.text()
	return JSON.parse(text, normalizeJson)
}

function shuffle (arr) {
	return arr.map(value => [Math.random(), value])
		.sort((a, b) => a[0] - b[0])
		.map(e => e[1])
}

async function postJson (u, body, headers = {}) {
	const res = await fetch(u, {
		method: 'POST',
		body: JSON.stringify(body),
		headers: { 'content-type': 'application/json', ...headers }
	})
	const text = await res.text()
	return JSON.parse(text, normalizeJson)
}

function snakeToCamel (str) {
	return str.replace(/_([a-z])/g, (_, c) => c.toUpperCase())
}

function extractHash (url) {
	// matchar en slash följt av exakt 32 hex-tecken följt av punkt
	const match = url.match(/\/([0-9a-f]{32})\./i)
	return match ? match[1] : null
}

/** @param {Uint8Array} bytes */
function bytesToCdnUrl (bytes, useImageCdn = false) {
	// exempel
	// https://cdn.audioaddict.com/4/5/8/d/7/4/458d747d74e38ee1cd3f1452f3d0dcf3.png
	const hex = bytes.toHex()
	const parts = hex.match(/.{1}/g)

	return useImageCdn
		? `https://cdn-images.audioaddict.com/${parts.slice(0, 6).join('/')}/${hex}`
		: `https://cdn.audioaddict.com/${parts.slice(0, 6).join('/')}/${hex}.png`
}
globalThis.bytesToCdnUrl = bytesToCdnUrl
function normalizeJson (key, value) {
	// värdehantering (din existerande logik)
	if (key === 'bits') return new Uint32Array(value)

	if (typeof value === 'string' && value.startsWith?.('//')) {
		try {
			const url = new URL(value.replace(/^\/\//, 'https://').replace(/{.*}/, ''))

			// Specifik hantering för AudioAddict CDN-URL:er
			if (
				url.hostname === 'static.audioaddict.com' ||
				url.hostname === 'cdn-images.audioaddict.com' ||
				url.hostname === 'cdn.audioaddict.com'
			) {
				return Uint8Array.fromHex(extractHash(value))
			}

			return url.href
		} catch {
			return value
		}
	}

	if (key.startsWith('who_')) {
		return new BloomFilter(value)
	}

	if (key.startsWith('votes') && value?.who_downvoted && value?.who_upvoted) {
		const myId = new TextEncoder().encode(config.session.memberId.toString())
		const iDownVoted = value.who_downvoted.testBytes(myId)
		const iUpVoted = value.who_upvoted.testBytes(myId)
		delete value.who_downvoted
		delete value.who_upvoted
		value.me = iDownVoted ? false : iUpVoted ? true : null
	}

	// 🧠 camelCase-konvertering för objekt
	if (value && typeof value === 'object' && !Array.isArray(value)) {
		const newObj = {}
		for (const [k, v] of Object.entries(value)) {
			newObj[snakeToCamel(k)] = v
		}
		return newObj
	}

	return value
}

async function makeFileHandleRecursive (rootHandle, path) {
	const parts = path.split('/').filter(Boolean)
	const name = parts.pop()
	while (parts.length) {
		rootHandle = await rootHandle.getDirectoryHandle(parts.shift(), { create: true })
	}
	return rootHandle.getFileHandle(name, { create: true })
}

const values = async (it, bag = []) => {
	for await (const v of it) bag.push(v)
	return bag
}

const formatTime = (seconds) => {
	if (seconds === Infinity) return 'Live'
	if (!seconds || isNaN(seconds)) return '00:00'
	const hours = Math.floor(seconds / 3600)
	const mins = Math.floor((seconds % 3600) / 60)
	const secs = Math.floor(seconds % 60)
	return `${hours > 0 ? hours + ':' : ''}${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`
}

/**
 * @template T
 * @typedef {T | Promise<T>} Awaitable
 */

/**
 * @template T
 * @typedef {T extends Promise<infer U> ? U : T} UnwrapPromise
 */

/**
 * Lazy<T> creates a "proxy promise" that:
 * — exposes T's properties
 * — exposes T's methods as callable functions
 * — unwraps Promise<T> → T at the type level
 * — supports async iteration if T is an AsyncIterable
 *
 * @template T
 * @typedef {{
 *   then: Promise<T>['then'],
 * } & (T extends AsyncIterable<infer U> ? { [Symbol.asyncIterator]: () => AsyncIterator<U> } : {}) & {
 *   [K in keyof UnwrapPromise<T>]:
 *     UnwrapPromise<T>[K] extends (...args: infer A) => infer R
 *       ? (...args: A) => Lazy<R>
 *       : Lazy<UnwrapPromise<T>[K]>
 * }} Lazy<T>
 */

function noop () {}
/**
 * Wraps a value or promise in a lazy proxy that allows chaining without await.
 *
 * @template T
 * @param {Awaitable<T>} target
 * @returns {Lazy<T>}
 */
const lazy = target => {
	return new Proxy(noop, {
		get (_, key) {
			if (key === 'then') {
				const p = Promise.resolve(target)
				return p.then.bind(p)
			}

			// if (key === Symbol.asyncIterator) {
			//   return () => {
			//     let iter
			//     return {
			//       async next() {
			//         const t = await target
			//         if (!iter) iter = t[Symbol.asyncIterator]()
			//         return iter.next()
			//       }
			//     }
			//   }
			// }

			return lazy(
				Promise.resolve(target).then(obj => {
					const val = obj[key]
					return typeof val === 'function' ? val.bind(obj) : val
				})
			)
		},

		apply (noop, that, args) {
			return lazy(
				Promise.resolve(target).then(fn => fn.apply(that, args))
			)
		},

		construct (noop, args) {
			return lazy(
				Promise.resolve(target).then(fn => new fn(...args))
			)
		}
	})
}

export {
	call,
	getJson,
	lazy,
	makeDictionary,
	makeFileHandleRecursive,
	pick,
	postJson,
	shuffle,
	formatTime,
	values,
	bytesToCdnUrl
}
