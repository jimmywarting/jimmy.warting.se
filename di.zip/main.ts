fetch("https://sl.se", {
  method: "POST",
  body: (123).toString(),
});
