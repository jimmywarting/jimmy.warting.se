import http from 'node:http'
import fs from 'node:fs/promises'

const PORT = 8080
const HOST = '0.0.0.0'

const server = http.createServer((req, res) => {
  // static file server
  let filePath = `.${req.url}`
  if (filePath === './') {
    filePath = './lit.html'
  }

  // enable CORS
  res.setHeader('Access-Control-Allow-Origin', '*')

  fs.readFile(filePath)
    .then(data => {
      res.writeHead(200)
      res.end(data)
    })
    .catch(err => {
      res.writeHead(404)
      res.end('Not found')
    })
})

server.listen(PORT, HOST, () => {
  console.log(`Server running at http://${HOST}:${PORT}/`)
})