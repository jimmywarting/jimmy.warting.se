const cachedV1 = caches.open('v1')

async function processImage (res, width, quality = 0.9) {
  const originalBlob = await res.blob()
  console.log({originalBlob})
  const bitmap = await createImageBitmap(originalBlob)

  const targetWidth = width ? Math.min(Number(width), bitmap.width) : bitmap.width
  const targetHeight = targetWidth * (bitmap.height / bitmap.width)

  const canvas = new OffscreenCanvas(targetWidth, targetHeight)
  const ctx = canvas.getContext('2d')
  ctx.drawImage(bitmap, 0, 0, targetWidth, targetHeight)

  const webpBlob = await canvas.convertToBlob({ type: 'image/webp', quality: Number(quality) })
  console.log({ originalSize: originalBlob.size, webpSize: webpBlob.size })
  // Returnera en Response med den blob som är minst
  return new Response(webpBlob.size < originalBlob.size ? webpBlob : originalBlob)
}

async function cacheFirst (req) {
  const cache = await cachedV1
  const cached = await cache.match(req.url)
  if (cached) return cached

  let res

  if (req.url.match(/\.(png|jpe?g|gif|webp)/i)) {
    res = await fetch(req.url)
    const url = new URL(req.url)
    const params = Object.fromEntries(url.searchParams)
    res = await processImage(res, params.width, params.quality)
  } else {
    res = await fetch(req)
  }

  await cache.put(req.url, res.clone())
  return res
}

const cacheable = [
  'localwebcontainer.com',
  'jsdelivr.net',
  // 'cdn.audioaddict.com',
  'unpkg.com',
  'fonts.googleapis.com'
]

router.get(
  ctx => cacheable.some(host => ctx.url.host.includes(host)),
  ctx => cacheFirst(ctx.request)
)
