globalThis.addEventListener('notificationclick', listener => {
  const notification = listener.notification
  const action = listener.action

  console.log('Notification clicked:', notification, 'Action:', action)
})

// router.get(
//   o => {
//     return o.request.destination === 'audio' && o.request.headers.get('Range')
//   },
//   async ctx => {
//     console.log('ja?')
//     const req = ctx.event.request
//     const response = await fetch(req)
//     const clone = response.clone()
//     const client = await clients.get(ctx.event.clientId)

//     client.postMessage({
//       type: 'track-chunk',
//       data: {
//         range: req.headers.get('Range'),
//         url: req.url,
//         status: clone.status,
//         statusText: clone.statusText,
//         headers: [...clone.headers],
//         body: clone.body,
//         ok: clone.ok
//       }
//     }, [clone.body])
//     return response
//   }
// )