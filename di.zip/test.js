const res = await fetch('https://www.di.fm/', {
  redirect: 'manual',
})
console.log(res)
const text = await res.text()
console.log(text)